// js/modules/datenVerarbeitung.js - v1.3.3 - Datenverarbeitung und Parsing, mit Artikel-zu-Gruppe-Mapping
console.log("Lade datenVerarbeitung.js v1.3.3...");

/**
 * Extrahiert potenzielle Produktnummern (nur Zahlen) aus einem Dateinamen-String.
 * @param {string} dateiName - Der Dateiname aus der 'Datei'-Spalte.
 * @returns {string[]} - Ein Array von eindeutigen, extrahierten Produktnummern als Strings.
 */
function extrahiereProduktnummernAusDatei(dateiName) {
    if (!dateiName || typeof dateiName !== 'string') return [];
    let basisName = dateiName.replace(/\.[^/.]+$/, "");
    basisName = basisName.replace(/_0[,.]5_Stamm|_Stamm_0[,.]5/gi, '');
    basisName = basisName.replace(/_Stamm|_Titel|_Flugblatt|_Umbau|_0[,.]5|\s0[,.]5/gi, '');
     basisName = basisName.replace(/Stamm|Titel|Flugblatt|Umbau/gi, (match) => {
         const index = basisName.indexOf(match);
         if (index === -1) return match;
         const vorher = basisName.charAt(index - 1);
         const nachher = basisName.charAt(index + match.length);
         if (!/\d/.test(vorher) && !/\d/.test(nachher)) {
             return '';
         }
         return match;
     });
    const segmente = basisName.split(/[^0-9]+/);
    const nummern = segmente.filter(segment => /^\d{4,}$/.test(segment));
    return [...new Set(nummern)];
}

/**
 * Verarbeitet die Eintheilung-Daten (aus Excel).
 * @param {object[]} planRohdaten - Die geparsten Rohdaten aus der Eintheilung-Datei (Excel).
 * @returns {{ planMap: Map<string, object>, artikelZuGruppeMap: Map<string, string>, fehlerListe: object[], minSeite: number, maxSeite: number, phase: string }}
 */
function verarbeitePlandaten(planRohdaten) {
    const planMap = new Map();
    const artikelZuGruppeMap = new Map(); // NEU: Map zur Zuordnung von Artnr zu Kataloggruppierung
    const fehlerListe = [];
    let minSeite = Infinity;
    let maxSeite = 0;

    const erwartetePlanSpaltenKern = ['Kataloggruppierung', 'Format', 'Modell', 'Seite'];
    const optionalePlanSpaltenSuche = ['Artnr', 'Artikel'];
    const duplikatPruefSpalten = [
        'ModellNr', 'Modell', 'Artnr', 'Artikel', 'GroessenVerlauf',
        'VKPreis', 'StattPreis', 'Rabatt', 'Format', 'NeuIn'
    ];

    if (!planRohdaten || planRohdaten.length === 0) {
        throw new Error("Eintheilung-Daten (Excel) sind leer oder ungültig.");
    }

    const ersteZeileKeysRoh = Object.keys(planRohdaten[0] || {});
    const ersteZeileKeys = ersteZeileKeysRoh.map(key => key.trim());

    if (!ersteZeileKeys.includes('Artnr')) {
        console.warn("Die Spalte 'Artnr' fehlt in der Einteilung. Die Zuordnung kann ungenau sein.");
    }

    const fehlendeKernSpalten = erwartetePlanSpaltenKern.filter(spalte => !ersteZeileKeys.includes(spalte));
    if (fehlendeKernSpalten.length > 0) {
        throw new Error(`Fehlende erforderliche Kernspalten in der Eintheilung-Datei (Excel): ${fehlendeKernSpalten.join(', ')}`);
    }

    // Verarbeitung der Daten
    planRohdaten.forEach((zeileRoh, index) => {
         const zeile = {};
         for (const key in zeileRoh) { zeile[key.trim()] = zeileRoh[key]; }
         const gruppe = zeile.Kataloggruppierung?.toString().trim();
         const artnr = zeile.Artnr?.toString().trim();
         const formatStr = zeile.Format?.toString().replace(',', '.').trim();
         const format = parseFloat(formatStr);
         const modell = (zeile.Modell || 'Unbekannt').trim();
         const seiteRoh = zeile.Seite;
         const seiteNum = parseInt(seiteRoh, 10);

         if (!isNaN(seiteNum) && seiteNum > 500) return;
         if (!gruppe) { console.warn(`Zeile ${index + 2} in Eintheilung-Daten ohne Kataloggruppierung ignoriert.`); return; }

         // Jede Artikelnummer ihrer Gruppe zuordnen
         if (artnr) {
            artikelZuGruppeMap.set(artnr, gruppe);
         }
         // Auch die Gruppennummer selbst zuordnen, falls sie als Produktnummer verwendet wird
         artikelZuGruppeMap.set(gruppe, gruppe);

         if (!planMap.has(gruppe)) {
             planMap.set(gruppe, {
                 gesamtFormat: 0, modell: 'Unbekannt', artikel: [], formatFehler: false,
                 istDoppelseite: false, istFlugblatt: false, istHalbseite: false,
                 seiten: new Set(), ersteSeiteNum: NaN, seite: 0,
                 fehlerNichtInId: false
             });
         }
         const eintrag = planMap.get(gruppe);
         if (eintrag.modell === 'Unbekannt' && modell !== 'Unbekannt') eintrag.modell = modell;
         eintrag.artikel.push(zeileRoh);

         if (isNaN(format)) {
             if (!eintrag.formatFehler && zeile.Format !== undefined && zeile.Format !== null && zeile.Format !== '') {
                 fehlerListe.push({ typ: 'Ungültiges Format (keine Zahl)', zeile: index + 2, gruppe: gruppe, wert: zeile.Format, modell: modell });
                 eintrag.formatFehler = true;
             }
         } else {
             eintrag.gesamtFormat += format;
         }

         if (!isNaN(seiteNum)) {
             eintrag.seiten.add(seiteNum);
             if (seiteNum > 0) eintrag.seite = seiteNum;
             if (isNaN(eintrag.ersteSeiteNum) || (seiteNum !== 0 && seiteNum < eintrag.ersteSeiteNum)) {
                eintrag.ersteSeiteNum = seiteNum;
             }
             if (seiteNum > 0 && seiteNum <= 500) {
                if(seiteNum > 1) minSeite = Math.min(minSeite, seiteNum);
                maxSeite = Math.max(maxSeite, seiteNum);
             }
         }
    });

    // Nachbearbeitung der Einträge in der planMap
    planMap.forEach((eintrag, gruppe) => {
        const gerundetesFormat = Math.round(eintrag.gesamtFormat * 100) / 100;
        let hatKatalogSeite = false, hatFlugblattSeite = false;
        eintrag.seiten.forEach(s => {
             if (s > 500) hatFlugblattSeite = true;
             else if (s > 0) hatKatalogSeite = true;
        });
        eintrag.istFlugblatt = (hatFlugblattSeite && !hatKatalogSeite) || (hatKatalogSeite && hatFlugblattSeite);

        if (!eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat !== 0 && ![0.5, 1, 2].includes(gerundetesFormat)) {
             if (!fehlerListe.some(f => f.gruppe === gruppe && f.typ === 'Ungültiges Format (keine Zahl)')) {
                fehlerListe.push({ typ: 'Ungültige Format-Summe', gruppe: gruppe, modell: eintrag.modell, summe: gerundetesFormat, erwartet: "0.5, 1 oder 2" });
             }
             eintrag.formatFehler = true;
        }

        eintrag.istDoppelseite = !eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat === 2;
        eintrag.istHalbseite = !eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat === 0.5;
        eintrag.gesamtFormat = gerundetesFormat;
    });

    if (minSeite === Infinity) minSeite = 1;
    const phase = detektierePhase(planMap);

    return { planMap, artikelZuGruppeMap, fehlerListe, minSeite, maxSeite, phase };
}


/**
 * Detektiert die Phase der Eintheilung (Sortiert oder Unsortiert).
 * @param {Map<string, object>} planMap - Verarbeitete Plan-Daten.
 * @returns {string} - 'SORTIERT' oder 'UNSORTIERT'
 */
function detektierePhase(planMap) {
    const alleEintraege = Array.from(planMap.values());
    const katalogEintraege = alleEintraege.filter(eintrag => !eintrag.istFlugblatt);
    const katalogMitSeitenzahlen = katalogEintraege.filter(eintrag => eintrag.seite && eintrag.seite > 0);
    const schwellenwert = Math.min(5, Math.floor(katalogEintraege.length * 0.1));
    return katalogMitSeitenzahlen.length <= schwellenwert ? 'UNSORTIERT' : 'SORTIERT';
}

/**
 * Verarbeitet die InDesign-Daten (CSV).
 * @param {object[]} inDesignRohdaten - Die geparsten Rohdaten aus der InDesign-Exportdatei (CSV).
 * @returns {{inDesignSeitenMap: Map<string, object>, produktNummerZuSeitenMap: Map<string, Set<string>>}}
 */
function verarbeiteInDesignDaten(inDesignRohdaten) {
    const seitenRohdatenMap = new Map();
    const produktNummerZuSeitenMap = new Map();
    const erwarteteCsvSpalten = ['Produktnummer', 'Seite', 'Format', 'Datei'];

    if (!inDesignRohdaten || inDesignRohdaten.length === 0) throw new Error("InDesign-Daten (CSV) sind leer oder ungültig.");
    const ersteZeileKeysCsv = Object.keys(inDesignRohdaten[0] || {});

    const fehlendeCsvSpalten = erwarteteCsvSpalten.filter(spalte => !ersteZeileKeysCsv.includes(spalte));
    if (fehlendeCsvSpalten.length > 0) {
        throw new Error(`Fehlende erforderliche Spalten in der InDesign-Datei (CSV): ${fehlendeCsvSpalten.join(', ')}`);
    }

    inDesignRohdaten.forEach((zeile) => {
        const seiteStr = zeile.Seite?.toString().trim();
        if (!seiteStr) return;
        const seiteNum = parseInt(seiteStr, 10);
        if (!isNaN(seiteNum) && seiteNum > 500) return;

        if (!seitenRohdatenMap.has(seiteStr)) seitenRohdatenMap.set(seiteStr, []);
        const formatStr = zeile.Format?.toString().replace(',', '.').trim();
        const format = parseFloat(formatStr);
        seitenRohdatenMap.get(seiteStr).push({ ...zeile, gueltigesFormat: !isNaN(format) ? format : NaN });

        const produktnummerAusCsv = zeile.Produktnummer?.toString().trim();
        const dateiName = zeile.Datei?.toString().trim();
        const produktnummernDieserZeile = new Set();
        if (produktnummerAusCsv) produktnummernDieserZeile.add(produktnummerAusCsv);
        if (dateiName) { extrahiereProduktnummernAusDatei(dateiName).forEach(nr => produktnummernDieserZeile.add(nr)); }

        produktnummernDieserZeile.forEach(produktnummer => {
            if (!produktNummerZuSeitenMap.has(produktnummer)) produktNummerZuSeitenMap.set(produktnummer, new Set());
            produktNummerZuSeitenMap.get(produktnummer).add(seiteStr);
        });
    });

    const inDesignSeitenMap = new Map();
    seitenRohdatenMap.forEach((rohdatenListe, seite) => {
        const produktnummern = new Set();
        let sumFormat = 0;
        let hatGueltigenInhalt = false;

        rohdatenListe.forEach(zeile => {
            const nummerAusCsv = zeile.Produktnummer?.toString().trim();
            if (nummerAusCsv) {
                produktnummern.add(nummerAusCsv);
                hatGueltigenInhalt = true;
            }
            if (!isNaN(zeile.gueltigesFormat)) {
                sumFormat += zeile.gueltigesFormat;
                if (zeile.gueltigesFormat > 0) hatGueltigenInhalt = true;
            }
        });

        inDesignSeitenMap.set(seite, {
            produktnummern: Array.from(produktnummern).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
            rohdatenZeilen: rohdatenListe,
            seitenFormat: sumFormat,
            hatInhalt: hatGueltigenInhalt
        });
    });

    return { inDesignSeitenMap, produktNummerZuSeitenMap };
}


console.log("datenVerarbeitung.js v1.3.3 geladen.");