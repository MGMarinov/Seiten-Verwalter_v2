// js/compare.js - v.2.0 - Datenvergleichslogik
console.log("Lade compare.js v.2.0...");

/**
 * Vergleicht Eintheilung- und InDesign-Daten, identifiziert Korrekturen und Duplikate/Konflikte.
 * Setzt Fehler-Flags für fehlende Gegenstücke.
 * @param {Map<string, object>} planMap - Schlüssel: Kataloggruppierung.
 * @param {Map<string, object>} inDesignSeitenMap - Schlüssel: Seite.
 * @param {Map<string, Set<string>>} produktNummerZuSeitenMap - Schlüssel: Produktnummer, Wert: Set von Seiten (aus InDesign).
 * @param {number} maxPlanSeiteFuerRueckseite - Die höchste Seitenzahl <= 500 aus dem Plan (für Rückseitenlogik).
 * @returns {{ zuEntfernen: object[], hinzuzufuegen: object[], korrekt: object[], duplikatFehler: object[], seitenZahlFehler: object[], unvollstaendigeSeiten: object[], fehlendeHalbseiten: object[] }}
 */
function vergleicheDaten(planMap, inDesignSeitenMap, produktNummerZuSeitenMap, maxPlanSeiteFuerRueckseite) {
    const zuEntfernen = [];
    const hinzuzufuegen = [];
    const korrekt = [];
    const duplikatFehler = [];
    const seitenZahlFehler = [];
    const inDesignNummernVerarbeitetFuerDuplikate = new Set();
    const planNummernVerarbeitet = new Set();
    const idSeitenMitFehlerNichtInPlan = new Set();
    const processedMultiPageProducts = new Set();

    // Duplikate im Katalog identifizieren
    produktNummerZuSeitenMap.forEach((seitenSet, produktNummer) => {
        if (seitenSet.size > 1) {
            const seitenArray = Array.from(seitenSet).sort((a, b) => {
                const numA = parseInt(a, 10);
                const numB = parseInt(b, 10);
                return isNaN(numA) || isNaN(numB) ? a.localeCompare(b) : numA - numB;
            });

            const planEintrag = planMap.get(produktNummer);
            const istFlugblattLautPlan = planEintrag ? planEintrag.istFlugblatt : false;

            let konfliktTyp = 'Duplikat im Katalog';
            if (istFlugblattLautPlan) {
                konfliktTyp = 'Konflikt: Katalog & Flugblatt';
            }

            duplikatFehler.push({
                produktNummer: produktNummer,
                typ: konfliktTyp,
                seiten: seitenArray.join(', '),
                details: `Produktnummer auf ${seitenSet.size} Seiten gefunden`
            });

            seitenArray.forEach(seite => {
                const seitenEintrag = inDesignSeitenMap.get(seite);
                if (seitenEintrag && seitenEintrag.produktnummern.includes(produktNummer)) {
                    inDesignNummernVerarbeitetFuerDuplikate.add(produktNummer);
                }
            });
        }
    });

    // Plan-Einträge verarbeiten
    planMap.forEach((planEintrag, planNummer) => {
        if (planEintrag.istFlugblatt || planEintrag.formatFehler || planEintrag.gesamtFormat === 0) {
            return;
        }

        const seitenMitDieserNummer = produktNummerZuSeitenMap.get(planNummer);
        if (seitenMitDieserNummer && seitenMitDieserNummer.size > 0) {
            const seitenArray = Array.from(seitenMitDieserNummer);
            const seitenString = seitenArray.sort((a, b) => {
                const numA = parseInt(a, 10);
                const numB = parseInt(b, 10);
                return isNaN(numA) || isNaN(numB) ? a.localeCompare(b) : numA - numB;
            }).join(', ');

            let aktuellesSeitenFormatInDesign = 0;
            seitenArray.forEach(seite => {
                const seitenEintrag = inDesignSeitenMap.get(seite);
                if (seitenEintrag) {
                    aktuellesSeitenFormatInDesign = Math.max(aktuellesSeitenFormatInDesign, seitenEintrag.seitenFormat);
                }
            });

            const korrektItem = {
                seite: seitenString,
                katalogGruppe: planNummer,
                modell: planEintrag.modell,
                gesamtFormat: planEintrag.gesamtFormat,
                seitenFormat: aktuellesSeitenFormatInDesign,
                istDoppelseite: planEintrag.istDoppelseite,
                istHalbseite: planEintrag.istHalbseite,
                seiteNum: planEintrag.ersteSeiteNum,
                formatFehler: false,
                istTitel: false,
                istRueckseite: false,
                hatInhaltswarnung: false,
                warnungsDetails: '',
                hatSeitenZahlFehler: false
            };

            korrekt.push(korrektItem);
        } else {
            hinzuzufuegen.push({
                seite: '',
                katalogGruppe: planNummer,
                modell: planEintrag.modell,
                gesamtFormat: planEintrag.gesamtFormat,
                istDoppelseite: planEintrag.istDoppelseite,
                istHalbseite: planEintrag.istHalbseite,
                seiteNum: planEintrag.ersteSeiteNum,
                formatFehler: false
            });
            planEintrag.fehlerNichtInId = true;
        }
        planNummernVerarbeitet.add(planNummer);
    });

    // Zu entfernende Objekte identifizieren - Produktebene-Logik
    inDesignSeitenMap.forEach((seitenEintrag, seiteStr) => {
        if (!seitenEintrag.hatInhalt) return;

        let seitenHatProblematischeProdukte = false;

        // Alle Produktnummern einzeln prüfen
        for (const idNummer of seitenEintrag.produktnummern) {
            let produktIstProblematisch = false;
            let produktModell = '-';
            const produktGruende = new Set();

            // Duplikat/Konflikt-Behandlung
            if (inDesignNummernVerarbeitetFuerDuplikate.has(idNummer)) {
                produktGruende.add('Konflikt/Duplikat');
                produktIstProblematisch = true;
            } else {
                const planEintrag = planMap.get(idNummer);
                if (planEintrag) {
                    // Produkt ist im Plan vorhanden - prüfen ob korrekt
                    if (planEintrag.istFlugblatt || planEintrag.formatFehler || planEintrag.gesamtFormat === 0) {
                        // Problematisches Produkt im Plan
                        if (planEintrag.istFlugblatt) produktGruende.add('Flugblatt (Plan)');
                        if (planEintrag.formatFehler) produktGruende.add('Formatfehler (Plan)');
                        if (planEintrag.gesamtFormat === 0) produktGruende.add('Format 0 (Plan)');
                        produktIstProblematisch = true;
                        if (planEintrag.modell !== 'Unbekannt') {
                            produktModell = planEintrag.modell;
                        }
                    }
                } else {
                    // Produkt fehlt im Plan
                    produktGruende.add('Nicht in Eintheilung');
                    produktIstProblematisch = true;
                }
            }

            // Problematisches Produkt zur Entfernungsliste hinzufügen
            if (produktIstProblematisch) {
                seitenHatProblematischeProdukte = true;

                let grund = Array.from(produktGruende).join('/') || 'Unbekannter Grund';

                // Modell aus Rohdaten bestimmen falls nicht verfügbar
                if (produktModell === '-' && seitenEintrag.rohdatenZeilen.length > 0) {
                    const rohZeileMitProdukt = seitenEintrag.rohdatenZeilen.find(z =>
                        z.Produktnummer?.toString().trim() === idNummer ||
                        (z.Datei && extrahiereProduktnummernAusDatei(z.Datei.toString().trim()).includes(idNummer))
                    );
                    if (rohZeileMitProdukt && rohZeileMitProdukt.Modell?.trim()) {
                        produktModell = rohZeileMitProdukt.Modell.trim();
                    }
                }

                // Problematisches Produkt zur Liste hinzufügen
                zuEntfernen.push({
                    seite: seiteStr,
                    katalogGruppe: idNummer,
                    modell: produktModell,
                    seitenFormat: seitenEintrag.seitenFormat,
                    gesamtFormat: null,
                    grund: grund
                });
            }
        }

        // Seite als fehlerhaft markieren wenn problematische Produkte vorhanden
        if (seitenHatProblematischeProdukte) {
            idSeitenMitFehlerNichtInPlan.add(seiteStr);
        }
    });

    // Markiere die InDesign SeitenMap Einträge
    idSeitenMitFehlerNichtInPlan.forEach(seiteStr => {
        const seitenEintrag = inDesignSeitenMap.get(seiteStr);
        if (seitenEintrag) {
            seitenEintrag.fehlerNichtInPlan = true;
        }
    });

    // Titel- und Rückseiten markieren
    korrekt.forEach(item => {
        const seiteNum = parseInt(item.seite.split(',')[0]?.trim(), 10);
        if (!isNaN(seiteNum)) {
            if (seiteNum === 1) {
                item.istTitel = true;
            } else if (seiteNum === maxPlanSeiteFuerRueckseite + 1) {
                item.istRueckseite = true;
            }
        }
    });

    // Halbseiten-Analyse
    const { unvollstaendigeSeiten, fehlendeHalbseiten } = analysiereHalbseitenUndLeerePlaetze(
        planMap, inDesignSeitenMap, maxPlanSeiteFuerRueckseite
    );

    // Sortierung
    zuEntfernen.sort(sortSeiteGruppe);
    korrekt.sort(sortSeiteGruppe);
    hinzuzufuegen.sort(sortGruppe);
    duplikatFehler.sort(sortGruppe);
    seitenZahlFehler.sort((a, b) => {
        if (a.planSeite !== b.planSeite) return a.planSeite - b.planSeite;
        const idA = parseInt(a.idSeite, 10);
        const idB = parseInt(b.idSeite, 10);
        if (!isNaN(idA) && !isNaN(idB)) return idA - idB;
        return String(a.planGruppe || '').localeCompare(String(b.planGruppe || ''), 'de', { numeric: true });
    });
    unvollstaendigeSeiten.sort(sortUnvollstaendigeSeiten);
    fehlendeHalbseiten.sort(sortUnvollstaendigeSeiten);

    return {
        zuEntfernen,
        hinzuzufuegen,
        korrekt,
        duplikatFehler,
        seitenZahlFehler,
        unvollstaendigeSeiten,
        fehlendeHalbseiten
    };
}

console.log("compare.js v.2.0 geladen.");
