# Claude Development Guidelines - Katalog Vergleich

## Entwicklungsrichtlinien

1. Objektumorientált programozásra törekedj!
2. A kódban csak német nyelvet használhatsz, de velem magyar nyelven kommunikálj!
3. Ha magyar nyelvű kommentet találsz, írd át németre!
4. Mielőtt elkezdenéd kódolni, sorold fel a módosítandó fájlokat!
5. Ha a kód újraírása folyamán hibát találsz vagy olyan elemet, amit optimalizálni lehet, jelezd a végén, amikor összefoglalod a műveletet!
6. Próbálj meg létező függvényeket, stíluselemeket használni vagy kibővíteni! Ne hozz létre szükségszerűen újakat!
7. Mindig törekedj a tiszta és egyszerű kód írására!
8. Kizárólag a működésre vonatkozó kommenteket helyezz el a kódban, módosításra utaló megjegyzéseket ne!
9. Kikommentelt elemekre nincs szükség, töröld mindet a kódból!
10. A meglévő, működő kódrészleteken ne változtass, kivéve, ha az az új funkció implementálásához elkerülhetetlen. A kódoptimalizálás vagy -tisztítás (refactoring) csak külön kérésre történjen.
11. Mindig tegeződő formát használj a kommunikációban és a kódban is (pl. alert üzenetek).
12. Mindig a teljes kódot illeszd be, hogy elkerüld a másolás-beillesztés (copy and paste) hibákat.

## Projektspecifikus információk

- **Nyelv**: Kódban német, kommunikációban magyar
- **Architektura**: Moduláris JavaScript struktúra
- **Főbb modulok**:
  - `js/modules/datenVerarbeitung.js` - Adatfeldolgozás
  - `js/modules/katalogLogik.js` - Katalógus logika
  - `js/modules/vergleichsLogik.js` - Összehasonlítási logika
  - `js/modules/uiController.js` - UI vezérlés
- **Tesztelés**: `utils/auto-test.js` automatizált tesztekkel
- **Bilanz rendszer**: Katalógus teljesség ellenőrzése