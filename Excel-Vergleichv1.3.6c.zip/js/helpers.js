// js/helpers.js - v.2.0 - Hilfsfunktionen für Datenverarbeitung
console.log("Lade helpers.js v.2.0...");

/**
 * Extrahiert potenzielle Produktnummern (nur Zahlen) aus einem Dateinamen-String.
 * @param {string} dateiName - Der Dateiname aus der 'Datei'-Spalte.
 * @returns {string[]} - Array von Produktnummern als Strings.
 */
function extrahiereProduktnummernAusDatei(dateiName) {
    if (!dateiName || typeof dateiName !== 'string') return [];
    const nummernMatches = dateiName.match(/\b\d{4,}\b/g);
    return nummernMatches ? nummernMatches.map(n => n.trim()).filter(n => n.length >= 4) : [];
}

/**
 * Hilfsfunktion für Sortierung nach Seite und Gruppe.
 */
function sortSeiteGruppe(a, b) {
    const seiteA = parseInt(a.seite, 10);
    const seiteB = parseInt(b.seite, 10);
    if (!isNaN(seiteA) && !isNaN(seiteB) && seiteA !== seiteB) return seiteA - seiteB;
    return String(a.katalogGruppe || '').localeCompare(String(b.katalogGruppe || ''), 'de', { numeric: true });
}

/**
 * Hilfsfunktion für Sortierung nach Gruppe.
 */
function sortGruppe(a, b) {
    return String(a.katalogGruppe || a.produktNummer || '').localeCompare(String(b.katalogGruppe || b.produktNummer || ''), 'de', { numeric: true });
}

/**
 * Hilfsfunktion für Sortierung unvollständiger Seiten.
 */
function sortUnvollstaendigeSeiten(a, b) {
    const seiteA = parseInt(a.seite, 10);
    const seiteB = parseInt(b.seite, 10);
    if (!isNaN(seiteA) && !isNaN(seiteB)) return seiteA - seiteB;
    return String(a.seite || '').localeCompare(String(b.seite || ''), 'de', { numeric: true });
}

/**
 * Analysiert Halbseiten und leere Plätze im Katalog.
 * Erkennt unvollständige Seiten und fehlende Halbseiten-Dokumente.
 * @param {Map<string, object>} planMap - Verarbeitete Plan-Daten.
 * @param {Map<string, object>} inDesignSeitenMap - Verarbeitete InDesign-Daten.
 * @param {number} maxSeiteNum - Höchste Seitenzahl im Katalog.
 * @returns {{ unvollstaendigeSeiten: object[], fehlendeHalbseiten: object[] }}
 */
function analysiereHalbseitenUndLeerePlaetze(planMap, inDesignSeitenMap, maxSeiteNum) {
    const unvollstaendigeSeiten = [];
    const fehlendeHalbseiten = [];

    const planSeitenNachNummer = new Map();
    const idSeitenNachNummer = new Map();

    planMap.forEach((eintrag, gruppe) => {
        if (eintrag.seiten && eintrag.seiten.size > 0) {
            eintrag.seiten.forEach(seiteNum => {
                if (!planSeitenNachNummer.has(seiteNum)) {
                    planSeitenNachNummer.set(seiteNum, []);
                }
                planSeitenNachNummer.get(seiteNum).push({
                    gruppe: gruppe,
                    format: eintrag.gesamtFormat,
                    istHalbseite: eintrag.istHalbseite,
                    istDoppelseite: eintrag.istDoppelseite,
                    istFlugblatt: eintrag.istFlugblatt
                });
            });
        }
    });

    inDesignSeitenMap.forEach((seitenEintrag, seiteStr) => {
        const seiteNum = parseInt(seiteStr, 10);
        if (!isNaN(seiteNum)) {
            idSeitenNachNummer.set(seiteNum, seitenEintrag);
        }
    });

    for (let seiteNum = 1; seiteNum <= maxSeiteNum; seiteNum++) {
        const idSeite = idSeitenNachNummer.get(seiteNum);
        const planEintraege = planSeitenNachNummer.get(seiteNum) || [];

        let gesamtFormatPlan = 0;
        planEintraege.forEach(eintrag => {
            gesamtFormatPlan += eintrag.format;
        });

        const formatInDesign = idSeite ? idSeite.seitenFormat : 0;

        if (gesamtFormatPlan === 0.5 && formatInDesign === 0) {
            fehlendeHalbseiten.push({
                seite: seiteNum.toString(),
                planFormat: gesamtFormatPlan,
                inDesignFormat: formatInDesign,
                grund: 'Halbseite im Plan, aber nicht in InDesign'
            });
        } else if (gesamtFormatPlan > 0 && gesamtFormatPlan < 1 && formatInDesign < gesamtFormatPlan) {
            unvollstaendigeSeiten.push({
                seite: seiteNum.toString(),
                planFormat: gesamtFormatPlan,
                inDesignFormat: formatInDesign,
                verfuegbarerPlatz: 1 - gesamtFormatPlan,
                grund: 'Unvollständige Seite - Platz für weitere Dokumente'
            });
        }
    }

    return { unvollstaendigeSeiten, fehlendeHalbseiten };
}

console.log("helpers.js v.2.0 geladen.");
