// js/utils.js - v.1.19 - Hilfsfunktionen
console.log("Lade utils.js v.1.19...");

let erfolgsTimeoutId = null;

/**
 * Zeigt/Verbirgt Ladeanzeige auf Button.
 * @param {boolean} istAmLaden - True zum Anzeigen, false zum Verbergen.
 */
 function ladeanzeigeZeigen(istAmLaden) {
    const vergleichButton = document.getElementById('vergleichButton');
    if (!vergleichButton) { console.error("Fehler: Vergleich-Button nicht gefunden."); return; }
    const ladeSpinner = vergleichButton.querySelector('.spinner');
    const buttonText = vergleichButton.querySelector('.button-text');
    if (!ladeSpinner || !buttonText) { console.error("Fehler: Spinner/Button-Text im Button nicht gefunden."); return; }
    ladeSpinner.classList.toggle('hidden', !istAmLaden);
    vergleichButton.disabled = istAmLaden;
    buttonText.textContent = istAmLaden ? "Verarbeitung..." : "Vergleich Starten";
}

/**
 * Zeigt globale Nachricht an (Overlay für Erfolg, Bereich für andere - Dark Mode angepasst).
 * @param {string} nachricht - Die anzuzeigende Nachricht.
 * @param {'danger'|'warning'|'success'|'info'} [typ='danger'] - Typ der Nachricht.
 */
function globalNachrichtAnzeigen(nachricht, typ = 'danger') {
    if (typ === 'success') {
        const erfolgsOverlay = document.getElementById('erfolgsMeldungOverlay');
        const erfolgsText = document.getElementById('erfolgsMeldungText');
        if (!erfolgsOverlay || !erfolgsText) { console.error("Fehler: Erfolgs-Overlay Elemente nicht gefunden."); alert(`Erfolg: ${nachricht}`); return; }
        erfolgsText.textContent = nachricht;
        erfolgsOverlay.classList.add('show');
        if (erfolgsTimeoutId) clearTimeout(erfolgsTimeoutId);
        erfolgsTimeoutId = setTimeout(() => { erfolgsOverlay.classList.remove('show'); erfolgsTimeoutId = null; }, 3000);
    } else {
        const globalFehlerBereich = document.getElementById('globalFehlerBereich');
        const globalFehlerAnzeige = document.getElementById('globalFehlerAnzeige');
        if (!globalFehlerBereich || !globalFehlerAnzeige) { console.error("Fehler: Globaler Nachrichtenbereich nicht gefunden."); alert(`Nachricht (${typ}): ${nachricht}`); return; }
        let klassen = 'p-3 rounded border text-sm ';
        switch (typ) {
            case 'warning': klassen += 'bg-yellow-900 border-yellow-700 text-yellow-200'; break;
            case 'info':    klassen += 'bg-blue-900 border-blue-700 text-blue-200'; break;
            case 'danger': default: klassen += 'bg-red-900 border-red-700 text-red-200'; break;
        }
        globalFehlerAnzeige.innerHTML = `<div class="${klassen}">${nachricht}</div>`;
        globalFehlerBereich.classList.remove('hidden');
    }
}

/**
 * Setzt alle Ergebnis- und Übersichtscontainer zurück.
 */
function alleErgebnisbereicheLeeren() {
    const setzeHtmlSicher = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; else console.warn(`Warnung: Element '${id}' zum Leeren nicht gefunden.`); };
    const setzeTextSicher = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; else console.warn(`Warnung: Element '${id}' zum Leeren nicht gefunden.`); };
    const toggleKlasseSicher = (id, klasse, hinzufügen) => { const el = document.getElementById(id); if (el) el.classList.toggle(klasse, hinzufügen); else console.warn(`Warnung: Element '${id}' zum Klassenwechsel nicht gefunden.`); };
    const setzeInputSicher = (id, wert, disabled, placeholder) => {
        const el = document.getElementById(id);
        if (el) { el.value = wert; el.disabled = disabled; el.placeholder = placeholder; }
        else { console.warn(`Warnung: Input-Element '${id}' zum Zurücksetzen nicht gefunden.`); }
    };
    const standardTexte = holeStandardTexte();

    toggleKlasseSicher('fehlerBereich', 'hidden', true); setzeHtmlSicher('fehlerAnzeige', standardTexte.standardFehlerPlanHtml);
    const fehlerTitel = document.querySelector('#fehlerBereich h3');
    if (fehlerTitel) { fehlerTitel.className = 'text-lg font-semibold mb-3 text-red-400'; fehlerTitel.textContent = 'Fehler/Hinweise in Einteilung'; }

    toggleKlasseSicher('duplikatFehlerBereich', 'hidden', true); setzeHtmlSicher('duplikatFehlerAnzeige', standardTexte.standardDuplikatHtml);
     const duplikatTitel = document.querySelector('#duplikatFehlerBereich h3');
     if (duplikatTitel) { duplikatTitel.className = 'text-lg font-semibold mb-3 text-red-500'; duplikatTitel.textContent = 'Duplikate / Konflikte'; }

    const seitenZahlBereich = document.getElementById('seitenZahlFehlerBereich');
    if (seitenZahlBereich) seitenZahlBereich.classList.add('hidden');

    setzeHtmlSicher('entfernenAnzeige', standardTexte.standardEntfernenHtml);
    setzeHtmlSicher('hinzufuegenAnzeige', standardTexte.standardHinzufuegenHtml);
    setzeHtmlSicher('korrektAnzeige', standardTexte.standardKorrektHtml);
    setzeHtmlSicher('leereSeitenAnzeige', standardTexte.standardLeereSeitenHtml);
    setzeTextSicher('entfernenTotal', ''); setzeTextSicher('hinzufuegenTotal', '');
    setzeHtmlSicher('planUebersichtBereich', standardTexte.standardPlanUebersichtHtml);
    setzeHtmlSicher('indesignUebersichtBereich', standardTexte.standardIndesignUebersichtHtml);
    toggleKlasseSicher('globalFehlerBereich', 'hidden', true); setzeHtmlSicher('globalFehlerAnzeige', '');

    setzeInputSicher('planSucheInput', '', true, 'Laden...'); setzeInputSicher('indesignSucheInput', '', true, 'Laden...');

    const erfolgsOverlay = document.getElementById('erfolgsMeldungOverlay');
    if (erfolgsOverlay && erfolgsOverlay.classList.contains('show')) { erfolgsOverlay.classList.remove('show'); if (erfolgsTimeoutId) { clearTimeout(erfolgsTimeoutId); erfolgsTimeoutId = null; } }
}

/**
 * Liest eine Datei als Text.
 * @param {File} datei - Die zu lesende Datei.
 * @returns {Promise<string>} Ein Promise, das mit dem Dateiinhalt als Text aufgelöst wird.
 */
function dateiAlsTextLesen(datei) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => resolve(event.target.result);
        reader.onerror = (error) => reject(new Error(`Fehler beim Lesen der Datei ${datei.name}: ${error}`));
        reader.readAsText(datei);
    });
}

/**
 * Verarbeitet eine JSON-Datei und gibt die Daten als Array von Objekten zurück.
 * @param {File} datei - Die JSON-Datei.
 * @returns {Promise<object[]>} Ein Promise, das mit den geparsten JSON-Daten aufgelöst wird.
 */
async function jsonLesenUndParsen(datei) {
    const dateiName = datei ? datei.name : 'Unbekannte JSON';
    try {
        const text = await dateiAlsTextLesen(datei);
        const data = JSON.parse(text);
        if (!Array.isArray(data)) {
            throw new Error(`Die JSON-Struktur in "${dateiName}" ist kein Array.`);
        }
        return data;
    } catch (fehler) {
        throw new Error(`Fehler beim Verarbeiten der JSON-Datei "${dateiName}": ${fehler.message}`);
    }
}

/**
 * Liest und parst eine Excel-Datei (XLSX).
 * @param {File} datei - Excel-Datei.
 * @returns {Promise<object[]>} Promise mit Datenobjekten.
 */
function excelLesenUndParsen(datei) {
    return new Promise((resolve, reject) => {
        if (!datei) return reject(new Error("Keine Excel-Datei übergeben."));
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const wb = XLSX.read(e.target.result, { type: 'array', cellDates: true });
                const wsName = wb.SheetNames[0];
                if (!wsName) return reject(new Error(`Datei "${datei.name}" enthält keine Blätter.`));
                const ws = wb.Sheets[wsName];
                const json = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
                let headerIndex = -1;
                for(let i = 0; i < json.length; i++) { if(Array.isArray(json[i]) && json[i].some(cell => cell !== null && cell !== undefined && cell !== '')) { headerIndex = i; break; } }
                if (headerIndex === -1) return reject(new Error(`Keine Header-Zeile in Blatt 1 von "${datei.name}" gefunden.`));
                 const contentRows = json.slice(headerIndex);
                 if (contentRows.length < 1) return reject(new Error(`Blatt 1 in "${datei.name}" enthält keine Zeilen nach dem Header.`));
                 const headers = contentRows[0].map((h, idx) => h ? String(h).trim() : `_EMPTY_${idx}_${Math.random()}`);
                 if (headers.length === 0 || headers.every(h => h.startsWith('_EMPTY_'))) return reject(new Error(`Header-Zeile in "${datei.name}" ist leer oder ungültig.`));
                 const data = contentRows.slice(1).map(r => {
                    if (!Array.isArray(r) || r.length === 0) return null;
                    const obj = {}; let hasValue = false;
                    headers.forEach((h, i) => {
                        if (h && !h.startsWith('_EMPTY_')) {
                            const v = r[i]; let finalValue = v;
                            if (v instanceof Date) { finalValue = v.getFullYear() + '-' + ('0' + (v.getMonth() + 1)).slice(-2) + '-' + ('0' + v.getDate()).slice(-2); }
                            else if (typeof v === 'string') { finalValue = v.trim(); }
                            obj[h] = finalValue;
                            if (finalValue !== null && finalValue !== undefined && finalValue !== '') hasValue = true;
                        }
                    }); return hasValue ? obj : null;
                 }).filter(o => o !== null);
                if (data.length === 0) return reject(new Error(`Keine gültigen Datenzeilen nach dem Header in "${datei.name}" gefunden.`));
                resolve(data);
            } catch (err) { console.error("Excel Parse Fehler:", err); reject(new Error(`Fehler bei Verarbeitung von "${datei.name}". (${err.message})`)); }
        };
        reader.onerror = () => reject(new Error(`Fehler beim Lesen von "${datei.name}".`));
        reader.readAsArrayBuffer(datei);
    });
}

/**
 * Liest und parst eine CSV-Datei.
 * @param {File} datei - CSV-Datei.
 * @param {string} delimiter - Trennzeichen.
 * @returns {Promise<object[]>} Promise mit Datenobjekten.
 */
function csvLesenUndParsen(datei, delimiter) {
     const name = datei ? datei.name : 'Unbekannte CSV';
    return new Promise((resolve, reject) => {
        if (!datei) return reject(new Error("Keine CSV-Datei übergeben."));
        if (typeof window.Papa === 'undefined' || window.Papa === null) {
            console.error("PapaParse (window.Papa) ist nicht verfügbar. Stelle sicher, dass die Bibliothek korrekt geladen wurde.");
            return reject(new Error("PapaParse ist nicht geladen. CSV-Verarbeitung nicht möglich."));
        }
        window.Papa.parse(datei, {
            header: true, skipEmptyLines: 'greedy', delimiter: delimiter, encoding: "UTF-8",
            transformHeader: h => h.trim(),
            complete: (res) => {
                const relevantErrors = res.errors.filter(e => e.code !== 'TooFewFields' && e.code !== 'TooManyFields');
                if (relevantErrors.length > 0) { const firstError = relevantErrors[0]; return reject(new Error(`Parse-Fehler in "${name}": ${firstError.message} (Typ: ${firstError.code}, Zeile: ${firstError.row + 1})`)); }
                if (!res.data || res.data.length === 0) return reject(new Error(`CSV "${name}" ist leer oder enthält nur Header.`));
                const expectedHeaders = ['Produktnummer', 'Seite', 'Format', 'Datei'];
                const actualHeadersLower = res.meta.fields ? res.meta.fields.map(f => f.trim().toLowerCase()) : [];
                const missingHeaders = expectedHeaders.filter(f => !actualHeadersLower.includes(f.toLowerCase()));
                if (missingHeaders.length > 0) return reject(new Error(`Fehlende erforderliche Spalten in CSV "${name}": ${missingHeaders.join(', ')}`));
                const headerMap = {}; const zielSchluessel = ['Produktnummer', 'Seite', 'Format', 'Datei', 'Modell', 'Ebene'];
                zielSchluessel.forEach(zielKey => { const originalHeader = res.meta.fields.find(f => f.trim().toLowerCase() === zielKey.toLowerCase()); if (originalHeader) headerMap[originalHeader] = zielKey; });
                const data = res.data.map(r => {
                    const row = {}; let hasValue = false;
                    zielSchluessel.forEach(zielKey => { const originalHeader = Object.keys(headerMap).find(h => headerMap[h] === zielKey); if (originalHeader && r.hasOwnProperty(originalHeader)) { const v = r[originalHeader]; if (v !== undefined && v !== null) { row[zielKey] = typeof v === 'string' ? v.trim() : v; if (row[zielKey] !== '') hasValue = true; } else { row[zielKey] = ''; } } else { row[zielKey] = ''; } });
                    return hasValue ? row : null;
                }).filter(o => o !== null);
                if (data.length === 0) return reject(new Error(`Keine gültigen Datenzeilen in CSV "${name}" gefunden.`));
                resolve(data);
            }, error: (err) => reject(new Error(`Lesefehler CSV "${name}": ${err.message}`))
        });
    });
}

/**
 * Allgemeine Funktion zum Lesen und Parsen einer Datei basierend auf ihrer Erweiterung.
 * @param {File} datei - Die zu verarbeitende Datei.
 * @param {string} csvDelimiter - Das Trennzeichen für CSV-Dateien.
 * @returns {Promise<object[]>} Ein Promise mit den geparsten Daten.
 */
function dateiLesenUndParsen(datei, csvDelimiter = ';') {
    const dateiName = datei.name.toLowerCase();
    if (dateiName.endsWith('.csv')) {
        return csvLesenUndParsen(datei, csvDelimiter);
    } else if (dateiName.endsWith('.json')) {
        return jsonLesenUndParsen(datei);
    } else {
        return Promise.reject(new Error(`Nicht unterstützter Dateityp: ${datei.name}. Bitte lade eine .csv oder .json Datei hoch.`));
    }
}

/**
 * Erstellt eine HTML-Tabelle mit Tooltips für bestimmte Fehler und Status-Tags.
 * Fügt den [Seitenzahl]-Tag zur Status-Spalte der Korrekt-Tabelle hinzu.
 * @param {object[]} datenArray - Array der Datenobjekte.
 * @param {string[]} spalten - Schlüssel (Spaltennamen).
 * @param {object} spaltenTitel - Mapping Schlüssel zu Titel.
 * @param {boolean} [zeigeGrundSpalte=false] - 'Grund'-Spalte anzeigen?
 * @param {'entfernen'|'hinzufuegen'|'korrekt'|'fehlerPlan'|'duplikat'|'fehlend'|'leereSeiten'} [tabelleTyp='korrekt'] - Typ der Tabelle für CSS-Styling und Tooltip-Logik.
 * @returns {{tabelle: HTMLTableElement | null}} - Tabellenelement.
 */
 function tabelleErstellen(datenArray, spalten, spaltenTitel, zeigeGrundSpalte = false, tabelleTyp = 'korrekt') {
    if (!Array.isArray(datenArray) || datenArray.length === 0 || !Array.isArray(spalten) || typeof spaltenTitel !== 'object') {
        return { tabelle: null };
    }

    const tabelle = document.createElement('table');
    tabelle.className = `min-w-full divide-y ${tabelleTyp}-table`;

    const thead = tabelle.createTHead();
    const kopfZeile = thead.insertRow();
    spalten.forEach(key => {
        if (key === 'grund' && !zeigeGrundSpalte) return;
        const th = document.createElement('th'); th.scope = 'col';
        th.textContent = spaltenTitel[key] || key; kopfZeile.appendChild(th);
    });

    const tbody = tabelle.createTBody();
    let gesamtFormatSumme = 0; let seitenFormatSumme = 0;

    datenArray.forEach(item => {
        if (typeof item !== 'object' || item === null) return;

        const zeile = tbody.insertRow();
        zeile.classList.add(`${tabelleTyp}-row`);
        let hatFormatAbweichung = false;

        if (tabelleTyp === 'korrekt' && typeof item.gesamtFormat === 'number' && typeof item.seitenFormat === 'number' && item.gesamtFormat !== item.seitenFormat) {
            hatFormatAbweichung = true; zeile.classList.add('format-abweichung-zeile');
        } else if (tabelleTyp === 'entfernen' && item.grund === 'Flugblatt (Plan)') {
            zeile.classList.add('flugblatt-row');
        } else if (tabelleTyp === 'korrekt' && item.istDoppelseite) {
             zeile.classList.add('doppelseite-row');
        } else if (tabelleTyp === 'fehlerPlan' && item.typ === 'Übereinstimmende Daten') {
             zeile.classList.add('identische-daten-zeile');
        } else if (tabelleTyp === 'fehlerPlan' && item.typ === 'Konfigurationsfehler') {
            zeile.classList.add('konfig-fehler-zeile');
        } else if (tabelleTyp === 'duplikat') {
            zeile.classList.add('duplikat-row');
        }

        spalten.forEach(key => {
            if (key === 'grund' && !zeigeGrundSpalte) return;
            const zelle = zeile.insertCell();
            let wert = item.hasOwnProperty(key) ? item[key] : '';
            if (wert === null || wert === undefined) wert = '';
            let tooltipText = '';

            if (tabelleTyp === 'fehlerPlan' && key === 'typ') { switch (item.typ) { case 'Ungültiges Format (keine Zahl)': tooltipText = "Der Wert in der Spalte 'Format' in der Eintheilung-Datei ist keine gültige Zahl."; break; case 'Ungültige Format-Summe': tooltipText = "Die Summe der 'Format'-Werte für diese Kataloggruppe in der Eintheilung ist nicht 0.5, 1 oder 2."; break; case 'Übereinstimmende Daten': tooltipText = "Diese Zeile hat in den relevanten Spalten identische Werte wie mindestens eine andere Zeile in der Eintheilung."; break; case 'Konfigurationsfehler': tooltipText = "Ein Konfigurationsproblem ist aufgetreten (z.B. fehlende Spalten für Duplikatsprüfung)."; break; } } else if (tabelleTyp === 'duplikat' && key === 'typ') { switch (item.typ) { case 'Duplikat im Katalog': tooltipText = "Diese Produktnummer wurde auf mehreren Seiten im InDesign-Export gefunden."; break; case 'Konflikt: Katalog & Flugblatt': case 'Konflikt: Flugblatt & Katalog': tooltipText = "Produkt ist in Eintheilung und/oder InDesign widersprüchlich als Katalog- und Flugblattartikel definiert."; break; } } else if (tabelleTyp === 'korrekt' && hatFormatAbweichung && (key === 'gesamtFormat' || key === 'seitenFormat')) { tooltipText = "Das berechnete 'Seitenformat' (aus InDesign) stimmt nicht mit dem 'Eintheilung'-Format überein."; }

            if (key === 'status' && tabelleTyp === 'korrekt') {
                let statusHTML = '';

                if (item.istTitel) {
                    const titelKorrekt = item.titelPositionKorrekt;
                    const titelClass = titelKorrekt ? 'titel-tag-korrekt' : 'titel-tag-fehler';
                    const titelTooltip = titelKorrekt ?
                        'Die Seite ist an der richtigen Position, aber achte auf das richtige Format!' :
                        'Die Seite ist an der falschen Position. Achte auf das richtige Format!';
                    statusHTML += `<span class="${titelClass}" title="${titelTooltip}">[Titel]</span> `;
                }

                if (item.istRueckseite) {
                    const rueckseiteKorrekt = item.rueckseitePositionKorrekt;
                    const rueckseiteClass = rueckseiteKorrekt ? 'rueckseite-tag-korrekt' : 'rueckseite-tag-fehler';
                    const rueckseiteTooltip = rueckseiteKorrekt ?
                        'Die Seite ist an der richtigen Position, aber achte auf das richtige Format!' :
                        'Die Seite ist an der falschen Position. Achte auf das richtige Format!';
                    statusHTML += `<span class="${rueckseiteClass}" title="${rueckseiteTooltip}">[Rückseite]</span> `;
                }

                if (item.istDoppelseite) statusHTML += '<span class="doppel-tag" title="Diese Kataloggruppe repräsentiert eine Doppelseite.">[Doppel]</span> ';
                if (hatFormatAbweichung) statusHTML += '<span class="fehler-tag" title="Das Seitenformat aus InDesign weicht vom Format in der Eintheilung ab.">[Formatabweichung]</span> ';
                if (item.hatSeitenZahlFehler) {
                    statusHTML += '<span class="seitenzahl-fehler-tag" title="Seitenzahl-Abweichung zwischen Katalog Einteilung und Katalogseiten.">[Seitenzahl]</span> ';
                }
                zelle.innerHTML = statusHTML.trim(); zelle.classList.add('text-center');
            } else {
                if (tooltipText) { zelle.setAttribute('title', tooltipText); }
                if ((key === 'gesamtFormat' || key === 'seitenFormat' || key === 'format') && typeof wert === 'number') {
                     if (key === 'gesamtFormat' && (tabelleTyp === 'hinzufuegen' || tabelleTyp === 'korrekt')) gesamtFormatSumme += wert;
                     if (key === 'seitenFormat' && tabelleTyp === 'korrekt') seitenFormatSumme += wert;
                     wert = wert.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
                     zelle.classList.add('text-right', 'font-mono');
                     if (hatFormatAbweichung && (key === 'gesamtFormat' || key === 'seitenFormat')) zelle.classList.add('format-abweichung-wert');
                }
                else if (key === 'seite' && wert === '' && tabelleTyp === 'hinzufuegen') { wert = '-'; zelle.classList.add('text-center', 'text-gray-500'); }
                else if (key === 'grund' && zeigeGrundSpalte) { }
                else if (['katalogGruppe', 'produktNummer', 'fehlerQuelle', 'fehlerWert', 'details', 'seiten', 'planGruppe'].includes(key)) {
                    zelle.classList.add('break-words'); zelle.style.whiteSpace = 'normal';
                    if (key === 'fehlerWert' && tabelleTyp === 'fehlerPlan' && item.typ === 'Übereinstimmende Daten') zelle.classList.add('identische-daten-wert');
                }
                else if (key === 'typ' && tabelleTyp === 'duplikat' && wert.startsWith('Konflikt')) zelle.classList.add('font-bold');
                else if (key === 'typ' && tabelleTyp === 'fehlerPlan') { if (wert === 'Übereinstimmende Daten') zelle.classList.add('font-semibold', 'text-yellow-300'); else if (wert === 'Konfigurationsfehler') zelle.classList.add('font-semibold', 'text-purple-300'); else zelle.classList.add('font-semibold', 'text-red-400'); }

                if (key === 'grund' && zeigeGrundSpalte) {
                    if (wert === 'Flugblatt (Plan)') zelle.classList.add('text-orange-400', 'font-medium');
                    else if (wert === 'Nicht in Einteilung') {
                        zelle.classList.add('text-red-400');
                        if (item.istInFlugblatt) {
                            const flugblattTag = '<span class="flugblatt-tag" title="Lösche die Seite aus dem Katalog und platziere sie in den Flugblättern.">[Flugblatt]</span>';
                            zelle.innerHTML = wert + ' ' + flugblattTag;
                        } else {
                            zelle.textContent = wert;
                        }
                    }
                    else if (wert.includes('Formatfehler') || wert.includes('Format 0')) zelle.classList.add('text-red-500');
                    else if (wert.includes('Konflikt/Duplikat')) zelle.classList.add('text-yellow-400');
                }

                if (key === 'seiten' && tabelleTyp === 'duplikat') zelle.innerHTML = wert;
                else zelle.textContent = wert;
            }
        });
    });

    let showSumRow = (tabelleTyp !== 'korrekt' && tabelleTyp !== 'hinzufuegen' && ((spalten.includes('gesamtFormat') && gesamtFormatSumme > 0) || (spalten.includes('seitenFormat') && seitenFormatSumme > 0)));

    if (showSumRow) {
        const totalZeile = tbody.insertRow(); totalZeile.className = 'total-row';
        let summenZellenAnzahl = 0;
        spalten.forEach(key => {
            if (key === 'grund' && !zeigeGrundSpalte) return;
            const zelle = totalZeile.insertCell(); let istSummenZelle = false;
            if (key === 'gesamtFormat' && tabelleTyp !== 'entfernen' && gesamtFormatSumme > 0) { zelle.textContent = gesamtFormatSumme.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }); zelle.classList.add('text-right', 'font-mono'); summenZellenAnzahl++; istSummenZelle = true; }
            else if (key === 'seitenFormat' && tabelleTyp === 'korrekt' && seitenFormatSumme > 0) { zelle.textContent = seitenFormatSumme.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }); zelle.classList.add('text-right', 'font-mono'); summenZellenAnzahl++; istSummenZelle = true; }
             if (!istSummenZelle) { zelle.textContent = ''; }
        });
        if (totalZeile.cells.length > 0) {
            const ersteZelle = totalZeile.cells[0]; ersteZelle.textContent = 'Gesamt:'; ersteZelle.classList.add('text-left');
            const sichtbareSpaltenAnzahl = spalten.filter(key => !(key === 'grund' && !zeigeGrundSpalte)).length;
            const colSpanValue = Math.max(1, sichtbareSpaltenAnzahl - summenZellenAnzahl);
             ersteZelle.colSpan = colSpanValue;
             while (totalZeile.cells.length > summenZellenAnzahl + 1) totalZeile.deleteCell(1);
        }
    }

    return { tabelle };
}

function holeStandardTexte() {
    return {
        standardTextHtml: '<div class="standard-text">Keine Einträge in dieser Kategorie.</div>',
        standardFehlendHtml: '<div class="standard-text">Keine leeren Seiten im Katalog gefunden.</div>',
        standardDuplikatHtml: '<div class="standard-text">Keine Duplikate oder Zuordnungsfehler gefunden.</div>',
        standardFehlerPlanHtml: '<div class="standard-text">Keine Fehler oder Hinweise in den Einteilungsdaten gefunden.</div>',
        standardEntfernenHtml: '<div class="standard-text">Keine Seiten zum Entfernen identifiziert.</div>',
        standardHinzufuegenHtml: '<div class="standard-text">Keine hinzuzufügenden Seiten identifiziert.</div>',
        standardKorrektHtml: '<div class="standard-text">Keine korrekten Seiten identifiziert.</div>',
        standardLeereSeitenHtml: '<div class="standard-text">Keine leeren Seiten im InDesign Export gefunden.</div>',
        standardPlanUebersichtHtml: '<p class="text-gray-400 italic text-sm">Eintheilung-Daten werden nach dem Vergleich hier angezeigt.</p>',
        standardIndesignUebersichtHtml: '<p class="text-gray-400 italic text-sm">InDesign-Daten werden nach dem Vergleich hier angezeigt.</p>'
    };
}

console.log("utils.js v.1.19 geladen.");