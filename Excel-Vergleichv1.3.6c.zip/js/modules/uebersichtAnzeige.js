// js/modules/uebersichtAnzeige.js - v1.3.0 - Übersichts-Anzeige für Plan und InDesign
console.log("Lade uebersichtAnzeige.js v1.3.0...");

/**
 * Filtert und zeigt die Einteilung-Übersicht an, inklusive Gesamt-Summen an korrekten Positionen.
 * Nutzt globalePlanMap. Berücksichtigt [Fehler] Tags.
 * @param {string} suchBegriff - Der aktuelle Suchbegriff aus dem Input-Feld.
 */
window.filterAndDisplayPlanOverview = function(suchBegriff) {
    if (!planUebersichtBereich) {
        console.error("Fehler: Plan-Übersichts-Container nicht gefunden.");
        return;
    }

    const standardText = '<p class="text-gray-400 italic text-sm">Keine passenden Einteilung-Daten gefunden.</p>';
    const suchBegriffLower = suchBegriff.toLowerCase().trim();

    const gefiltertePlanDaten = new Map();
    if (suchBegriffLower === '') {
        globalePlanMap.forEach((value, key) => gefiltertePlanDaten.set(key, value));
    } else {
        globalePlanMap.forEach((eintrag, gruppe) => {
            let match = false;
            if (String(gruppe).toLowerCase().includes(suchBegriffLower) || (eintrag.modell && eintrag.modell.toLowerCase().includes(suchBegriffLower))) {
                match = true;
            } else if (eintrag.artikel && eintrag.artikel.length > 0) {
                 for (const artikelZeile of eintrag.artikel) {
                     for (const key in artikelZeile) {
                         if (artikelZeile.hasOwnProperty(key) && artikelZeile[key] !== null && artikelZeile[key] !== undefined) {
                             if (String(artikelZeile[key]).toLowerCase().includes(suchBegriffLower)) {
                                 match = true;
                                 break;
                             }
                         }
                     }
                     if (match) break;
                 }
            }
            if (match) {
                gefiltertePlanDaten.set(gruppe, eintrag);
            }
        });
    }

    planUebersichtBereich.innerHTML = '';
    const planUl = document.createElement('ul');
    planUl.className = 'list-none text-sm space-y-1';

    let titelItem=null, rueckseiteItem=null;
    const regulaer=[], flugblattItems=[];
    let gesamtFormatKatalog = 0;
    let gesamtFormatFlugblatt = 0;

    gefiltertePlanDaten.forEach((e, g) => {
         const formatValue = (typeof e.gesamtFormat === 'number' && !isNaN(e.gesamtFormat)) ? e.gesamtFormat : 0;
         const d={
             g, m:e.modell||'-', f:formatValue,
             fl:e.istFlugblatt, fe:e.formatFehler, db:e.istDoppelseite,
             s:e.ersteSeiteNum,
             fehlerNichtInId: e.fehlerNichtInId // Fehler, wenn Eintrag im Plan, aber nicht in ID
            };
         if(d.fl) {
             flugblattItems.push(d);
             gesamtFormatFlugblatt += d.f;
         } else {
             gesamtFormatKatalog += d.f;
             if(!isNaN(d.s) && d.s === 1) titelItem = d;
             else if (!isNaN(d.s) && d.s === globaleMaxPlanSeiteFuerRueckseite && globaleMaxPlanSeiteFuerRueckseite > 1) rueckseiteItem = d;
             else regulaer.push(d);
         }
    });

    const regulaerOhneR = regulaer.filter(item => item !== rueckseiteItem);
    const sortFn = (a,b) => String(a.g).localeCompare(String(b.g), 'de', {numeric:true});
    regulaerOhneR.sort(sortFn);
    flugblattItems.sort(sortFn);
    const katalogItems = [...(titelItem ? [titelItem] : []), ...regulaerOhneR, ...(rueckseiteItem ? [rueckseiteItem] : [])];

    if (katalogItems.length === 0 && flugblattItems.length === 0) {
        planUebersichtBereich.innerHTML = standardText;
        return;
    }

    let lastAppendedLi = null;

    katalogItems.forEach(i => {
        const li = document.createElement('li');
        li.className = 'flex justify-between items-baseline pb-1 border-b border-slate-700';
        let tagHtml = '';
        if(i === titelItem) tagHtml =' <span class="titel-tag">[Titel]</span>';
        else if(i === rueckseiteItem) tagHtml =' <span class="rueckseite-tag">[Rückseite]</span>';

        let statusHtml = '';
        if(i.db) statusHtml+=' <span class="doppel-tag">[Doppel]</span>';
        if(i.fe) statusHtml+=' <span class="fehler-tag">[FEHLER!]</span>';
        if(i.fehlerNichtInId) statusHtml+=' <span class="fehler-tag" title="Eintrag fehlt im InDesign Export">[Fehlt in InDesign]</span>';

        const leftContent = `<span class="font-medium text-gray-200">${i.g}:</span> <span class="text-gray-300">${i.m}</span>${tagHtml}${statusHtml}`;
        const rightContent = `Format: ${i.f.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}`;
        li.innerHTML = `<span class="pr-2">${leftContent}</span><span class="text-right font-mono text-gray-400 whitespace-nowrap">${rightContent}</span>`;
        planUl.appendChild(li);
        lastAppendedLi = li;
    });

    if (gesamtFormatKatalog > 0 || katalogItems.length > 0) {
        const katalogGesamtLi = document.createElement('li');
        katalogGesamtLi.className = 'plan-katalog-summary-row';
        katalogGesamtLi.innerHTML = `Gesamt Katalog: <span class="font-mono">${gesamtFormatKatalog.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}</span>`;
        planUl.appendChild(katalogGesamtLi);
        lastAppendedLi = katalogGesamtLi;
    }

    flugblattItems.forEach(i => {
        const li = document.createElement('li');
        li.className = 'flex justify-between items-baseline pb-1 border-b border-slate-700';
        let tagHtml = ' <span class="flugblatt-markierung">[Flugblatt]</span>';
        let statusHtml = '';
        if(i.fe) statusHtml+=' <span class="fehler-tag">[FEHLER!]</span>';
        if(i.fehlerNichtInId) statusHtml+=' <span class="fehler-tag" title="Eintrag fehlt im InDesign Export">[Fehlt in InDesign]</span>';
        const leftContent = `<span class="font-medium text-gray-200">${i.g}:</span> <span class="text-gray-300">${i.m}</span>${tagHtml}${statusHtml}`;
        const rightContent = `Format: ${i.f.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}`;
        li.innerHTML = `<span class="pr-2">${leftContent}</span><span class="text-right font-mono text-gray-400 whitespace-nowrap">${rightContent}</span>`;
        planUl.appendChild(li);
        lastAppendedLi = li;
    });

    if (gesamtFormatFlugblatt > 0 || flugblattItems.length > 0) {
        const flugblattGesamtLi = document.createElement('li');
        flugblattGesamtLi.className = 'plan-flugblatt-summary-row';
        flugblattGesamtLi.innerHTML = `Gesamt Flugblatt: <span class="font-mono">${gesamtFormatFlugblatt.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}</span>`;
        planUl.appendChild(flugblattGesamtLi);
        lastAppendedLi = flugblattGesamtLi;
    }

    if (lastAppendedLi && (lastAppendedLi.classList.contains('plan-katalog-summary-row') || lastAppendedLi.classList.contains('plan-flugblatt-summary-row'))) {
         if (katalogItems.length > 0 && flugblattItems.length > 0) {
             lastAppendedLi.classList.add('plan-final-summary-styling');
         } else {
             lastAppendedLi.style.borderTop = '1px solid #334155';
         }
         lastAppendedLi.classList.remove('plan-katalog-summary-row');
         lastAppendedLi.classList.remove('plan-flugblatt-summary-row');
    }
    planUebersichtBereich.appendChild(planUl);
};

/**
 * Filtert und zeigt die InDesign-Übersicht an.
 * Nutzt globaleInDesignSeitenMap und iteriert durch rohdatenZeilen für separate Anzeige.
 * Dedupliziert Einträge basierend auf Seite, Datei und Produktnummer (Ebene wird ignoriert).
 * Zeigt "FEHLER: Datei nicht gefunden" spezifisch an.
 * @param {string} suchBegriff - Der aktuelle Suchbegriff aus dem Input-Feld.
 */
window.filterAndDisplayIndesignOverview = function(suchBegriff) {
    if (!indesignUebersichtBereich) {
        console.error("Fehler: InDesign-Übersichts-Container nicht gefunden.");
        return;
    }

    const standardText = '<p class="text-gray-400 italic text-sm">Keine passenden InDesign-Daten gefunden.</p>';
    const suchBegriffLower = suchBegriff.toLowerCase().trim();
    let hatErgebnisse = false;

    const indesignUl = document.createElement('ul');
    const sortedSeiten = Array.from(globaleInDesignSeitenMap.keys()).sort((a,b) => {
        const nA=parseInt(a,10), nB=parseInt(b,10);
        return !isNaN(nA) && !isNaN(nB) ? nA-nB : String(a).localeCompare(String(b));
    });

    indesignUebersichtBereich.innerHTML = '';

    sortedSeiten.forEach(s => { // 's' ist die Seitenzahl als String
        const seitenEintragGesamt = globaleInDesignSeitenMap.get(s); // Der gesamte Eintrag für die Seite 's'
        if (!seitenEintragGesamt || !seitenEintragGesamt.rohdatenZeilen || seitenEintragGesamt.rohdatenZeilen.length === 0) return;

        const displayedEntriesThisPage = new Set();

        seitenEintragGesamt.rohdatenZeilen.forEach(rohZeile => {
            const prodNr = rohZeile.Produktnummer?.toString().trim() || '';
            const datei = rohZeile.Datei?.trim() || '';
            const formatAnzeige = rohZeile.Format?.toString().trim() || ''; // Format aus Rohdaten für Anzeige
            const ebene = rohZeile.Ebene?.trim() || '';

            // DATEI-BASIERTE DEDUPLIZIERUNG: Nur Datei als Schlüssel verwenden
            const entryKey = `${s}_${datei}`; // Eindeutiger Schlüssel basierend auf Seite und Datei

            if (displayedEntriesThisPage.has(entryKey)) {
                return; // Datei wurde bereits für diese Seite angezeigt
            }

            let zeileMatch = false;
            if (prodNr || datei) { // Nur Zeilen mit Produktnummer oder Datei anzeigen
                 if (suchBegriffLower === '') {
                     zeileMatch = true;
                 } else {
                     if (s.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && prodNr.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && datei.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && formatAnzeige.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && rohZeile.Modell?.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && ebene.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                 }
            }

            if (zeileMatch) {
                hatErgebnisse = true;
                displayedEntriesThisPage.add(entryKey);

                // BESTIMME DIE KATALOGGRUPPIERUNG (KLEINSTE PRODUKTNUMMER) FÜR DIESE DATEI
                const alleProduktNummernFuerDatei = seitenEintragGesamt.rohdatenZeilen
                    .filter(z => z.Datei?.trim() === datei)
                    .map(z => z.Produktnummer?.toString().trim())
                    .filter(pn => pn && pn !== '')
                    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

                // Kataloggruppierung = kleinste (erste) Produktnummer
                const kataloggruppierung = alleProduktNummernFuerDatei.length > 0 ? alleProduktNummernFuerDatei[0] : '';

                const li = document.createElement('li');
                const anzeigeSpan = document.createElement('span'); // Haupt-Span für linke Seite

                if (prodNr === "FEHLER: Datei nicht gefunden") {
                    anzeigeSpan.innerHTML = `<span class="seite-text">Seite ${s}</span> - <span class="datei-text-id">${datei || 'Unbekannte Datei'}</span>: <span class="fehler-text-rot">${prodNr}</span>`;
                    const fehlerFormatSpan = document.createElement('span');
                    fehlerFormatSpan.className = 'format-text-id-fehler';
                    fehlerFormatSpan.textContent = 'Format: N/A';
                    li.appendChild(anzeigeSpan);
                    li.appendChild(fehlerFormatSpan);
                } else {
                    // ZEIGE NUR DIE KATALOGGRUPPIERUNG (KLEINSTE PRODUKTNUMMER)
                    const nummernText = kataloggruppierung ? `(${kataloggruppierung})` : '(Keine ProdNr)';
                    anzeigeSpan.innerHTML = `<span class="seite-text">Seite ${s}</span> <span class="nummern-text">${nummernText}</span>`;
                    li.appendChild(anzeigeSpan);

                    const fS = document.createElement('span');
                    let formatText = 'Format: -';
                    try {
                        const formatNum = parseFloat(formatAnzeige.replace(',', '.'));
                        if (!isNaN(formatNum)) {
                            formatText = `Format: ${formatNum.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}`;
                        } else if (formatAnzeige) {
                             formatText = `Format: ${formatAnzeige}`;
                        }
                    } catch (parseError) {
                         if (formatAnzeige) formatText = `Format: ${formatAnzeige}`;
                    }
                    fS.textContent = formatText;
                    li.appendChild(fS);
                }

                // Tooltip für alle Zeilen setzen (auch Fehlerzeilen)
                let tooltipDetails = [];
                if (ebene) tooltipDetails.push(`Ebene: ${ebene}`);
                // Für Fehlerzeilen könnte man den Tooltip anpassen oder spezifischer gestalten
                if (prodNr === "FEHLER: Datei nicht gefunden") {
                    tooltipDetails.push(`Datei: ${datei || 'Unbekannt'} - Gemeldeter Fehler`);
                } else {
                    // ZEIGE KATALOGGRUPPIERUNG UND ALLE PRODUKTNUMMERN IM TOOLTIP
                    if (kataloggruppierung) {
                        tooltipDetails.push(`Kataloggruppierung: ${kataloggruppierung}`);
                    }
                    if (alleProduktNummernFuerDatei.length > 1) {
                        tooltipDetails.push(`Alle Produkte: ${alleProduktNummernFuerDatei.join(', ')}`);
                    }
                    if (datei) tooltipDetails.push(`Datei: ${datei}`);
                }
                anzeigeSpan.title = tooltipDetails.join(' | ');

                indesignUl.appendChild(li);
            }
        });
    });

    if (hatErgebnisse) {
        indesignUebersichtBereich.appendChild(indesignUl);
    } else {
        indesignUebersichtBereich.innerHTML = standardText;
    }
};

console.log("uebersichtAnzeige.js v1.3.0 geladen.");
