// js/modules/tabellenAnzeige.js - v1.3.1 - Tabellen-Anzeige und Ergebnisdarstellung
console.log("Lade tabellenAnzeige.js v1.3.1...");

/**
 * Hilfsfunktion zum Anzeigen einer Tabelle im Ergebnisbereich.
 */
function zeigeTabelle(container, bereichContainer, daten, spalten, titelMap, typ, standardTextFallback, zeigeGrund = false, transformFunc = null, alwaysShowContainer = false) {
    if (!container || !bereichContainer) {
        console.warn(`Container oder BereichsContainer für ${typ} nicht gefunden.`);
        return false;
    }

    const standardTexte = holeStandardTexte();
    const fallbackHtml = standardTextFallback || standardTexte[`standard${typ.charAt(0).toUpperCase() + typ.slice(1)}Html`] || standardTexte.standardTextHtml;

    if (daten && daten.length > 0) {
        const datenFuerTabelle = transformFunc ? daten.map(transformFunc) : daten;

        if (typ === 'fehlerPlan') {
            datenFuerTabelle.sort((a, b) => {
                const zeileA = parseInt(a.fehlerQuelle?.match(/Zeile (\d+)/)?.[1], 10);
                const zeileB = parseInt(b.fehlerQuelle?.match(/Zeile (\d+)/)?.[1], 10);
                if (!isNaN(zeileA) && !isNaN(zeileB)) return zeileA - zeileB;
                else if (!isNaN(zeileA)) return -1;
                else if (!isNaN(zeileB)) return 1;
                else {
                    const typCompare = (a.typ || '').localeCompare(b.typ || '');
                    if (typCompare !== 0) return typCompare;
                    return (a.fehlerQuelle || '').localeCompare(b.fehlerQuelle || '');
                }
            });
        }

        const { tabelle } = tabelleErstellen(datenFuerTabelle, spalten, titelMap, zeigeGrund, typ);

        if (tabelle) {
            container.innerHTML = '';
            const div = document.createElement('div');
            div.className = 'table-container';
            const titelElement = bereichContainer.querySelector('h3');

            if (typ === 'fehlerPlan' || typ === 'duplikat') {
                const hatEchteFehler = datenFuerTabelle.some(f => f.typ !== 'Konfigurationsfehler' && f.typ !== 'Übereinstimmende Daten');
                const hatUebereinstimmung = datenFuerTabelle.some(f => f.typ === 'Übereinstimmende Daten');
                const hatKonfigFehler = datenFuerTabelle.some(f => f.typ === 'Konfigurationsfehler');

                if (hatEchteFehler || (typ === 'duplikat' && datenFuerTabelle.length > 0)) {
                    div.classList.add('border-red-700');
                    if (titelElement) {
                        titelElement.className = 'text-lg font-semibold mb-3 text-red-500';
                        titelElement.textContent = typ === 'duplikat' ? 'Duplikate / Konflikte' : 'Fehler in Einteilung-Daten';
                    }
                } else if (hatUebereinstimmung) {
                    div.classList.add('border-yellow-700');
                    if (titelElement) {
                        titelElement.className = 'text-lg font-semibold mb-3 text-yellow-400';
                        titelElement.textContent = 'Hinweise in Einteilung-Daten';
                    }
                } else if (hatKonfigFehler) {
                    div.classList.add('border-purple-700');
                    if (titelElement) {
                        titelElement.className = 'text-lg font-semibold mb-3 text-purple-400';
                        titelElement.textContent = 'Konfigurations-Hinweise';
                    }
                } else if (titelElement) {
                    titelElement.className = 'text-lg font-semibold mb-3 text-gray-400';
                    titelElement.textContent = 'Informationen zur Einteilung';
                }
            }

            if (typ === 'seitenzahlAbweichungen') {
                div.classList.add('border-orange-700');
                if (titelElement) {
                    titelElement.className = 'text-lg font-semibold mb-3 text-orange-400';
                    titelElement.textContent = 'Seitenzahl-Abweichungen (Sortierte Einteilung)';
                }
            }

            div.appendChild(tabelle);
            container.appendChild(div);
            bereichContainer.classList.remove('hidden');
            return true;
        } else {
            container.innerHTML = fallbackHtml;
            if (!alwaysShowContainer) {
                bereichContainer.classList.add('hidden');
            } else {
                bereichContainer.classList.remove('hidden');
            }
        }
    } else {
        container.innerHTML = fallbackHtml;
        if (!alwaysShowContainer) {
            bereichContainer.classList.add('hidden');
        } else {
            bereichContainer.classList.remove('hidden');
        }
    }
    return false;
}

/**
 * Zeigt Vergleichsergebnisse an.
 */
window.ergebnisseAnzeigen = function(ergebnisse, fehlerListePlan) {
    const elementeExistieren = [
        fehlerBereich, fehlerAnzeige, entfernenAnzeige, hinzufuegenAnzeige, korrektAnzeige,
        leereSeitenAnzeige, entfernenTotal, hinzufuegenTotal, duplikatFehlerBereich,
        duplikatFehlerAnzeige, korrektSpeichernButton
    ].every(el => el !== null);

    const seitenzahlAbweichungBereich = document.getElementById('seitenzahlAbweichungBereich');
    const seitenzahlAbweichungAnzeige = document.getElementById('seitenzahlAbweichungAnzeige');

    if (!elementeExistieren) {
        console.error("Fehler: Einige Ergebnis-Container-Elemente nicht im DOM gefunden.");
        return;
    }

    const { standardTextHtml, standardFehlendHtml, standardDuplikatHtml } = holeStandardTexte();

    fehlerBereich.classList.add('hidden');
    fehlerAnzeige.innerHTML = '';
    duplikatFehlerBereich.classList.add('hidden');
    duplikatFehlerAnzeige.innerHTML = standardDuplikatHtml;

    if (seitenzahlAbweichungBereich) seitenzahlAbweichungBereich.classList.add('hidden');
    if (seitenzahlAbweichungAnzeige) seitenzahlAbweichungAnzeige.innerHTML = '';

    entfernenAnzeige.innerHTML = standardTextHtml;
    hinzufuegenAnzeige.innerHTML = standardTextHtml;
    korrektAnzeige.innerHTML = standardTextHtml;
    entfernenTotal.textContent = '';
    hinzufuegenTotal.textContent = '';
    globaleKorrekteDaten = [];
    korrektSpeichernButton.disabled = true;

    const { zuEntfernen, hinzuzufuegen, korrekt, duplikatFehler, seitenzahlAbweichungen, leereSeiten } = ergebnisse;
    globaleKorrekteDaten = korrekt;

    const spaltenTitel = {
        seite:'Seite', katalogGruppe:'Gruppe/Nr.', modell:'Modell', produktNummer:'Produktnr.',
        gesamtFormat:'Format', seitenFormat:'Format', grund:'Grund', status:'Status',
        typ:'Fehlertyp', seiten:'Betroffene Seiten', details:'Details',
        fehlerQuelle: 'Quelle', fehlerWert: 'Details/Wert', format:'Format',
        planSeite: 'Plan Seite', korrektSeite: 'Korrekt Seite', abweichung: 'Abweichung', fehler: 'Fehler'
    };

    const spaltenEntfernen = ['seite', 'katalogGruppe', 'modell', 'grund', 'seitenFormat'];
    const spaltenHinzufuegen = ['seite', 'katalogGruppe', 'modell', 'gesamtFormat'];
    
    const spaltenKorrekt = globalePhase === 'SORTIERT'
        ? ['seite', 'katalogGruppe', 'modell', 'status', 'seitenFormat', 'planSeite']
        : ['seite', 'katalogGruppe', 'modell', 'status', 'seitenFormat'];
        
    const spaltenDuplikatFehler = ['produktNummer', 'typ', 'seiten', 'details'];
    const spaltenFehlerPlan = ['typ', 'fehlerQuelle', 'modell', 'fehlerWert'];
    const spaltenLeereSeiten = ['seite', 'katalogGruppe', 'modell', 'format'];
    const spaltenSeitenzahlAbweichungen = ['katalogGruppe', 'modell', 'planSeite', 'korrektSeite', 'abweichung'];

    zeigeTabelle(duplikatFehlerAnzeige, duplikatFehlerBereich, duplikatFehler, spaltenDuplikatFehler, spaltenTitel, 'duplikat', standardDuplikatHtml);

    zeigeTabelle(fehlerAnzeige, fehlerBereich, fehlerListePlan, spaltenFehlerPlan, spaltenTitel, 'fehlerPlan', standardTextHtml, false, f => ({
        typ: f.typ || '-',
        fehlerQuelle: f.zeile !== undefined && f.zeile !== 'N/A' ? `Zeile ${f.zeile}` : (f.gruppe !== undefined ? `Gruppe ${f.gruppe}` : '-'),
        modell: f.modell || '-',
        fehlerWert: f.summe !== undefined ? `Summe: ${f.summe.toLocaleString('de-DE')} (Erw: ${f.erwartet})` : (f.wert !== undefined ? `${f.wert}` : '-')
    }));

    const transformierteLeereSeiten = leereSeiten.map(item => ({
        seite: item.seite,
        katalogGruppe: '-',
        modell: item.typ === 'vollständig leer' ? 'Ganze Seite leer' : 'Teilweise leer',
        format: item.verfuegbaresFormat
    }));

    zeigeTabelle(leereSeitenAnzeige, document.getElementById('leereSeitenBereich'), transformierteLeereSeiten, spaltenLeereSeiten, spaltenTitel, 'leereSeiten', standardFehlendHtml, false, null, true);
    zeigeTabelle(entfernenAnzeige, document.getElementById('entfernenBereich'), zuEntfernen, spaltenEntfernen, spaltenTitel, 'entfernen', standardTextHtml, true);
    zeigeTabelle(hinzufuegenAnzeige, document.getElementById('hinzufuegenBereich'), hinzuzufuegen, spaltenHinzufuegen, spaltenTitel, 'hinzufuegen', standardTextHtml);

    const korrekteDatenAngezeigt = zeigeTabelle(korrektAnzeige, document.getElementById('korrektBereich'), korrekt, spaltenKorrekt, spaltenTitel, 'korrekt', standardTextHtml);
    if (korrekteDatenAngezeigt && globaleKorrekteDaten.length > 0) {
        korrektSpeichernButton.disabled = false;
    }

    if (globalePhase === 'SORTIERT' && seitenzahlAbweichungen && seitenzahlAbweichungen.length > 0) {
        zeigeTabelle(seitenzahlAbweichungAnzeige, seitenzahlAbweichungBereich, seitenzahlAbweichungen, spaltenSeitenzahlAbweichungen, spaltenTitel, 'seitenzahlAbweichungen', standardTextHtml);
    }

    if(entfernenTotal) {
        const entfernenFormatSumme = zuEntfernen.reduce((sum, item) => sum + (item.seitenFormat || 0), 0);
        entfernenTotal.textContent = zuEntfernen.length > 0 ? `Gesamt: ${entfernenFormatSumme.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : '';
        entfernenTotal.style.textAlign = 'right';
    }
    if(hinzufuegenTotal) {
        const hinzufuegenFormatSumme = hinzuzufuegen.reduce((sum, item) => sum + (item.seitenFormat || item.gesamtFormat || 0), 0);
        hinzufuegenTotal.textContent = hinzuzufuegen.length > 0 ? `Gesamt: ${hinzufuegenFormatSumme.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : '';
        hinzufuegenTotal.style.textAlign = 'right';
    }

    const korrektTotal = document.getElementById('korrektTotal');
    if (korrektTotal) {
        const korrektFormatSumme = korrekt.reduce((sum, item) => sum + (item.seitenFormat || item.gesamtFormat || 0), 0);
        korrektTotal.textContent = korrekt.length > 0 ? `Gesamt: ${korrektFormatSumme.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : '';
        korrektTotal.style.textAlign = 'right';
        korrektTotal.style.display = 'block';
    }

    const seitenzahlAbweichungTotal = document.getElementById('seitenzahlAbweichungTotal');
    if (seitenzahlAbweichungTotal && seitenzahlAbweichungen) {
        seitenzahlAbweichungTotal.textContent = seitenzahlAbweichungen.length > 0 ? `Gesamt: ${seitenzahlAbweichungen.length}` : '';
        seitenzahlAbweichungTotal.style.textAlign = 'right';
    }

    const leereSeitenTotal = document.getElementById('leereSeitenTotal');
    if (leereSeitenTotal && leereSeiten && leereSeiten.length > 0) {
        const gesamtSeitenFormat = leereSeiten.reduce((sum, item) => sum + item.verfuegbaresFormat, 0);
        leereSeitenTotal.textContent = `Gesamt: ${gesamtSeitenFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}`;
        leereSeitenTotal.style.textAlign = 'right';
    } else if (leereSeitenTotal) {
        leereSeitenTotal.textContent = '';
    }
};

console.log("tabellenAnzeige.js v1.3.1 geladen.");