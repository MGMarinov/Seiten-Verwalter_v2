// js/main.js - v1.3.0 - Hauptinitialisierung und Event-Handler
console.log("Lade main.js v1.3.0...");

function setupClearButton(inputElement, clearButton, searchFunction) {
    if (!inputElement || !clearButton) return;

    clearButton.addEventListener('click', () => {
        inputElement.value = '';
        clearButton.classList.add('hidden');
        if (searchFunction) {
            searchFunction('');
        }
        inputElement.focus();
    });
}

function oeffneHilfeModal() {
    if (hilfeModalOverlay) {
        hilfeModalOverlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

function schliesseHilfeModal() {
    if (hilfeModalOverlay) {
        hilfeModalOverlay.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

function oeffneKatalogSucheModal() {
    const katalogSucheModalOverlay = document.getElementById('katalogSucheModalOverlay');
    if (katalogSucheModalOverlay) {
        katalogSucheModalOverlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

function schliesseKatalogSucheModal() {
    const katalogSucheModalOverlay = document.getElementById('katalogSucheModalOverlay');
    if (katalogSucheModalOverlay) {
        katalogSucheModalOverlay.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("Initialisiere Anwendung...");

    let katalogSucheDebounceTimer, planSucheDebounceTimer, indesignSucheDebounceTimer, korrekturenSucheDebounceTimer;

    const korrekturenSucheInput = document.getElementById('korrekturenSucheInput');
    const korrekturenSucheClear = document.getElementById('korrekturenSucheClear');
    const korrekturenSpalte = document.getElementById('korrekturenSpalte');
    const einteilungAnzeigenButton = document.getElementById('einteilungAnzeigenButton');
    const einteilungModalOverlay = document.getElementById('einteilungModalOverlay');
    const einteilungModalSchliessen = document.getElementById('einteilungModalSchliessen');
    const einteilungModalSuche = document.getElementById('einteilungModalSuche');
    const einteilungModalInhalt = document.getElementById('einteilungModalInhalt');

    if (vergleichButton) {
        vergleichButton.addEventListener('click', vergleichStarten);
    } else {
        console.error("Initialisierungsfehler: Vergleich-Button nicht im DOM gefunden.");
    }

    if (korrektSpeichernButton) {
        korrektSpeichernButton.addEventListener('click', korrekteSeitenAlsCsvSpeichern);
        korrektSpeichernButton.disabled = true;
    } else {
        console.error("Initialisierungsfehler: Korrekt-Speichern-Button nicht im DOM gefunden.");
    }

    if (resetButton) {
        resetButton.addEventListener('click', () => {
            if (confirm("Möchtest du die aktuelle Ansicht zurücksetzen und die Seite neu laden?")) {
                location.reload();
            }
        });
    } else {
        console.error("Initialisierungsfehler: Reset-Button nicht im DOM gefunden.");
    }

    if (katalogSucheInput) {
        katalogSucheInput.addEventListener('input', (event) => {
            const suchBegriff = event.target.value.trim();
            if (katalogSucheClear) {
                katalogSucheClear.classList.toggle('hidden', !suchBegriff);
            }
            clearTimeout(katalogSucheDebounceTimer);
            katalogSucheDebounceTimer = setTimeout(() => {
                sucheInPlandaten(event.target.value);
            }, 300);
        });
        katalogSucheInput.disabled = true;
        if (katalogSucheErgebnis) {
            katalogSucheErgebnis.innerHTML = '<p class="text-gray-500 italic">Zuerst Einteilung-Datei laden</p>';
        }
    } else {
        console.error("Initialisierungsfehler: Katalog-Suchfeld (Sidebar) nicht im DOM gefunden.");
    }

    if (planSucheInput) {
        planSucheInput.addEventListener('input', (event) => {
            const suchBegriff = event.target.value.trim();
            if (planSucheClear) {
                planSucheClear.classList.toggle('hidden', !suchBegriff);
            }
            clearTimeout(planSucheDebounceTimer);
            planSucheDebounceTimer = setTimeout(() => {
                filterAndDisplayPlanOverview(event.target.value);
            }, 300);
        });
        planSucheInput.disabled = true;
        planSucheInput.placeholder = 'Laden...';
    } else {
        console.error("Initialisierungsfehler: Plan-Suchfeld (Hauptbereich) nicht im DOM gefunden.");
    }

    if (indesignSucheInput) {
        indesignSucheInput.addEventListener('input', (event) => {
            const suchBegriff = event.target.value.trim();
            if (indesignSucheClear) {
                indesignSucheClear.classList.toggle('hidden', !suchBegriff);
            }
            clearTimeout(indesignSucheDebounceTimer);
            indesignSucheDebounceTimer = setTimeout(() => {
                filterAndDisplayIndesignOverview(event.target.value);
            }, 300);
        });
        indesignSucheInput.disabled = true;
        indesignSucheInput.placeholder = 'Laden...';
    } else {
        console.error("Initialisierungsfehler: InDesign-Suchfeld (Hauptbereich) nicht im DOM gefunden.");
    }

    if (katalogSucheInput && katalogSucheClear) {
        setupClearButton(katalogSucheInput, katalogSucheClear, sucheInPlandaten);
    } else {
        console.error("Initialisierungsfehler: Katalog-Suchfeld oder Clear-Button (Sidebar) nicht im DOM gefunden.");
    }

    if (planSucheInput && planSucheClear) {
        setupClearButton(planSucheInput, planSucheClear, filterAndDisplayPlanOverview);
    } else {
        console.error("Initialisierungsfehler: Plan-Suchfeld oder Clear-Button (Hauptbereich) nicht im DOM gefunden.");
    }

    if (indesignSucheInput && indesignSucheClear) {
        setupClearButton(indesignSucheInput, indesignSucheClear, filterAndDisplayIndesignOverview);
    } else {
        console.error("Initialisierungsfehler: InDesign-Suchfeld oder Clear-Button (Hauptbereich) nicht im DOM gefunden.");
    }

    if (korrekturenSucheInput) {
        korrekturenSucheInput.addEventListener('input', (event) => {
            const suchBegriff = event.target.value.trim().toLowerCase();
            if (korrekturenSucheClear) {
                korrekturenSucheClear.classList.toggle('hidden', !suchBegriff);
            }
            clearTimeout(korrekturenSucheDebounceTimer);
            korrekturenSucheDebounceTimer = setTimeout(() => {
                filterKorrekturenTabellen(suchBegriff);
            }, 300);
        });
        korrekturenSucheInput.disabled = true;
        korrekturenSucheInput.placeholder = 'Laden...';
    } else {
        console.error("Initialisierungsfehler: Korrekturen-Suchfeld nicht im DOM gefunden.");
    }

    if (korrekturenSucheInput && korrekturenSucheClear) {
        setupClearButton(korrekturenSucheInput, korrekturenSucheClear, filterKorrekturenTabellen);
    } else {
        console.error("Initialisierungsfehler: Korrekturen-Suchfeld oder Clear-Button nicht im DOM gefunden.");
    }
    
    einteilungAnzeigenButton.addEventListener('click', () => {
        if (globalePlanRohdaten.length === 0) {
            globalNachrichtAnzeigen('Bitte lade zuerst eine Einteilung-Datei hoch.', 'warning');
        } else {
            const dateiPlan = dateiPlanInput.files[0];
            zeigeEinteilungPopup(globalePlanRohdaten, dateiPlan ? dateiPlan.name : 'Unbekannte Datei');
        }
    });

    einteilungModalSchliessen.addEventListener('click', () => {
        einteilungModalOverlay.classList.add('hidden');
    });
    
    einteilungModalOverlay.addEventListener('click', (event) => {
        if (event.target === einteilungModalOverlay) {
            einteilungModalOverlay.classList.add('hidden');
        }
    });

    einteilungModalInhalt.addEventListener('click', (event) => {
        const header = event.target.closest('.group-header');
        if (header) {
            const tbody = header.parentElement;
            tbody.classList.toggle('expanded');
        }
    });
    
    einteilungModalSuche.addEventListener('input', (event) => {
        const suchBegriff = event.target.value.toLowerCase();
        const tbodies = document.querySelectorAll('#einteilungModalInhalt tbody');
        tbodies.forEach(tbody => {
            const inhalt = tbody.textContent.toLowerCase();
            if (inhalt.includes(suchBegriff)) {
                tbody.style.display = 'table-row-group';
            } else {
                tbody.style.display = 'none';
            }
        });
    });

    window.devTest = {
        runUnsortiert: async function() {
            console.log('🧪 Entwickler-Test: Unsortiert');
            try {
                const ergebnis = await fuehreAutomatischenTestDurch('unsortiert');
                console.log('📊 Unsortiert Test Ergebnis:', ergebnis);
                return ergebnis;
            } catch (fehler) {
                console.error('❌ Unsortiert Test Fehler:', fehler);
                return { fehler: fehler.message };
            }
        },
        runSortiert: async function() {
            console.log('🧪 Entwickler-Test: Sortiert');
            try {
                const ergebnis = await fuehreAutomatischenTestDurch('sortiert');
                console.log('📊 Sortiert Test Ergebnis:', ergebnis);
                return ergebnis;
            } catch (fehler) {
                console.error('❌ Sortiert Test Fehler:', fehler);
                return { fehler: fehler.message };
            }
        },
        runKomplett: async function() {
            console.log('🧪 Entwickler-Test: Komplett');
            try {
                const ergebnis = await fuehreKomplettTestDurch();
                console.log('📊 Komplett Test Ergebnis:', ergebnis);
                return ergebnis;
            } catch (fehler) {
                console.error('❌ Komplett Test Fehler:', fehler);
                return { fehler: fehler.message };
            }
        },
        openTestPage: function() {
            window.open('utils/test.html', '_blank');
        }
    };

    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.shiftKey && event.key === 'T') {
            event.preventDefault();
            console.log('🧪 Test-Seite wird geöffnet...');
            window.devTest.openTestPage();
        }

        if (event.key === 'Escape') {
            if (einteilungModalOverlay && !einteilungModalOverlay.classList.contains('hidden')) {
                einteilungModalOverlay.classList.add('hidden');
                event.preventDefault();
            } else if (katalogSucheModalOverlay && !katalogSucheModalOverlay.classList.contains('hidden')) {
                schliesseKatalogSucheModal();
                event.preventDefault();
            } else if (hilfeModalOverlay && !hilfeModalOverlay.classList.contains('hidden')) {
                schliesseHilfeModal();
                event.preventDefault();
            }
        }
    });

    if (hilfeButton) {
        hilfeButton.addEventListener('click', oeffneHilfeModal);
    } else {
        console.error("Initialisierungsfehler: Hilfe-Button nicht im DOM gefunden.");
    }

    if (hilfeModalSchliessen) {
        hilfeModalSchliessen.addEventListener('click', schliesseHilfeModal);
    } else {
        console.error("Initialisierungsfehler: Hilfe-Modal-Schließen-Button nicht im DOM gefunden.");
    }

    if (hilfeModalOverlay) {
        hilfeModalOverlay.addEventListener('click', (event) => {
            if (event.target === hilfeModalOverlay) {
                schliesseHilfeModal();
            }
        });
    } else {
        console.error("Initialisierungsfehler: Hilfe-Modal-Overlay nicht im DOM gefunden.");
    }

    const katalogSucheModalOverlay = document.getElementById('katalogSucheModalOverlay');
    const katalogSucheModalSchliessen = document.getElementById('katalogSucheModalSchliessen');

    if (katalogSucheModalSchliessen) {
        katalogSucheModalSchliessen.addEventListener('click', schliesseKatalogSucheModal);
    } else {
        console.error("Initialisierungsfehler: Katalog-Suche-Modal-Schließen-Button nicht im DOM gefunden.");
    }

    if (katalogSucheModalOverlay) {
        katalogSucheModalOverlay.addEventListener('click', (event) => {
            if (event.target === katalogSucheModalOverlay) {
                schliesseKatalogSucheModal();
            }
        });
    } else {
        console.error("Initialisierungsfehler: Katalog-Suche-Modal-Overlay nicht im DOM gefunden.");
    }

    alleErgebnisbereicheLeeren();
    if(korrekturenSucheInput) {
        korrekturenSucheInput.value = '';
        korrekturenSucheInput.disabled = true;
        korrekturenSucheInput.placeholder = 'Laden...';
        if(korrekturenSucheClear) korrekturenSucheClear.classList.add('hidden');
    }

    console.log("Anwendung erfolgreich initialisiert.");
});

function filterKorrekturenTabellen(suchBegriff) {
    const suchBegriffLower = suchBegriff.trim().toLowerCase();
    if (!korrekturenSpalte) return;

    const tabellenContainer = korrekturenSpalte.querySelectorAll('.table-container');

    tabellenContainer.forEach(container => {
        const tabelle = container.querySelector('table');
        if (!tabelle) return;

        const tbody = tabelle.querySelector('tbody');
        if (!tbody) return;

        let sichtbareZeilenInTabelle = 0;
        Array.from(tbody.rows).forEach(zeile => {
            if (zeile.classList.contains('total-row')) return;

            const zellenText = Array.from(zeile.cells)
                .map(zelle => zelle.textContent.toLowerCase())
                .join(' ');

            const istTreffer = zellenText.includes(suchBegriffLower);
            zeile.style.display = istTreffer ? '' : 'none';
            if (istTreffer) sichtbareZeilenInTabelle++;
        });
    });
    if (korrekturenSucheInput && korrekturenSucheClear) {
        korrekturenSucheClear.classList.toggle('hidden', !korrekturenSucheInput.value.trim());
    }
}

console.log("main.js v1.3.0 geladen.");