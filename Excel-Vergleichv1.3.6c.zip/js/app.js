// js/app.js - v.2.0 - Hauptanwendungslogik
console.log("Lade app.js v.2.0...");

/**
 * Zeigt Vergleichsergebnisse an. Nutzt die Ergebnisse von logic.js und Hilfsfunktionen aus utils.js.
 */
function ergebnisseAnzeigen(ergebnisse, fehlerListePlan, fehlendeSeitenListe, fehlendeSeitenMitFormat = []) {
    console.log("ergebnisseAnzeigen aufgerufen mit fehlendeSeitenListe:", fehlendeSeitenListe);
    console.log("ergebnisseAnzeigen aufgerufen mit fehlendeSeitenMitFormat:", fehlendeSeitenMitFormat);

    const elementeExistieren = [
        fehlerBereich, fehlerAnzeige, entfernenAnzeige, hinzufuegenAnzeige, korrektAnzeige,
        leereSeitenAnzeige, entfernenTotal, hinzufuegenTotal, duplikatFehlerBereich,
        duplikatFehlerAnzeige, korrektSpeichernButton
    ].every(el => el !== null);

    if (!elementeExistieren) {
        console.error("Fehler: Einige Ergebnis-Container-Elemente nicht im DOM gefunden.");
        return;
    }

    const standardTextHtml = '<div class="standard-text">Keine Einträge in dieser Kategorie.</div>';
    const standardFehlendHtml = '<div class="standard-text">Keine leeren Seiten im Katalog gefunden.</div>';
    const standardDuplikatHtml = '<div class="standard-text">Keine Duplikate oder Zuordnungsfehler gefunden.</div>';

    fehlerBereich.classList.add('hidden'); fehlerAnzeige.innerHTML = '';
    duplikatFehlerBereich.classList.add('hidden'); duplikatFehlerAnzeige.innerHTML = standardDuplikatHtml;
    const seitenZahlBereichVeraltet = document.getElementById('seitenZahlFehlerBereich');
    if (seitenZahlBereichVeraltet) seitenZahlBereichVeraltet.classList.add('hidden');
    entfernenAnzeige.innerHTML = standardTextHtml; hinzufuegenAnzeige.innerHTML = standardTextHtml;
    korrektAnzeige.innerHTML = standardTextHtml;
    entfernenTotal.textContent = ''; hinzufuegenTotal.textContent = '';
    globaleKorrekteDaten = []; korrektSpeichernButton.disabled = true;

    const { zuEntfernen, hinzuzufuegen, korrekt, duplikatFehler } = ergebnisse;
    globaleKorrekteDaten = korrekt;

    const spaltenTitel = {
        seite:'Seite', katalogGruppe:'Gruppe/Nr.', modell:'Modell', produktNummer:'Produktnr.',
        gesamtFormat:'Format', seitenFormat:'Format', grund:'Grund', status:'Status',
        typ:'Fehlertyp', seiten:'Betroffene Seiten', details:'Details',
        fehlerQuelle: 'Quelle', fehlerWert: 'Details/Wert', format:'Format'
    };

    const spaltenEntfernen = ['seite', 'katalogGruppe', 'modell', 'grund', 'seitenFormat'];
    const spaltenHinzufuegen = ['seite', 'katalogGruppe', 'modell', 'gesamtFormat'];
    const spaltenKorrekt = ['seite', 'katalogGruppe', 'modell', 'status', 'seitenFormat'];
    const spaltenDuplikatFehler = ['produktNummer', 'typ', 'seiten', 'details'];
    const spaltenFehlerPlan = ['typ', 'fehlerQuelle', 'modell', 'fehlerWert'];
    const spaltenLeereSeiten = ['seite', 'katalogGruppe', 'modell', 'format'];

    zeigeTabelle(duplikatFehlerAnzeige, duplikatFehlerBereich, duplikatFehler, spaltenDuplikatFehler, spaltenTitel, 'duplikat', standardDuplikatHtml);

    zeigeTabelle(fehlerAnzeige, fehlerBereich, fehlerListePlan, spaltenFehlerPlan, spaltenTitel, 'fehlerPlan', standardTextHtml, false, f => ({
        typ: f.typ || '-',
        fehlerQuelle: f.zeile !== undefined && f.zeile !== 'N/A' ? `Zeile ${f.zeile}` : (f.gruppe !== undefined ? `Gruppe ${f.gruppe}` : '-'),
        modell: f.modell || '-',
        fehlerWert: f.summe !== undefined ? `Summe: ${f.summe.toLocaleString('de-DE')} (Erw: ${f.erwartet})` : (f.wert !== undefined ? `${f.wert}` : '-')
    }));

    const transformierteLeereSeiten = fehlendeSeitenMitFormat.map(item => {
        const istHalbseite = item.seite.includes('(halbe Seite leer)');
        const istTeilweiseLeer = item.seite.includes('(teilweise leer)');
        const seiteNum = istHalbseite ? item.seite.split(' ')[0] :
                       istTeilweiseLeer ? item.seite.split(' ')[0] : item.seite;

        return {
            seite: seiteNum,
            katalogGruppe: '-',
            modell: '-',
            format: item.verfuegbaresFormat
        };
    });

    zeigeTabelle(leereSeitenAnzeige, document.getElementById('leereSeitenBereich'), transformierteLeereSeiten, spaltenLeereSeiten, spaltenTitel, 'leereSeiten', standardFehlendHtml);
    zeigeTabelle(entfernenAnzeige, document.getElementById('entfernenBereich'), zuEntfernen, spaltenEntfernen, spaltenTitel, 'entfernen', standardTextHtml, true);
    zeigeTabelle(hinzufuegenAnzeige, document.getElementById('hinzufuegenBereich'), hinzuzufuegen, spaltenHinzufuegen, spaltenTitel, 'hinzufuegen', standardTextHtml);

    const korrekteDatenAngezeigt = zeigeTabelle(korrektAnzeige, document.getElementById('korrektBereich'), korrekt, spaltenKorrekt, spaltenTitel, 'korrekt', standardTextHtml);
    if (korrekteDatenAngezeigt && globaleKorrekteDaten.length > 0) {
        korrektSpeichernButton.disabled = false;
    }

    if(entfernenTotal) {
        const entfernenFormatSumme = zuEntfernen.reduce((sum, item) => sum + (item.seitenFormat || 0), 0);
        entfernenTotal.textContent = zuEntfernen.length > 0 ? `Gesamt: ${entfernenFormatSumme.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : '';
        entfernenTotal.style.textAlign = 'right';
    }
    if(hinzufuegenTotal) {
        const hinzufuegenFormatSumme = hinzuzufuegen.reduce((sum, item) => sum + (item.seitenFormat || item.gesamtFormat || 0), 0);
        hinzufuegenTotal.textContent = hinzuzufuegen.length > 0 ? `Gesamt: ${hinzufuegenFormatSumme.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : '';
        hinzufuegenTotal.style.textAlign = 'right';
    }

    const leereSeitenTotal = document.getElementById('leereSeitenTotal');
    if (leereSeitenTotal && fehlendeSeitenMitFormat && fehlendeSeitenMitFormat.length > 0) {
        const gesamtSeitenFormat = fehlendeSeitenMitFormat.reduce((sum, item) => sum + item.verfuegbaresFormat, 0);
        leereSeitenTotal.textContent = `Gesamt: ${gesamtSeitenFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}`;
        leereSeitenTotal.style.textAlign = 'right';
    } else if (leereSeitenTotal) {
        leereSeitenTotal.textContent = '';
    }
}

/**
 * Erstellt und löst den Download einer CSV-Datei aus den global gespeicherten "korrekt"-Daten aus.
 */
function korrekteSeitenAlsCsvSpeichern() {
    if (!globaleKorrekteDaten || globaleKorrekteDaten.length === 0) { globalNachrichtAnzeigen("Keine korrekten Daten zum Speichern vorhanden.", "warning"); return; }
    const spaltenTitel = { seite: 'Seite', katalogGruppe: 'Gruppe/Nr.', modell: 'Modell', status: 'Status', seitenFormat: 'Format' };
    const spaltenReihenfolge = ['seite', 'katalogGruppe', 'modell', 'status', 'seitenFormat'];

    try {
        const header = spaltenReihenfolge.map(key => `"${spaltenTitel[key]}"`).join(';');
        const rows = globaleKorrekteDaten.map(item => {
            return spaltenReihenfolge.map(key => {
                let wert = item.hasOwnProperty(key) ? item[key] : ''; if (wert === null || wert === undefined) wert = '';
                if (key === 'status') {
                    let statusText = [];
                    if (item.istTitel) statusText.push('Titel');
                    if (item.istRueckseite) statusText.push('Rückseite');
                    if (item.istDoppelseite) statusText.push('Doppel');
                    if (typeof item.gesamtFormat === 'number' && typeof item.seitenFormat === 'number' && item.gesamtFormat !== item.seitenFormat) statusText.push('Formatabweichung');
                    if (item.hatSeitenZahlFehler) statusText.push('Seitenzahlfehler');
                    wert = statusText.join(', ');
                } else if (typeof wert === 'number') { wert = wert.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 2 }); }
                return `"${String(wert).replace(/"/g, '""')}"`;
            }).join(';');
        });
        const csvInhalt = [header, ...rows].join('\n'); const blob = new Blob([`\uFEFF${csvInhalt}`], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a"); const url = URL.createObjectURL(blob); link.setAttribute("href", url); link.setAttribute("download", "korrekte_seiten.csv");
        link.style.visibility = 'hidden'; document.body.appendChild(link); link.click(); document.body.removeChild(link); URL.revokeObjectURL(url);
    } catch (fehler) { console.error("Fehler beim Erstellen der CSV für korrekte Seiten:", fehler); globalNachrichtAnzeigen(`Fehler beim Speichern der CSV: ${fehler.message}`, 'danger'); }
}

/**
 * Hauptfunktion, die den gesamten Vergleichsprozess steuert.
 */
async function vergleichStarten() {
    if (!dateiPlanInput || !dateiInDesignInput || !vergleichButton) { globalNachrichtAnzeigen("Interner Fehler: Wichtige UI-Elemente fehlen.", 'danger'); return; }
    const dateiPlan = dateiPlanInput.files[0]; const dateiInDesign = dateiInDesignInput.files[0];
    if (!dateiPlan || !dateiInDesign) { globalNachrichtAnzeigen("Bitte wählen Sie beide Dateien aus.", 'warning'); return; }

    try {
        ladeanzeigeZeigen(true);
        alleErgebnisbereicheLeeren();

        const [planRohdatenParsed, inDesignRohdaten] = await Promise.all([ excelLesenUndParsen(dateiPlan), csvLesenUndParsen(dateiInDesign, ';') ]);
        globalePlanRohdaten = planRohdatenParsed; console.log(`Globale Einteilung-Rohdaten gesetzt (${globalePlanRohdaten.length} Zeilen).`);
        console.log("Dateien geparst.");

        const { planMap, fehlerListe: fehlerPlan, minSeite, maxSeite } = verarbeitePlandaten(globalePlanRohdaten);
        console.log("Einteilung-Daten verarbeitet.");

        const { inDesignSeitenMap, hoechsteSeiteNummerCsv, vorhandeneSeitenNummernCsv, produktNummerZuSeitenMap } = verarbeiteInDesignDaten(inDesignRohdaten);
        console.log("InDesign-Daten verarbeitet.");



        const vergleichsErgebnisse = vergleicheDaten(planMap, inDesignSeitenMap, produktNummerZuSeitenMap, globaleMaxPlanSeiteFuerRueckseite);
        console.log("Daten verglichen.");

        // OBJEKTUM SZINTŰ TÁROLÁS - globális változóban tároljuk
        window.globaleProblematischeProduktNummern = vergleichsErgebnisse.problematischeProduktNummern;
        console.log("Problémás produktnummern:", Array.from(window.globaleProblematischeProduktNummern));

        uebersichtAnzeigen(planMap, inDesignSeitenMap, globaleMaxPlanSeiteFuerRueckseite);

        // Konvertiere unvollstaendigeSeiten und fehlendeHalbseiten zu fehlendeSeitenMitFormat
        const fehlendeSeitenMitFormat = [];

        // Füge unvollständige Seiten hinzu
        if (vergleichsErgebnisse.unvollstaendigeSeiten) {
            vergleichsErgebnisse.unvollstaendigeSeiten.forEach(item => {
                fehlendeSeitenMitFormat.push({
                    seite: item.seite,
                    katalogGruppe: '-',
                    modell: '-',
                    format: item.verfuegbarerPlatz || (1 - (item.inDesignFormat || 0))
                });
            });
        }

        // Füge fehlende Halbseiten hinzu
        if (vergleichsErgebnisse.fehlendeHalbseiten) {
            vergleichsErgebnisse.fehlendeHalbseiten.forEach(item => {
                fehlendeSeitenMitFormat.push({
                    seite: item.seite,
                    katalogGruppe: '-',
                    modell: '-',
                    format: item.planFormat || 0.5
                });
            });
        }

        ergebnisseAnzeigen(vergleichsErgebnisse, fehlerPlan, [], fehlendeSeitenMitFormat);

        if(katalogSucheInput) katalogSucheInput.disabled = false; if(katalogSucheErgebnis) katalogSucheErgebnis.innerHTML = '<p class="text-gray-500 italic">Geben Sie eine Kataloggruppierung ein.</p>';
        globalNachrichtAnzeigen('Vergleich erfolgreich abgeschlossen.', 'success');
    } catch (fehler) {
        console.error("Fehler im Vergleichsprozess:", fehler); globalNachrichtAnzeigen(`Verarbeitung fehlgeschlagen: ${fehler.message}`, 'danger');
        if(katalogSucheInput) katalogSucheInput.disabled = true; if(katalogSucheErgebnis) katalogSucheErgebnis.innerHTML = '<p class="text-gray-500 italic">Geben Sie eine Kataloggruppierung ein.</p>';
        if(planSucheInput) planSucheInput.value = ''; if(indesignSucheInput) indesignSucheInput.value = '';
        if(katalogSucheClear) katalogSucheClear.classList.add('hidden'); if(planSucheClear) planSucheClear.classList.add('hidden'); if(indesignSucheClear) indesignSucheClear.classList.add('hidden');
    } finally { ladeanzeigeZeigen(false); }
}

/**
 * Initialisiert Event Listener und UI-Komponenten.
 */
function initializeApp() {
    if (vergleichButton) vergleichButton.addEventListener('click', vergleichStarten);
    if (korrektSpeichernButton) korrektSpeichernButton.addEventListener('click', korrekteSeitenAlsCsvSpeichern);
    if (resetButton) resetButton.addEventListener('click', () => { alleErgebnisbereicheLeeren(); });

    if (katalogSucheInput) katalogSucheInput.addEventListener('input', (e) => sucheInPlandaten(e.target.value));
    if (planSucheInput) planSucheInput.addEventListener('input', (e) => filterAndDisplayPlanOverview(e.target.value));
    if (indesignSucheInput) indesignSucheInput.addEventListener('input', (e) => filterAndDisplayIndesignOverview(e.target.value));

    setupClearButton(katalogSucheInput, katalogSucheClear, sucheInPlandaten);
    setupClearButton(planSucheInput, planSucheClear, filterAndDisplayPlanOverview);
    setupClearButton(indesignSucheInput, indesignSucheClear, filterAndDisplayIndesignOverview);

    if (hilfeButton && hilfeModalOverlay && hilfeModalSchliessen) {
        hilfeButton.addEventListener('click', () => hilfeModalOverlay.classList.remove('hidden'));
        hilfeModalSchliessen.addEventListener('click', () => hilfeModalOverlay.classList.add('hidden'));
        hilfeModalOverlay.addEventListener('click', (e) => { if (e.target === hilfeModalOverlay) hilfeModalOverlay.classList.add('hidden'); });
    }
}

// Initialisierung beim Laden der Seite
document.addEventListener('DOMContentLoaded', initializeApp);

console.log("app.js v.2.0 geladen.");
