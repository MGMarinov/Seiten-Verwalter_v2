# Dokumentation: Katalog Vergleich v1.3.0

## 1. Einleitung

Dieses Dokument beschreibt die Funktionalität, Dateistruktur und technischen Aspekte der Webanwendung "Katalog Vergleich". Die Anwendung dient dazu, Daten aus einer Katalog-Einteilungsdatei (Excel-Format, als JSON verarbeitet) mit einem Export aus InDesign (CSV) zu vergleichen, um Diskrepanzen, Fehler und notwendige Korrekturen zu identifizieren.

**Wichtige Aktualisierungen:** Moduläre Code-Architektur, Phase-Erkennung (SORTIERT/UNSORTIERT), Seitenzahl-Abweichungsanalyse, verbesserte Testautomatisierung mit externen Testdaten und korrigierte Bilanz-Logik.

## 2. Funktionen

Die Hauptfunktionen der Anwendung umfassen:

* **Datei-Upload:** Hochladen einer Excel-Datei (`.xlsx`, `.xls`) für die Katalog-Einteilung und einer CSV-Datei (`.csv`) aus einem InDesign-Export.
* **Datenverarbeitung:**
    * Parsen und Validieren der hochgeladenen Dateien.
    * Verarbeitung der Einteilungsdaten (aus Excel/JSON): Gruppierung nach "Kataloggruppierung", Berechnung von Gesamtformaten pro Gruppe, Identifizierung von Titel-/Fix-/Flugblatt-Seiten, Prüfung auf Formatfehler und Duplikate/identische Datenzeilen in der Einteilung.
    * Verarbeitung der InDesign-Daten (CSV): Extrahieren von Produktnummern, Zuordnung von Nummern zu Seiten, Bestimmung des Seitenformats und Identifizierung von leeren Seiten.
* **Vergleich:** Abgleich der verarbeiteten Daten aus beiden Quellen.
* **Ergebnisanzeige:** Detaillierte Darstellung der Vergleichsergebnisse.
* **Suche:** In Katalog-Einteilung und Filterung der Übersichten.
* **Export:** Speichern der Liste der "Korrekten Seiten" als CSV-Datei.
* **Zurücksetzen:** Neustart der Anwendungsoberfläche.
* **Feedback:** Visuelle Rückmeldungen während der Verarbeitung.

## 3. Dateistruktur

* **`index.html`**: Haupt-HTML-Datei.
* **`css/style.css`**: Benutzerdefinierte CSS-Regeln.
* **`js/main.js`**: Hauptinitialisierung und Event-Handler.
* **`js/utils.js`**: Hilfsfunktionen (Datei-Parsing, UI-Benachrichtigungen, Tabellenerstellung). Enthält jetzt eine Prüfung auf die Verfügbarkeit von `window.Papa` für das CSV-Parsing im Browser.
* **`js/modules/`**:
    * **`datenVerarbeitung.js`**: Kernlogik für Excel/JSON- und CSV-Datenverarbeitung.
    * **`katalogLogik.js`**: Spezielle Katalog-Verarbeitungslogik.
    * **`vergleichsLogik.js`**: Vergleichsalgorithmen, Seitenzahl-Validierung und korrigierte Bilanz-Logik. Enthält zusätzliche Log-Ausgaben zur Fehlersuche bei der Bilanz-Berechnung.
    * **`uiController.js`**: UI-Steuerung.
    * **`tabellenAnzeige.js`**: Tabellen-Rendering.
    * **`uebersichtAnzeige.js`**: Übersichts-Anzeigen.
    * **`testModul.js`**: Für automatisierte Tests. Lädt Testdaten (JSON für Excel, CSV für InDesign) aus dem `utils/TestDoks/` Verzeichnis im Node.js-Kontext. Die `aiTestFunktion` erhält Testdaten als Parameter.
* **`favicon.ico`**: Anwendungsicon.
* **`utils/`**: Enthält Test-Skripte und Testdaten.
    * **`auto-test.js`**: Puppeteer-basiertes Testskript. Lädt Testdaten über `testModul.js` und übergibt sie an die Browser-Instanz. Gibt detaillierte Bilanz-Informationen aus.
    * **`TestDoks/`**: Verzeichnis für aktuelle Test-Dokumente (z.B. `AD13.25 unsortiert 2025 05 06.json`, `AD13.25 sortiert 2025 05 09.json`, `AD13.25 unsortiert 2025 05 06.csv`, `AD13.25 sortiert 2025 05 09.csv`).

## 4. Benutzeroberfläche (UI)
(Unverändert zur vorherigen Beschreibung)

## 5. Datenverarbeitung

### 5.1 Katalog-Bilanz (Balance) System

Die Anwendung verwendet ein Bilanz-Prinzip, um die Vollständigkeit des Katalogs zu überprüfen. Die korrigierte Logik stellt sicher, dass die Summe der Formate der korrekten, hinzuzufügenden und (neu berechneten) leeren Seiten dem erwarteten Gesamtumfang des Katalogs entspricht.

**Korrigierte Bilanz-Formel:**
```
Katalog Gesamt (Soll) = Korrekte Seiten (Format) + Hinzuzufügende Seiten (Format) + Neu Berechnete Leere Seiten (Format)
```
Wobei `Neu Berechnete Leere Seiten (Format) = Katalog Gesamt (Soll) - (Korrekte Seiten (Format) + Hinzuzufügende Seiten (Format))`.
Die `istAusgeglichen`-Prüfung in `js/modules/vergleichsLogik.js` wurde entsprechend angepasst.

### 5.2 Format-Berechnungen und Seitenkapazität

**Seitenkapazität und Format-System:**
- **1 Katalogseite = 1.0 Formatkapazität** (maximale Belegung)
- Formatwerte können sein: 0.5, 1.0 oder 2.0 (bei Doppelseiten)
- Eine Seite ist **vollständig belegt** wenn das Gesamtformat = 1.0 erreicht
- Eine Seite hat **verfügbaren Platz** wenn das Gesamtformat < 1.0 ist

**Leere Seiten-Erkennung:**
- **Vollständig leer**: Keine Inhalte vorhanden (verfügbar: 1.0 Format)
- **Teilweise belegt**: Hat Inhalte, aber < 1.0 Format (verfügbarer Platz wird angezeigt)
- **Vollständig belegt**: Gesamtformat = 1.0 (erscheint nicht in "Leere Seiten")

**Beispiele:**
- Seite mit nur einem 0.5-Format Artikel → 0.5 Format verfügbarer Platz
- Seite mit 0.5 + 0.5 Format Artikeln → vollständig belegt (1.0), kein verfügbarer Platz
- Seite ohne Artikel → vollständig leer (1.0 verfügbarer Platz)

### 5.3 Datenverarbeitung in Modulen
(Die grundlegende Beschreibung der Funktionen in `datenVerarbeitung.js` und `vergleichsLogik.js` bleibt gültig, aber die Implementierung der Bilanz wurde in `vergleichsLogik.js` verfeinert.)

## 6. Hilfsfunktionen (`utils.js`)
Die Funktion `csvLesenUndParsen` prüft nun, ob `window.Papa` verfügbar ist, bevor `parse` aufgerufen wird, um Fehler im Browser-Kontext besser abzufangen.

## 7. Abhängigkeiten
(Unverändert)

## 8. Verwendung
(Unverändert)

## 9. Test-Modul

### 9.1 Automatisierte Tests (`utils/auto-test.js` mit `js/modules/testModul.js`)

Das Test-Modul ermöglicht automatisierte Tests mit extern geladenen Daten:

**Datenladung:**
- Das Node.js-Skript `utils/auto-test.js` verwendet die Funktion `ladeAlleTestdatenAusDateien` aus `js/modules/testModul.js`.
- `ladeAlleTestdatenAusDateien` liest folgende Dateien aus dem Verzeichnis `utils/TestDoks/`:
    - Excel-Daten Unsortiert: `AD13.25 unsortiert 2025 05 06.json`
    - Excel-Daten Sortiert: `AD13.25 sortiert 2025 05 09.json`
    - CSV-Daten Unsortiert (InDesign Export): `AD13.25 unsortiert 2025 05 06.csv`
    - CSV-Daten Sortiert (InDesign Export): `AD13.25 sortiert 2025 05 09.csv`
- Diese Daten werden dann an die Puppeteer Browser-Instanz übergeben, wo die `aiTestFunktion` (ebenfalls in `testModul.js`) sie verarbeitet.

**Testausführung:**
- Starten mit `node utils/auto-test.js`.
- Führt Tests für "unsortiert" und "sortiert" Szenarien durch.
- Generiert eine `test-results.json` Datei und gibt eine Zusammenfassung auf der Konsole aus, inklusive detaillierter Bilanz-Analyse.

**Vorteile:**
- Testet mit realen, externen Daten.
- Automatische Validierung der Kernlogik, inklusive der Bilanz.
- Detaillierte Konsolen-Logs und JSON-Ergebnisdatei.

### 9.2 Test-Dokumentation und Dateien
(Die Liste der Test-Skripte unter `utils/` bleibt relevant, aber der Fokus der jüngsten Änderungen lag auf `auto-test.js` und `testModul.js`.)

## 10. Fehlerbehebungen und Verbesserungen (Jüngste Änderungen)

*   **Bilanz-Logik Korrektur (`js/modules/vergleichsLogik.js`):** Die Berechnung der Katalogbilanz wurde überarbeitet, um sicherzustellen, dass die Summe der Formate der korrekten, hinzuzufügenden und der neu berechneten leeren Seiten dem erwarteten Gesamtumfang des Katalogs entspricht. Dies löste die vorherigen "Bilanz FEHLER" Meldungen.
*   **Testdaten-Management (`js/modules/testModul.js`, `utils/auto-test.js`):** Die Testautomatisierung lädt nun alle Testdaten (Excel als JSON, InDesign als CSV für sortierte und unsortierte Fälle) aus dem `utils/TestDoks/` Verzeichnis im Node.js-Kontext und übergibt sie korrekt an die Testfunktionen im Browser-Kontext.
*   **Fehlerbehandlung `js/utils.js`:** Die CSV-Parsing Funktion prüft nun auf die Verfügbarkeit von `window.Papa`.
*   **Terminologie:** "Mérleg" wurde durchgängig zu "Bilanz" in den deutschen Ausgaben und Kommentaren geändert.
*   **Logolás:** Zusätzliche `console.log` Anweisungen wurden in `vergleichsLogik.js` hinzugefügt, um die Bilanzberechnung nachvollziehbarer zu machen.

## 11. UI-Verbesserungen
(Die in v1.3.0 beschriebenen UI-Verbesserungen, wie die Neupositionierung des "Leere Seiten" Bereichs, bleiben bestehen.)
