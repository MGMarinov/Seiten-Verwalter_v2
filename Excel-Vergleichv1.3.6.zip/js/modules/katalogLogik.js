// js/modules/katalogLogik.js - v1.3.0 - Katalog-spezifische Logik und Validierung
console.log("Lade katalogLogik.js v1.3.0...");

/**
 * Klasse für ein Katalog-Dokument
 */
class KatalogDokument {
    constructor(kataloggruppierung, modell, format, seite = 0) {
        this.kataloggruppierung = kataloggruppierung;
        this.modell = modell;
        this.format = format;
        this.seite = seite;
        this.istFlugblatt = false;
        this.istDoppelseite = false;
        this.istHalbseite = false;
        this.quelle = 'UNBEKANNT'; // 'PLAN', 'INDESIGN', 'BEIDE'
    }

    /**
     * Prüft ob das Dokument eine gültige Format-Größe hat
     */
    istFormatGueltig() {
        return [0.5, 1.0, 2.0].includes(this.format);
    }

    /**
     * Bestimmt den Dokumenttyp basierend auf Format
     */
    bestimmeDokumenttyp() {
        if (this.format === 0.5) {
            this.istHalbseite = true;
        } else if (this.format === 2.0) {
            this.istDoppelseite = true;
        }
    }
}

/**
 * Klasse für eine Katalog-Seite
 */
class KatalogSeite {
    constructor(seitennummer) {
        this.seitennummer = seitennummer;
        this.dokumente = [];
        this.maxKapazitaet = 1.0;
        this.aktuelleKapazitaet = 1.0;
    }

    /**
     * Fügt ein Dokument zur Seite hinzu
     */
    fuegeDokumentHinzu(dokument) {
        if (this.aktuelleKapazitaet >= dokument.format) {
            this.dokumente.push(dokument);
            this.aktuelleKapazitaet -= dokument.format;
            return true;
        }
        return false;
    }

    /**
     * Entfernt ein Dokument von der Seite
     */
    entferneDokument(kataloggruppierung) {
        const index = this.dokumente.findIndex(d => d.kataloggruppierung === kataloggruppierung);
        if (index !== -1) {
            const dokument = this.dokumente[index];
            this.dokumente.splice(index, 1);
            this.aktuelleKapazitaet += dokument.format;
            return dokument;
        }
        return null;
    }

    /**
     * Prüft ob die Seite leer ist
     */
    istLeer() {
        return this.dokumente.length === 0;
    }

    /**
     * Prüft ob die Seite voll ist
     */
    istVoll() {
        return this.aktuelleKapazitaet < 0.1; // Toleranz für Rundungsfehler
    }

    /**
     * Berechnet das Gesamt-Format der Seite
     */
    berechneGesamtFormat() {
        return this.dokumente.reduce((sum, dok) => sum + dok.format, 0);
    }
}

/**
 * Klasse für den gesamten Katalog
 */
class Katalog {
    constructor(gesamtSeiten) {
        this.gesamtSeiten = gesamtSeiten;
        this.seiten = new Map();
        this.dokumente = new Map();

        // Initialisiere alle Seiten
        for (let i = 1; i <= gesamtSeiten; i++) {
            this.seiten.set(i, new KatalogSeite(i));
        }
    }

    /**
     * Fügt ein Dokument zum Katalog hinzu
     */
    fuegeDokumentHinzu(dokument) {
        this.dokumente.set(dokument.kataloggruppierung, dokument);

        if (dokument.seite > 0 && dokument.seite <= this.gesamtSeiten) {
            const seite = this.seiten.get(dokument.seite);
            return seite.fuegeDokumentHinzu(dokument);
        }
        return false;
    }

    /**
     * Entfernt ein Dokument aus dem Katalog
     */
    entferneDokument(kataloggruppierung) {
        const dokument = this.dokumente.get(kataloggruppierung);
        if (dokument && dokument.seite > 0) {
            const seite = this.seiten.get(dokument.seite);
            const entfernteDokument = seite.entferneDokument(kataloggruppierung);
            if (entfernteDokument) {
                this.dokumente.delete(kataloggruppierung);
                return entfernteDokument;
            }
        }
        return null;
    }

    /**
     * Findet leere Seiten im Katalog
     */
    findeLeereSeiten() {
        const leereSeiten = [];
        this.seiten.forEach((seite, nummer) => {
            if (seite.istLeer()) {
                leereSeiten.push(nummer);
            }
        });
        return leereSeiten;
    }

    /**
     * Findet unvollständige Seiten (haben noch Kapazität)
     */
    findeUnvollstaendigeSeiten() {
        const unvollstaendigeSeiten = [];
        this.seiten.forEach((seite, nummer) => {
            if (!seite.istLeer() && !seite.istVoll()) {
                unvollstaendigeSeiten.push({
                    seitennummer: nummer,
                    verfuegbareKapazitaet: seite.aktuelleKapazitaet,
                    dokumente: seite.dokumente.map(d => d.kataloggruppierung)
                });
            }
        });
        return unvollstaendigeSeiten;
    }

    /**
     * Validiert den gesamten Katalog
     */
    validiere() {
        const validierungsergebnis = {
            istGueltig: true,
            fehler: [],
            warnungen: [],
            statistik: {
                leereSeiten: 0,
                volleSeiten: 0,
                unvollstaendigeSeiten: 0,
                gesamtDokumente: this.dokumente.size
            }
        };

        this.seiten.forEach((seite, nummer) => {
            if (seite.istLeer()) {
                validierungsergebnis.statistik.leereSeiten++;
            } else if (seite.istVoll()) {
                validierungsergebnis.statistik.volleSeiten++;
            } else {
                validierungsergebnis.statistik.unvollstaendigeSeiten++;
                validierungsergebnis.warnungen.push({
                    typ: 'Unvollständige Seite',
                    seite: nummer,
                    verfuegbareKapazitaet: seite.aktuelleKapazitaet,
                    nachricht: `Seite ${nummer} ist nicht vollständig gefüllt`
                });
            }

            // Prüfe Format-Überschreitung
            const gesamtFormat = seite.berechneGesamtFormat();
            if (gesamtFormat > 1.0) {
                validierungsergebnis.istGueltig = false;
                validierungsergebnis.fehler.push({
                    typ: 'Format-Überschreitung',
                    seite: nummer,
                    gesamtFormat: gesamtFormat,
                    nachricht: `Seite ${nummer} überschreitet die maximale Kapazität von 1.0`
                });
            }
        });

        return validierungsergebnis;
    }
}

/**
 * Analysiert Halbseiten und leere Plätze im Katalog.
 * Erkennt unvollständige Seiten und fehlende Halbseiten-Dokumente.
 * @param {Map<string, object>} planMap - Verarbeitete Plan-Daten.
 * @param {Map<string, object>} inDesignSeitenMap - Verarbeitete InDesign-Daten.
 * @param {number} maxSeiteNum - Höchste Seitenzahl im Katalog.
 * @returns {{ unvollstaendigeSeiten: object[], fehlendeHalbseiten: object[] }}
 */
function analysiereHalbseitenUndLeerePlaetze(planMap, inDesignSeitenMap, maxSeiteNum) {
    const unvollstaendigeSeiten = [];
    const fehlendeHalbseiten = [];

    // Erstelle eine Map für InDesign-Seiten nach Seitenzahl
    const idSeitenNachNummer = new Map();
    inDesignSeitenMap.forEach((seitenEintrag, seiteStr) => {
        const seiteNum = parseInt(seiteStr, 10);
        if (!isNaN(seiteNum) && seiteNum > 0 && seiteNum <= 500) {
            idSeitenNachNummer.set(seiteNum, seitenEintrag);
        }
    });

    // Erstelle eine Map für Plan-Einträge nach Seitenzahl
    const planSeitenNachNummer = new Map();
    planMap.forEach((planEintrag, gruppe) => {
        if (planEintrag.istFlugblatt || planEintrag.formatFehler || planEintrag.gesamtFormat === 0) {
            return; // Ignoriere problematische Einträge
        }

        planEintrag.seiten.forEach(seiteNum => {
            if (seiteNum > 0 && seiteNum <= 500) {
                if (!planSeitenNachNummer.has(seiteNum)) {
                    planSeitenNachNummer.set(seiteNum, []);
                }
                planSeitenNachNummer.get(seiteNum).push({
                    gruppe: gruppe,
                    format: planEintrag.gesamtFormat,
                    modell: planEintrag.modell,
                    istDoppelseite: planEintrag.istDoppelseite,
                    istHalbseite: planEintrag.istHalbseite
                });
            }
        });
    });

    // Prüfe jede Seite im Katalog
    for (let seiteNum = 1; seiteNum <= maxSeiteNum; seiteNum++) {
        const idSeite = idSeitenNachNummer.get(seiteNum);
        const planEintraege = planSeitenNachNummer.get(seiteNum) || [];

        // Berechne das Gesamt-Format auf dieser Seite laut Plan
        let gesamtFormatPlan = 0;
        planEintraege.forEach(eintrag => {
            gesamtFormatPlan += eintrag.format;
        });

        // Berechne das Format der InDesign-Seite
        const formatInDesign = idSeite ? idSeite.seitenFormat : 0;

        // Prüfe auf verschiedene Halbseiten-Probleme
        if (gesamtFormatPlan === 0.5 && (!idSeite || formatInDesign < 0.5)) {
            // Halbseite im Plan, aber nicht oder unvollständig in InDesign
            unvollstaendigeSeiten.push({
                seite: seiteNum.toString(),
                problem: 'Fehlende Halbseite',
                erwartetFormat: 0.5,
                istFormat: formatInDesign,
                grund: 'Halbseiten-Dokument fehlt im InDesign',
                planGruppen: planEintraege.map(e => e.gruppe).join(', ')
            });
        } else if (gesamtFormatPlan === 1 && idSeite && formatInDesign === 0.5) {
            // Ganze Seite geplant, aber nur Halbseite in InDesign - hier ist Platz für eine weitere Halbseite
            unvollstaendigeSeiten.push({
                seite: seiteNum.toString(),
                problem: 'Unvollständige Seite',
                erwartetFormat: 1,
                istFormat: 0.5,
                grund: 'Seite hat noch Platz für eine weitere Halbseite',
                planGruppen: planEintraege.map(e => e.gruppe).join(', ')
            });
        } else if (idSeite && formatInDesign === 0.5 && gesamtFormatPlan === 0) {
            // Halbseite in InDesign, aber nicht im Plan - diese sollte entfernt werden
            fehlendeHalbseiten.push({
                seite: seiteNum.toString(),
                problem: 'Halbseite ohne Plan-Eintrag',
                istFormat: 0.5,
                grund: 'Halbseite in InDesign, aber fehlt in Eintheilung',
                produktnummern: idSeite.produktnummern || []
            });
        } else if (gesamtFormatPlan === 0 && (!idSeite || formatInDesign === 0)) {
            // Komplett leere Seite - das ist auch ein Problem im Katalog
            unvollstaendigeSeiten.push({
                seite: seiteNum.toString(),
                problem: 'Leere Seite',
                erwartetFormat: 0,
                istFormat: 0,
                grund: 'Katalogseite ist komplett leer',
                planGruppen: ''
            });
        }

        // Spezielle Logik für Doppelseiten
        if (planEintraege.some(e => e.istDoppelseite)) {
            const doppelseiteEintrag = planEintraege.find(e => e.istDoppelseite);
            if (doppelseiteEintrag && doppelseiteEintrag.format === 2) {
                // Prüfe auch die nächste Seite für Doppelseiten
                const naechsteSeite = seiteNum + 1;
                if (naechsteSeite <= maxSeiteNum) {
                    const idNaechsteSeite = idSeitenNachNummer.get(naechsteSeite);
                    const formatNaechsteSeite = idNaechsteSeite ? idNaechsteSeite.seitenFormat : 0;

                    if (formatInDesign + formatNaechsteSeite < 2) {
                        unvollstaendigeSeiten.push({
                            seite: `${seiteNum}-${naechsteSeite}`,
                            problem: 'Unvollständige Doppelseite',
                            erwartetFormat: 2,
                            istFormat: formatInDesign + formatNaechsteSeite,
                            grund: 'Doppelseite nicht vollständig gefüllt',
                            planGruppen: doppelseiteEintrag.gruppe
                        });
                    }
                }
            }
        }
    }

    return { unvollstaendigeSeiten, fehlendeHalbseiten };
}

/**
 * Validiert die Sortierte Einteilung - prüft Seitenzahl-Übereinstimmung.
 * @param {Map<string, object>} planMap - Verarbeitete Plan-Daten.
 * @param {object[]} korrekteSeiten - Korrekte Seiten Liste.
 * @returns {object[]} - Array von Seitenzahl-Abweichung Objekten.
 */
function validiereSortierteEinteilung(planMap, korrekteSeiten) {
    const seitenzahlAbweichungen = [];

    korrekteSeiten.forEach(korrektItem => {
        const planEintrag = planMap.get(korrektItem.katalogGruppe);

        if (planEintrag && planEintrag.seite > 0) {
            // Hat endgültige Seitenzahl im Plan
            const planSeite = planEintrag.seite;
            const korrektSeite = parseInt(korrektItem.seite.split(',')[0].trim(), 10);

            if (!isNaN(korrektSeite) && planSeite !== korrektSeite) {
                seitenzahlAbweichungen.push({
                    katalogGruppe: korrektItem.katalogGruppe,
                    modell: korrektItem.modell,
                    planSeite: planSeite,
                    korrektSeite: korrektSeite,
                    abweichung: Math.abs(planSeite - korrektSeite),
                    fehler: 'Seitenzahl-Abweichung'
                });
            }
        }
    });

    return seitenzahlAbweichungen;
}

/**
 * Berechnet die Katalog-Kapazität und Validierung.
 * @param {number} maxKatalogSeiten - Maximale Katalog-Seitenzahl.
 * @param {object[]} zuEntfernen - Zu entfernende Objekte.
 * @param {object[]} korrekt - Korrekte Objekte.
 * @returns {object} - Kapazitäts-Informationen und Validierung.
 */
function berechneKatalogKapazitaet(maxKatalogSeiten, zuEntfernen, korrekt) {
    const zuEntfernendeFormatWerte = zuEntfernen.reduce((sum, obj) => {
        return sum + (obj.seitenFormat || 0);
    }, 0);

    const korrekteFormatAnzahl = korrekt.reduce((sum, obj) => {
        return sum + (obj.seitenFormat || 0);
    }, 0);

    const verfuegbareSeiten = maxKatalogSeiten - zuEntfernendeFormatWerte;
    const kapazitaetsUeberschreitung = korrekteFormatAnzahl > verfuegbareSeiten;

    return {
        maxKatalogSeiten,
        zuEntfernendeFormatWerte,
        korrekteFormatAnzahl,
        verfuegbareSeiten,
        kapazitaetsUeberschreitung,
        freieKapazitaet: verfuegbareSeiten - korrekteFormatAnzahl
    };
}

/**
 * Erstellt einen Katalog-Zustand für zentrale Verwaltung.
 * @param {number} gesamtSeiten - Gesamte Katalog-Seitenzahl.
 * @param {Map<string, object>} planMap - Plan-Daten.
 * @param {Map<string, object>} inDesignSeitenMap - InDesign-Daten.
 * @returns {object} - Zentraler Katalog-Zustand.
 */
function erstelleKatalogZustand(gesamtSeiten, planMap, inDesignSeitenMap) {
    const objekteMap = new Map();
    const seitenPlatzierung = new Map();
    const kapazitaetsMap = new Map();

    // Initialisiere alle Seiten mit leerer Kapazität
    for (let i = 1; i <= gesamtSeiten; i++) {
        seitenPlatzierung.set(i, []);
        kapazitaetsMap.set(i, 1.0); // Jede Seite hat 1.0 Kapazität
    }

    // Fülle Objekt-Daten aus planMap
    planMap.forEach((planEintrag, katalogGruppe) => {
        objekteMap.set(katalogGruppe, {
            katalogGruppe,
            modell: planEintrag.modell,
            format: planEintrag.gesamtFormat,
            seite: planEintrag.seite || 0,
            istFlugblatt: planEintrag.istFlugblatt,
            istDoppelseite: planEintrag.istDoppelseite,
            istHalbseite: planEintrag.istHalbseite,
            quelle: 'PLAN'
        });
    });

    // Aktualisiere mit InDesign-Daten
    inDesignSeitenMap.forEach((seitenEintrag, seiteStr) => {
        const seiteNum = parseInt(seiteStr, 10);
        if (!isNaN(seiteNum) && seiteNum > 0 && seiteNum <= gesamtSeiten) {
            // Reduziere verfügbare Kapazität
            const aktuelleKapazitaet = kapazitaetsMap.get(seiteNum) || 1.0;
            kapazitaetsMap.set(seiteNum, Math.max(0, aktuelleKapazitaet - seitenEintrag.seitenFormat));

            // Füge Objekte zur Seite hinzu
            seitenEintrag.produktnummern.forEach(produktNr => {
                const vorhandeneObjekte = seitenPlatzierung.get(seiteNum) || [];
                vorhandeneObjekte.push(produktNr);
                seitenPlatzierung.set(seiteNum, vorhandeneObjekte);
            });
        }
    });

    return {
        gesamtSeiten,
        objekteMap,
        seitenPlatzierung,
        kapazitaetsMap
    };
}

console.log("katalogLogik.js v1.3.0 geladen.");
