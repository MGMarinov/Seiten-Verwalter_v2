// js/modules/uiController.js - v1.3.3 - UI-Steuerung und Ereignisbehandlung
console.log("Lade uiController.js v1.3.3...");

let globalePlanRohdaten = [];
let globalePlanMap = new Map();
let globaleInDesignSeitenMap = new Map();
let globaleKorrekteDaten = [];
let globaleMaxPlanSeiteFuerRueckseite = 0;
let globalePhase = 'UNSORTIERT';

window.dateiPlanInput = document.getElementById('dateiPlan');
window.dateiInDesignInput = document.getElementById('dateiInDesign');
window.vergleichButton = document.getElementById('vergleichButton');
window.fehlerBereich = document.getElementById('fehlerBereich');
window.fehlerAnzeige = document.getElementById('fehlerAnzeige');
window.entfernenAnzeige = document.getElementById('entfernenAnzeige');
window.hinzufuegenAnzeige = document.getElementById('hinzufuegenAnzeige');
window.korrektAnzeige = document.getElementById('korrektAnzeige');
window.entfernenTotal = document.getElementById('entfernenTotal');
window.hinzufuegenTotal = document.getElementById('hinzufuegenTotal');
window.leereSeitenAnzeige = document.getElementById('leereSeitenAnzeige');
window.duplikatFehlerBereich = document.getElementById('duplikatFehlerBereich');
window.duplikatFehlerAnzeige = document.getElementById('duplikatFehlerAnzeige');
window.planUebersichtBereich = document.getElementById('planUebersichtBereich');
window.indesignUebersichtBereich = document.getElementById('indesignUebersichtBereich');
window.katalogSucheInput = document.getElementById('katalogSucheInput');
window.katalogSucheErgebnis = document.getElementById('katalogSucheErgebnis');
window.planSucheInput = document.getElementById('planSucheInput');
window.indesignSucheInput = document.getElementById('indesignSucheInput');
window.korrektSpeichernButton = document.getElementById('korrektSpeichernButton');
window.resetButton = document.getElementById('resetButton');
const phaseIndikator = document.getElementById('phaseIndikator');

window.uebersichtAnzeigen = function(planMap, inDesignSeitenMap, maxPlanSeite, phase = 'UNSORTIERT') {
    globalePlanMap = planMap;
    globaleInDesignSeitenMap = inDesignSeitenMap;
    globaleMaxPlanSeiteFuerRueckseite = maxPlanSeite;
    globalePhase = phase;
    aktualisierePhaseIndikator(phase);
    filterAndDisplayPlanOverview('');
    filterAndDisplayIndesignOverview('');
};

function aktualisierePhaseIndikator(phase) {
    if (phaseIndikator) {
        phaseIndikator.textContent = `Phase: ${phase}`;
        phaseIndikator.className = phase === 'SORTIERT'
            ? 'phase-indikator sortiert'
            : 'phase-indikator unsortiert';
    }
}

window.korrekteSeitenAlsCsvSpeichern = function() {
    if (!globaleKorrekteDaten || globaleKorrekteDaten.length === 0) {
        globalNachrichtAnzeigen("Keine korrekten Daten zum Speichern vorhanden.", "warning");
        return;
    }
    const spaltenTitel = {
        seite: 'Seite', katalogGruppe: 'Gruppe/Nr.', modell: 'Modell', status: 'Status', seitenFormat: 'Format', planSeite: 'Plan Seite'
    };
    const spaltenReihenfolge = ['seite', 'katalogGruppe', 'modell', 'status', 'seitenFormat'];
    if (globalePhase === 'SORTIERT') {
        spaltenReihenfolge.push('planSeite');
    }
    try {
        const header = spaltenReihenfolge.map(key => `"${spaltenTitel[key]}"`).join(';');
        const rows = globaleKorrekteDaten.map(item => {
            return spaltenReihenfolge.map(key => {
                let wert = item.hasOwnProperty(key) ? item[key] : '';
                if (wert === null || wert === undefined) wert = '';
                if (key === 'status') {
                    let statusText = [];
                    if (item.istTitel) statusText.push('Titel');
                    if (item.istRueckseite) statusText.push('Rückseite');
                    if (item.istDoppelseite) statusText.push('Doppel');
                    if (item.hatFormatAbweichung) statusText.push('Formatabweichung');
                    if (item.hatSeitenZahlFehler) statusText.push('Seitenzahlfehler');
                    wert = statusText.join(', ');
                } else if (typeof wert === 'number') {
                    wert = wert.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 2 });
                }
                return `"${String(wert).replace(/"/g, '""')}"`;
            }).join(';');
        });
        const csvInhalt = [header, ...rows].join('\n');
        const blob = new Blob([`\uFEFF${csvInhalt}`], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "korrekte_seiten.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (fehler) {
        console.error("Fehler beim Erstellen der CSV für korrekte Seiten:", fehler);
        globalNachrichtAnzeigen(`Fehler beim Speichern der CSV: ${fehler.message}`, 'danger');
    }
}

window.vergleichStarten = async function() {
    if (!dateiPlanInput || !dateiInDesignInput || !vergleichButton) {
        globalNachrichtAnzeigen("Interner Fehler: Wichtige UI-Elemente fehlen.", 'danger');
        return;
    }
    const dateiPlan = dateiPlanInput.files[0];
    const dateiInDesign = dateiInDesignInput.files[0];
    if (!dateiPlan || !dateiInDesign) {
        globalNachrichtAnzeigen('Bitte wähle beide Dateien (Einteilung und InDesign Export)!', 'warning');
        return;
    }

    ladeanzeigeZeigen(true);
    alleErgebnisbereicheLeeren();
    
    try {
        const [planRohdatenParsed, inDesignRohdaten] = await Promise.all([
            excelLesenUndParsen(dateiPlan),
            dateiLesenUndParsen(dateiInDesign)
        ]);
        globalePlanRohdaten = planRohdatenParsed;

        const { planMap, artikelZuGruppeMap, fehlerListe: fehlerPlan, minSeite, maxSeite, phase } = verarbeitePlandaten(globalePlanRohdaten);
        globalePlanMap = planMap;
        globaleMaxPlanSeiteFuerRueckseite = maxSeite;
        globalePhase = phase;

        const { inDesignSeitenMap, produktNummerZuSeitenMap } = verarbeiteInDesignDaten(inDesignRohdaten);
        globaleInDesignSeitenMap = inDesignSeitenMap;

        const ergebnisse = vergleicheDaten(planMap, artikelZuGruppeMap, inDesignSeitenMap, produktNummerZuSeitenMap, maxSeite, phase);
        
        const problematischeProduktNummern = new Set();
        ergebnisse.zuEntfernen.forEach(item => problematischeProduktNummern.add(item.katalogGruppe));
        ergebnisse.duplikatFehler.forEach(item => problematischeProduktNummern.add(item.produktNummer));
        window.globaleProblematischeProduktNummern = problematischeProduktNummern;

        uebersichtAnzeigen(planMap, inDesignSeitenMap, maxSeite, phase);
        ergebnisseAnzeigen(ergebnisse, fehlerPlan);

        if(katalogSucheInput) { katalogSucheInput.disabled = false; katalogSucheInput.placeholder = 'Suche in Einteilung...'; }
        if(planSucheInput) { planSucheInput.disabled = false; planSucheInput.placeholder = 'Suche in Einteilung...'; }
        if(indesignSucheInput) { indesignSucheInput.disabled = false; indesignSucheInput.placeholder = 'Suche in InDesign...'; }
        
        const korrekturenSucheInput = document.getElementById('korrekturenSucheInput');
        if(korrekturenSucheInput) { korrekturenSucheInput.disabled = false; korrekturenSucheInput.placeholder = 'Korrekturen durchsuchen...'; }

        if(katalogSucheErgebnis) katalogSucheErgebnis.innerHTML = '<p class="text-gray-500 italic">Geben Sie einen Suchbegriff ein...</p>';

        globalNachrichtAnzeigen(`Vergleich erfolgreich abgeschlossen! Phase: ${phase}`, 'success');
    } catch (fehler) {
        console.error("Fehler beim Vergleichsprozess:", fehler);
        globalNachrichtAnzeigen(`Fehler: ${fehler.message}`, 'danger');
    } finally {
        ladeanzeigeZeigen(false);
    }
};

function zeigeEinteilungPopup(planRohdaten, dateiname) {
    const modalInhalt = document.getElementById('einteilungModalInhalt');
    const modalOverlay = document.getElementById('einteilungModalOverlay');
    const dateinameAnzeige = document.getElementById('einteilungDateiname');
    
    modalInhalt.innerHTML = '';
    dateinameAnzeige.textContent = dateiname || '';

    const gruppierteDaten = new Map();
    let originalReihenfolgeGruppen = [];

    planRohdaten.forEach((zeile, index) => {
        zeile.__rowNum__ = index; // Eindeutige ID für jede Zeile
        const gruppe = zeile.Kataloggruppierung || 'Unbekannt';
        if (!gruppierteDaten.has(gruppe)) {
            gruppierteDaten.set(gruppe, []);
            originalReihenfolgeGruppen.push(gruppe);
        }
        gruppierteDaten.get(gruppe).push(zeile);
    });

    const alleHeader = new Set();
    planRohdaten.forEach(zeile => {
        Object.keys(zeile).forEach(key => {
            if (key !== '__rowNum__') alleHeader.add(key);
        });
    });
    const headerArray = Array.from(alleHeader);

    const table = document.createElement('table');
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    headerArray.forEach(headerText => {
        const th = document.createElement('th');
        th.className = 'text-left p-2 text-gray-300 font-medium border-b border-slate-600';
        th.textContent = headerText;
        headerRow.appendChild(th);
    });

    originalReihenfolgeGruppen.forEach(gruppe => {
        const gruppenZeilen = gruppierteDaten.get(gruppe);
        if (gruppenZeilen.length > 0) {
            const tbody = table.createTBody();
            tbody.setAttribute('data-gruppe', gruppe);

            gruppenZeilen.forEach((zeile, index) => {
                const row = tbody.insertRow();
                row.setAttribute('data-row-id', zeile.__rowNum__);

                if (index === 0) {
                    row.classList.add('group-header');
                } else {
                    row.classList.add('group-content');
                }

                headerArray.forEach((header, cellIndex) => {
                    const cell = row.insertCell();
                    cell.className = 'p-2 text-gray-200 border-b border-slate-700 whitespace-nowrap';
                    if (index === 0 && cellIndex === 0 && gruppenZeilen.length > 1) {
                        cell.classList.add('collapsible-cell');
                    }
                    cell.textContent = zeile[header] !== null && zeile[header] !== undefined ? zeile[header] : '';
                });
            });
        }
    });
    
    modalInhalt.appendChild(table);
    modalOverlay.classList.remove('hidden');
}


console.log("uiController.js v1.3.3 geladen.");