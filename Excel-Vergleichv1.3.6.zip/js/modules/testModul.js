// js/modules/testModul.js - v1.3.5 - Test Modul für automatisierte Tests mit realen Daten
console.log("Lade testModul.js v1.3.5...");

let fs = null;
let path = null;
let Papa = null; 
const IS_NODE = typeof process !== 'undefined' && process.versions && process.versions.node && typeof require !== 'undefined';

if (IS_NODE) {
    try {
        fs = require('fs');
        path = require('path');
        Papa = require('papaparse'); 
        console.log("Node.js Module (fs, path, papaparse) für testModul.js geladen.");
    } catch (e) {
        console.error("Fehler beim Laden der Node.js Module in testModul.js:", e);
        fs = null; path = null; Papa = null;
    }
}

const TESTDATEN_ORDNER_PFAD = 'utils/TestDoks'; 
const UNSORTIERTE_EXCEL_DATEI_NAME = 'AD13.25 unsortiert 2025 05 06.json'; 
const SORTIERTE_EXCEL_DATEI_NAME = 'AD13.25 sortiert 2025 05 09.json';     
const INDESIGN_CSV_UNSORTIERT_DATEI_NAME = 'AD13.25 unsortiert 2025 05 06.csv';
const INDESIGN_CSV_SORTIERT_DATEI_NAME = 'AD13.25 sortiert 2025 05 09.csv';


/**
 * Hilfsfunktion zum Laden und Parsen einer CSV-Datei als JSON-Objekt-Array im Node.js-Kontext.
 */
async function ladeCsvDateiAlsJsonNode(dateiname) {
    if (!IS_NODE || !fs || !path || !Papa) {
        console.warn(`Node.js Umgebung oder erforderliche Module (fs, path, Papa) nicht verfügbar für CSV: ${dateiname}. Gebe leere Daten zurück.`);
        return [];
    }
    try {
        const projektRoot = path.resolve(__dirname, '..', '..'); 
        const dateiPfad = path.join(projektRoot, TESTDATEN_ORDNER_PFAD, dateiname);
        if (!fs.existsSync(dateiPfad)) {
            console.error(`CSV-Datei nicht gefunden: ${dateiPfad}`);
            return [];
        }
        const csvString = fs.readFileSync(dateiPfad, 'utf8');
        return new Promise((resolve, reject) => {
            Papa.parse(csvString, {
                header: true,
                skipEmptyLines: true,
                dynamicTyping: true,
                complete: (results) => {
                    if (results.errors.length > 0) {
                        console.warn(`Fehler beim Parsen von CSV ${dateiname}:`, results.errors);
                    }
                    if (results.data.length === 0 && results.errors.length > 0) {
                         reject(new Error(`Konnte CSV ${dateiname} nicht erfolgreich parsen.`));
                    } else {
                        resolve(results.data);
                    }
                },
                error: (error) => reject(error)
            });
        });
    } catch (error) {
        console.error(`Fehler beim Lesen der CSV-Datei ${dateiname} (Node.js):`, error.message);
        return [];
    }
}

/**
 * Hilfsfunktion zum Laden einer JSON-Datei im Node.js-Kontext.
 */
async function ladeJsonDateiNode(dateiname) {
    if (!IS_NODE || !fs || !path) {
        console.warn(`Node.js Umgebung oder erforderliche Module (fs, path) nicht verfügbar für JSON: ${dateiname}. Gebe leere Daten zurück.`);
        return [];
    }
    try {
        const projektRoot = path.resolve(__dirname, '..', '..');
        const dateiPfad = path.join(projektRoot, TESTDATEN_ORDNER_PFAD, dateiname);
        if (!fs.existsSync(dateiPfad)) {
            console.error(`JSON-Datei nicht gefunden: ${dateiPfad}`);
            return [];
        }
        const jsonDataString = fs.readFileSync(dateiPfad, 'utf8');
        const jsonData = JSON.parse(jsonDataString);
        return jsonData;
    } catch (error) {
        console.error(`Fehler beim Lesen oder Parsen der JSON-Datei ${dateiname} (Node.js):`, error.message, error.stack); 
        return [];
    }
}

/**
 * Lädt alle Testdatensätze (sortiert und unsortiert).
 */
async function ladeAlleTestdatenAusDateien() { 
    if (IS_NODE && fs && path && Papa) { 
        try {
            const unsortierteExcel = await ladeJsonDateiNode(UNSORTIERTE_EXCEL_DATEI_NAME);
            const sortierteExcel = await ladeJsonDateiNode(SORTIERTE_EXCEL_DATEI_NAME);
            const unsortierteCsv = await ladeCsvDateiAlsJsonNode(INDESIGN_CSV_UNSORTIERT_DATEI_NAME);
            const sortierteCsv = await ladeCsvDateiAlsJsonNode(INDESIGN_CSV_SORTIERT_DATEI_NAME);

            return { 
                unsortierteExcel, 
                sortierteExcel, 
                unsortierteCsv, 
                sortierteCsv 
            };
        } catch (fehler) {
            console.error('Fehler beim Laden aller Testdaten aus Dateien (Node.js):', fehler);
            return { unsortierteExcel: [], sortierteExcel: [], unsortierteCsv: [], sortierteCsv: [] }; 
        }
    } else {
        console.warn("Nicht in Node.js Umgebung oder Module fehlen. Keine Testdaten aus Dateien geladen.");
        return { unsortierteExcel: [], sortierteExcel: [], unsortierteCsv: [], sortierteCsv: [] };
    }
}


/**
 * Führt einen automatisierten Test mit den vollständigen Dokumenten durch.
 * Diese Funktion ist für den Browser-Kontext gedacht und erwartet, dass die globalen UI-Funktionen verfügbar sind.
 * WARNUNG: Diese Funktion überschreibt die globalen Variablen mit Testdaten!
 */
async function fuehreAutomatischenTestDurch(testTyp = 'unsortiert') {
    console.warn('🧪 TESZT MODUS: A globális változók felülírásra kerülnek teszt adatokkal!');

    try {
        let excelDaten, csvDaten;
        if (typeof window !== 'undefined' && window.globaleTestDaten) {
            excelDaten = testTyp === 'sortiert' ? window.globaleTestDaten.sortierteExcel : window.globaleTestDaten.unsortierteExcel;
            csvDaten = testTyp === 'sortiert' ? window.globaleTestDaten.sortierteCsv : window.globaleTestDaten.unsortierteCsv;
        } else if (IS_NODE) {
            const alleDaten = await ladeAlleTestdatenAusDateien();
            excelDaten = testTyp === 'sortiert' ? alleDaten.sortierteExcel : alleDaten.unsortierteExcel;
            csvDaten = testTyp === 'sortiert' ? alleDaten.sortierteCsv : alleDaten.unsortierteCsv;
        } else {
            throw new Error("Testdatenquelle nicht verfügbar.");
        }

        if (!excelDaten || excelDaten.length === 0) {
            throw new Error(`${testTyp} Excel Testdaten sind leer.`);
        }
        if (!csvDaten || csvDaten.length === 0) {
            throw new Error(`${testTyp} CSV Testdaten sind leer.`);
        }

        // WARNUNG: Globale Variablen werden mit Testdaten überschrieben!
        globalePlanRohdaten = excelDaten;
        const { planMap, fehlerListe: fehlerPlan, minSeite, maxSeite, phase } = verarbeitePlandaten(excelDaten);
        globalePlanMap = planMap;
        globaleMaxPlanSeiteFuerRueckseite = maxSeite;
        globalePhase = phase;

        const { inDesignSeitenMap } = verarbeiteInDesignDaten(csvDaten);
        globaleInDesignSeitenMap = inDesignSeitenMap;

        const ergebnisse = vergleicheDaten(planMap, inDesignSeitenMap, produktNummerZuSeitenMapAusCsv(csvDaten), maxSeite, phase); // produktNummerZuSeitenMapAusCsv benötigt

        uebersichtAnzeigen(planMap, inDesignSeitenMap, maxSeite, phase);
        ergebnisseAnzeigen(ergebnisse, fehlerPlan, [], []);

        const testBericht = {
            erfolg: true, testTyp: testTyp, phase: phase,
            planEintraege: planMap.size, inDesignSeiten: inDesignSeitenMap.size,
            timestamp: new Date().toISOString()
        };
        globalNachrichtAnzeigen(`Test erfolgreich! Typ: ${testTyp}`, 'success');
        return testBericht;

    } catch (fehler) {
        console.error(`Test fehlgeschlagen (${testTyp}):`, fehler);
        globalNachrichtAnzeigen(`Test fehlgeschlagen: ${fehler.message}`, 'danger');
        return { erfolg: false, fehler: fehler.message, timestamp: new Date().toISOString() };
    }
}

function produktNummerZuSeitenMapAusCsv(csvDaten) {
    const map = new Map();
    csvDaten.forEach(row => {
        if (row.Produktnummer && row.Seite) {
            const produktnummern = String(row.Produktnummer).split(/[+;\s,]/).map(p => p.trim()).filter(p => p);
            produktnummern.forEach(pn => {
                if (!map.has(pn)) {
                    map.set(pn, new Set());
                }
                map.get(pn).add(String(row.Seite));
            });
        }
    });
    return map;
}


function validiereTestErgebnisse(testBericht) {
    const erwarteteWerte = testBericht.testTyp === 'sortiert' ? {
        phase: 'SORTIERT', minPlanEintraege: 8, minKorrekt: 5, maxDuplikate: 5, minSeitenzahlAbweichungen: 0 
    } : {
        phase: 'UNSORTIERT', minPlanEintraege: 8, minKorrekt: 5, maxDuplikate: 5, maxSeitenzahlAbweichungen: 0 
    };
    const validierung = {
        phaseKorrekt: testBericht.phase === erwarteteWerte.phase,
        genugPlanEintraege: testBericht.planEintraege >= erwarteteWerte.minPlanEintraege,
        genugKorrekte: testBericht.korrekt >= erwarteteWerte.minKorrekt,
        wenigeDuplikate: (testBericht.duplikatFehler || 0) <= erwarteteWerte.maxDuplikate,
        seitenzahlAbweichungenOk: testBericht.testTyp === 'sortiert' ?
            (testBericht.seitenzahlAbweichungen || 0) >= erwarteteWerte.minSeitenzahlAbweichungen :
            (testBericht.seitenzahlAbweichungen || 0) <= erwarteteWerte.maxSeitenzahlAbweichungen,
        gesamtErfolg: false
    };
    validierung.gesamtErfolg = validierung.phaseKorrekt && validierung.genugPlanEintraege && validierung.genugKorrekte && validierung.wenigeDuplikate && validierung.seitenzahlAbweichungenOk;
    return validierung;
}

async function fuehreKomplettTestDurch() { 
    console.warn("fuehreKomplettTestDurch ist für den direkten Browser-Aufruf gedacht.");
    return { erfolg: false, fehler: "Nicht direkt im Node-Kontext für Puppeteer gedacht." };
}

async function exportiereTestdaten() {
    if (typeof window === 'undefined') { 
             console.warn("exportiereTestdaten ist nur im Browser-Kontext sinnvoll.");
             return;
    }
}

async function ladeTestdatenAusDateienBrowser() {
    console.warn("ladeTestdatenAusDateienBrowser ist nicht vollständig implementiert.");
    return { unsortierteExcel: [], sortierteExcel: [], unsortierteCsv: [], sortierteCsv: [] };
}

async function aiTestFunktion(alleTestdaten, testTyp = 'unsortiert', detailLevel = 'normal') {
    console.warn('🧪 AI-TESZT MODUS: A globális változók felülírásra kerülnek teszt adatokkal!');

    try {
        if (!alleTestdaten || !alleTestdaten.unsortierteExcel || !alleTestdaten.sortierteExcel || !alleTestdaten.unsortierteCsv || !alleTestdaten.sortierteCsv) {
            throw new Error('Übergebene Testdaten (alleTestdaten) sind unvollständig oder fehlen für aiTestFunktion.');
        }

        const excelDatenToUse = testTyp === 'sortiert' ? alleTestdaten.sortierteExcel : alleTestdaten.unsortierteExcel;
        const csvDatenToUse = testTyp === 'sortiert' ? alleTestdaten.sortierteCsv : alleTestdaten.unsortierteCsv;

        if (excelDatenToUse.length === 0) {
             throw new Error(`${testTyp} Excel Testdaten sind leer für aiTestFunktion.`);
        }
        if (csvDatenToUse.length === 0) {
            throw new Error(`${testTyp} CSV Testdaten sind leer für aiTestFunktion.`);
        }

        // WARNUNG: Globale Variablen werden mit Testdaten überschrieben!
        globalePlanRohdaten = excelDatenToUse;
        const { planMap, fehlerListe: fehlerPlan, minSeite, maxSeite, phase } = verarbeitePlandaten(excelDatenToUse);
        globalePlanMap = planMap;
        globaleMaxPlanSeiteFuerRueckseite = maxSeite;
        globalePhase = phase;

        // produktNummerZuSeitenMap direkt aus den relevanten CSV-Daten erstellen
        const produktMapFuerVergleich = produktNummerZuSeitenMapAusCsv(csvDatenToUse);
        const { inDesignSeitenMap } = verarbeiteInDesignDaten(csvDatenToUse); // hoechsteSeiteNummerCsv, vorhandeneSeitenNummernCsv hier nicht direkt benötigt
        globaleInDesignSeitenMap = inDesignSeitenMap;

        const ergebnisse = vergleicheDaten(planMap, inDesignSeitenMap, produktMapFuerVergleich, maxSeite, phase);
        
        const seite4Analyse = analysiereSeite4(inDesignSeitenMap, planMap, ergebnisse);
        const merlegAnalyse = analysiereMerleg(ergebnisse);
        const aiErgebnis = {
            erfolg: true, testTyp: testTyp, phase: phase, katalogGesamtSeiten: maxSeite,
            planEintraege: planMap.size, inDesignSeiten: inDesignSeitenMap.size,
            zuEntfernen: ergebnisse.zuEntfernen.length, hinzufuegen: ergebnisse.hinzuzufuegen.length, korrekt: ergebnisse.korrekt.length,
            duplikatFehler: ergebnisse.duplikatFehler?.length || 0, // Sicherstellen, dass es definiert ist
            seite4Analyse: seite4Analyse, merlegAnalyse: merlegAnalyse,
            details: detailLevel === 'detail' ? {
                zuEntfernenListe: ergebnisse.zuEntfernen.slice(0, 5),
                korrektListe: ergebnisse.korrekt.slice(0, 5),
                hinzuzufuegenListe: ergebnisse.hinzuzufuegen.slice(0, 5),
                planMapKeys: Array.from(planMap.keys()).slice(0, 10),
                inDesignSeiten: Array.from(inDesignSeitenMap.keys()).slice(0, 10)
            } : null,
            timestamp: new Date().toISOString()
        };
        return aiErgebnis;
    } catch (fehler) {
        console.error(`AI-Test fehlgeschlagen (${testTyp}):`, fehler.message, fehler.stack);
        return { erfolg: false, fehler: fehler.message, stack: fehler.stack, timestamp: new Date().toISOString() };
    }
}

function analysiereSeite4(inDesignSeitenMap, planMap, ergebnisse) {
    const seite4 = inDesignSeitenMap.get('4');
    if (!seite4) return { fehler: 'Seite 4 nicht in InDesign-Daten gefunden' };
    const artikelNummern = seite4.produktnummern;
    if (!artikelNummern || artikelNummern.length === 0) return { fehler: 'Keine Artikelnummern auf Seite 4 gefunden.'};
    const kleinsteArtikel = Math.min(...artikelNummern.map(nr => parseInt(nr, 10))).toString();
    const istInPlan = planMap.has(kleinsteArtikel);
    const inZuEntfernen = ergebnisse.zuEntfernen.find(item => item.seite === '4');
    const inKorrekt = ergebnisse.korrekt.find(item => item.seite === '4');
    return {
        artikelNummern: artikelNummern, kleinsteArtikel: kleinsteArtikel, istInPlan: istInPlan,
        inZuEntfernen: !!inZuEntfernen, inKorrekt: !!inKorrekt,
        korrektKategorisiert: istInPlan ? !!inKorrekt : !!inZuEntfernen,
        planEintrag: istInPlan ? planMap.get(kleinsteArtikel) : null
    };
}

function analysiereMerleg(ergebnisse) {
    if (!ergebnisse || !ergebnisse.merlegBalance || !ergebnisse.katalogStatistik) {
        return { fehler: "Erforderliche Daten für Merleg-Analyse fehlen."};
    }
    const { korrektFormat, entfernenFormat, hinzufuegenFormat, leereSeitenFormat, istAusgeglichen } = ergebnisse.merlegBalance;
    const { gesamtSeiten: richtigenKatalogSeiten, korrekteSeiten: korrekteSeitenAnzahl, zuEntfernendeSeiten: zuEntfernendeSeitenAnzahl, hinzuzufuegendeSeiten: hinzuzufuegendeSeitenAnzahl } = ergebnisse.katalogStatistik;
    
    const merlegStimmt = istAusgeglichen; 
    
    return {
        katalogGesamtSeiten: richtigenKatalogSeiten, korrekteSeitenFormat: korrektFormat,
        zuEntfernendeSeitenFormat: entfernenFormat, hinzufuegendeSeitenFormat: hinzufuegenFormat,
        leereSeitenFormat: leereSeitenFormat, 
        merlegStimmt: merlegStimmt, 
        korrekteSeitenAnzahl: korrekteSeitenAnzahl,
        zuEntfernendeSeitenAnzahl: zuEntfernendeSeitenAnzahl, 
        hinzuzufuegendeSeitenAnzahl: hinzuzufuegendeSeitenAnzahl,
        debug: {
            formatBilanz: `Korrekt(${korrektFormat?.toFixed(1)}) + Entfernen(${entfernenFormat?.toFixed(1)}) + Hinzufügen(${hinzufuegenFormat?.toFixed(1)}) + Leer(${leereSeitenFormat?.toFixed(1)}) = ${(korrektFormat + entfernenFormat + hinzufuegenFormat + leereSeitenFormat)?.toFixed(1)} (Soll: ${richtigenKatalogSeiten})`,
            istAusgeglichenApp: istAusgeglichen
        }
    };
}

if (typeof window !== 'undefined') {
    window.fuehreAutomatischenTestDurch = fuehreAutomatischenTestDurch;
    window.aiTestFunktion = aiTestFunktion;
    window.ladeTestdatenAusDateienBrowser = ladeTestdatenAusDateienBrowser;
    window.exportiereTestdaten = exportiereTestdaten;
    window.validiereTestErgebnisse = validiereTestErgebnisse;
} else {
    module.exports = {
        ladeAlleTestdatenAusDateien
    };
}

console.log("testModul.js v1.3.5 geladen.");
