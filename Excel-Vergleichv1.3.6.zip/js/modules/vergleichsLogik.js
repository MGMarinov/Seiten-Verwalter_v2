// js/modules/vergleichsLogik.js - v1.3.6 - Wiederhergestellte Klassenlogik mit Artikel-Mapping
console.log("Lade vergleichsLogik.js v1.3.6...");

/**
 * Führt den Datenvergleich durch.
 * @param {Map<string, object>} planMap - Verarbeitete Plandaten (Schlüssel: Kataloggruppierung).
 * @param {Map<string, string>} artikelZuGruppeMap - Map von Artnr zu Kataloggruppierung.
 * @param {Map<string, object>} inDesignSeitenMap - Verarbeitete InDesign-Daten.
 * @param {Map<string, Set<string>>} produktNummerZuSeitenMap - Map von Produktnummern zu den Seiten.
 * @param {number} maxPlanSeiteFuerRueckseite - Höchste Seite aus dem Plan.
 * @param {string} phase - Die erkannte Phase ('SORTIERT' oder 'UNSORTIERT').
 * @returns {object} - Ein Objekt mit den Vergleichsergebnissen.
 */
function vergleicheDaten(planMap, artikelZuGruppeMap, inDesignSeitenMap, produktNummerZuSeitenMap, maxPlanSeiteFuerRueckseite, phase) {
    const korrekt = [];
    const hinzuzufuegen = [];
    const zuEntfernen = [];
    const duplikatFehler = [];

    const inDesignProdukteVerarbeitet = new Set();
    const planGruppenVerarbeitet = new Set();

    // Schritt 1: InDesign-Daten durchgehen, um korrekte und zu entfernende Elemente zu finden
    inDesignSeitenMap.forEach((seitenEintrag, seiteStr) => {
        seitenEintrag.rohdatenZeilen.forEach(zeile => {
            const produktNummer = zeile.Produktnummer?.toString().trim();
            if (!produktNummer || produktNummer === "FEHLER: Datei nicht gefunden") return;

            const objektId = `${seiteStr}-${produktNummer}`;
            if (inDesignProdukteVerarbeitet.has(objektId)) return;

            const gruppeKey = artikelZuGruppeMap.get(produktNummer);
            const planEintrag = gruppeKey ? planMap.get(gruppeKey) : null;

            if (planEintrag && !planEintrag.istFlugblatt && !planEintrag.formatFehler && planEintrag.gesamtFormat > 0) {
                // Gültiger Plan-Eintrag gefunden -> KORREKT
                korrekt.push({
                    seite: seiteStr,
                    katalogGruppe: produktNummer, // Zeige die spezifische Artikelnummer an
                    modell: planEintrag.modell,
                    status: '', // Wird später gefüllt
                    gesamtFormat: planEintrag.gesamtFormat, // Format der Gruppe
                    seitenFormat: !isNaN(zeile.gueltigesFormat) ? zeile.gueltigesFormat : 0, // Format des Artikels
                    planSeite: planEintrag.seite,
                    istTitel: planEintrag.seite === 1,
                    istRueckseite: planEintrag.seite === maxPlanSeiteFuerRueckseite,
                    istDoppelseite: planEintrag.istDoppelseite,
                    hatFormatAbweichung: false, // Initial
                    hatSeitenZahlFehler: false // Initial
                });
                planGruppenVerarbeitet.add(gruppeKey);
            } else {
                // Kein gültiger Plan-Eintrag -> ZU ENTFERNEN
                let grund = 'Nicht in Einteilung';
                if (planEintrag) {
                    if (planEintrag.istFlugblatt) grund = 'Flugblatt (Plan)';
                    else grund = 'Fehlerhafter Plan-Eintrag';
                }
                zuEntfernen.push({
                    seite: seiteStr,
                    katalogGruppe: produktNummer,
                    modell: zeile.Modell || planEintrag?.modell || 'Unbekannt',
                    seitenFormat: !isNaN(zeile.gueltigesFormat) ? zeile.gueltigesFormat : 0,
                    grund: grund
                });
            }
            inDesignProdukteVerarbeitet.add(objektId);
        });
    });

    // Schritt 2: Plan-Daten durchgehen, um hinzuzufügende Gruppen zu finden
    planMap.forEach((planEintrag, gruppe) => {
        if (!planGruppenVerarbeitet.has(gruppe) && !planEintrag.istFlugblatt && !planEintrag.formatFehler && planEintrag.gesamtFormat > 0) {
            hinzuzufuegen.push({
                seite: planEintrag.seite > 0 ? planEintrag.seite.toString() : '-',
                katalogGruppe: gruppe,
                modell: planEintrag.modell,
                gesamtFormat: planEintrag.gesamtFormat
            });
        }
    });
    
    // Schritt 3: Duplikate behandeln
    produktNummerZuSeitenMap.forEach((seitenSet, produktNummer) => {
        if (seitenSet.size > 1) {
            duplikatFehler.push({
                produktNummer: produktNummer,
                typ: 'Duplikat im Katalog',
                seiten: Array.from(seitenSet).join(', '),
                details: `Produktnummer auf ${seitenSet.size} Seiten gefunden.`
            });
        }
    });

    const leereSeiten = analysiereLeereSeiten(inDesignSeitenMap, maxPlanSeiteFuerRueckseite);
    const seitenzahlAbweichungen = phase === 'SORTIERT' ? validiereSeitenzahlen(korrekt) : [];

    // Formatabweichungen prüfen
    korrekt.forEach(item => {
        const gruppe = artikelZuGruppeMap.get(item.katalogGruppe);
        const planEintrag = planMap.get(gruppe);
        if (planEintrag && planEintrag.gesamtFormat !== item.seitenFormat && planEintrag.istDoppelseite === false && planEintrag.istHalbseite === true) {
             item.hatFormatAbweichung = true;
        }
    });

    return {
        zuEntfernen: zuEntfernen.sort((a,b) => a.seite.localeCompare(b.seite, 'de', { numeric: true })),
        hinzuzufuegen: hinzuzufuegen.sort((a,b) => a.katalogGruppe.localeCompare(b.katalogGruppe, 'de', { numeric: true })),
        korrekt: korrekt.sort((a,b) => a.seite.localeCompare(b.seite, 'de', { numeric: true })),
        duplikatFehler,
        seitenzahlAbweichungen,
        leereSeiten
    };
}

/**
 * Validiert die Seitenzahlen für die 'SORTIERT' Phase.
 * @param {object[]} korrekteElemente - Die Liste der als korrekt identifizierten Elemente.
 * @returns {object[]} - Eine Liste von Objekten, die Seitenzahlabweichungen beschreiben.
 */
function validiereSeitenzahlen(korrekteElemente) {
    const abweichungen = [];
    korrekteElemente.forEach(item => {
        if (item.planSeite > 0) {
            const idSeiteNum = parseInt(item.seite, 10);
            if (!isNaN(idSeiteNum) && idSeiteNum !== item.planSeite) {
                abweichungen.push({
                    katalogGruppe: item.katalogGruppe,
                    modell: item.modell,
                    planSeite: item.planSeite,
                    korrektSeite: idSeiteNum,
                    abweichung: idSeiteNum - item.planSeite
                });
                item.hatSeitenZahlFehler = true;
            }
        }
    });
    return abweichungen;
}

/**
 * Analysiert leere Seiten und Seiten mit verfügbarem Platz.
 * @param {Map<string, object>} inDesignSeitenMap - Verarbeitete InDesign-Daten.
 * @param {number} maxSeiteNum - Die höchste zu berücksichtigende Seitenzahl.
 * @returns {object[]} - Eine Liste leerer Seiten und Seiten mit verfügbarem Platz.
 */
function analysiereLeereSeiten(inDesignSeitenMap, maxSeiteNum) {
    const leereSeiten = [];
    const maxInDesignSeite = Array.from(inDesignSeitenMap.keys()).reduce((max, seite) => Math.max(max, parseInt(seite, 10) || 0), 0);
    const maxIteration = Math.max(maxSeiteNum, maxInDesignSeite);

    console.log(`DEBUG analysiereLeereSeiten: maxSeiteNum=${maxSeiteNum}, maxInDesignSeite=${maxInDesignSeite}, maxIteration=${maxIteration}`);

    for (let i = 1; i <= maxIteration; i++) {
        const seiteStr = i.toString();
        const inDesignEintrag = inDesignSeitenMap.get(seiteStr);

        if (!inDesignEintrag || !inDesignEintrag.hatInhalt) {
            // Vollständig leere Seite
            leereSeiten.push({
                seite: seiteStr,
                verfuegbaresFormat: 1.0,
                typ: 'vollständig leer'
            });
        } else {
            // Seite mit Inhalt - prüfe ob noch Platz verfügbar ist
            const belegteFormat = inDesignEintrag.seitenFormat || 0;
            const verfuegbaresFormat = Math.max(0, 1.0 - belegteFormat);

            // Seite nur hinzufügen wenn verfügbarer Platz > 0
            if (verfuegbaresFormat > 0) {
                const gerundeterVerfuegbarerPlatz = Math.round(verfuegbaresFormat * 100) / 100;
                leereSeiten.push({
                    seite: seiteStr,
                    verfuegbaresFormat: gerundeterVerfuegbarerPlatz,
                    typ: gerundeterVerfuegbarerPlatz >= 1.0 ? 'vollständig leer' : 'teilweise belegt'
                });
            }
        }
    }
    return leereSeiten;
}


if (typeof window !== 'undefined') {
    window.vergleicheDaten = vergleicheDaten;
}
console.log("vergleichsLogik.js v1.3.6 geladen.");