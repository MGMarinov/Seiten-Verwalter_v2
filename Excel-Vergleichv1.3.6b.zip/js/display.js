// js/display.js - v.2.0 - Anzeige- und UI-Funktionen
console.log("Lade display.js v.2.0...");

/**
 * Zeigt die Übersichten für Einteilung und InDesign initial an (ohne Filterung).
 * Speichert die verarbeiteten Daten global.
 * @param {Map<string, object>} planMap - Verarbeitete Plandaten (von logic.js).
 * @param {Map<string, object>} inDesignSeitenMap - Verarbeitete ID-Daten (von logic.js).
 * @param {number} maxPlanSeite - Höchste Seite <= 500 aus dem Plan (für Rückseitenlogik).
 */
function uebersichtAnzeigen(planMap, inDesignSeitenMap, maxPlanSeite) {
    globalePlanMap = planMap;
    globaleInDesignSeitenMap = inDesignSeitenMap;
    globaleMaxPlanSeiteFuerRueckseite = maxPlanSeite;
    filterAndDisplayPlanOverview('');
    filterAndDisplayIndesignOverview('');
}

/**
 * Filtert und zeigt die Einteilung-Übersicht an, inklusive Gesamt-Summen an korrekten Positionen.
 * Nutzt globalePlanMap. Berücksichtigt [Fehler] Tags.
 * @param {string} suchBegriff - Der aktuelle Suchbegriff aus dem Input-Feld.
 */
function filterAndDisplayPlanOverview(suchBegriff) {
    if (!planUebersichtBereich) {
        console.error("Fehler: Plan-Übersichts-Container nicht gefunden.");
        return;
    }

    const standardText = '<p class="text-gray-400 italic text-sm">Keine passenden Einteilung-Daten gefunden.</p>';
    const suchBegriffLower = suchBegriff.toLowerCase().trim();
    let hatErgebnisse = false;

    planUebersichtBereich.innerHTML = '';

    if (!globalePlanMap || globalePlanMap.size === 0) {
        planUebersichtBereich.innerHTML = standardText;
        return;
    }

    const ul = document.createElement('ul');
    ul.className = 'list-none space-y-1';

    let katalogGesamtFormat = 0;
    let flugblattGesamtFormat = 0;
    let anzahlKatalogEintraege = 0;
    let anzahlFlugblattEintraege = 0;

    const sortierteGruppen = Array.from(globalePlanMap.keys()).sort((a, b) =>
        a.localeCompare(b, undefined, { numeric: true })
    );

    sortierteGruppen.forEach(gruppe => {
        const eintrag = globalePlanMap.get(gruppe);
        if (!eintrag) return;

        let zeileMatch = false;
        if (suchBegriffLower === '') {
            zeileMatch = true;
        } else {
            if (gruppe.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
            if (!zeileMatch && eintrag.modell.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
        }

        if (zeileMatch) {
            hatErgebnisse = true;

            const li = document.createElement('li');
            const hauptSpan = document.createElement('span');
            hauptSpan.textContent = `${gruppe} (${eintrag.modell})`;

            let statusTags = [];
            if (eintrag.istFlugblatt) statusTags.push('<span class="flugblatt-markierung">[Flugblatt]</span>');
            if (eintrag.istDoppelseite) statusTags.push('<span class="doppel-tag">[Doppel]</span>');
            if (eintrag.formatFehler) statusTags.push('<span class="fehler-tag">[Fehler]</span>');
            if (eintrag.fehlerNichtInId) statusTags.push('<span class="fehler-tag">[Fehlt in ID]</span>');

            if (statusTags.length > 0) {
                hauptSpan.innerHTML += ' ' + statusTags.join(' ');
            }

            const formatSpan = document.createElement('span');
            formatSpan.textContent = `Format: ${eintrag.gesamtFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}`;

            li.appendChild(hauptSpan);
            li.appendChild(formatSpan);
            ul.appendChild(li);

            if (eintrag.istFlugblatt) {
                flugblattGesamtFormat += eintrag.gesamtFormat;
                anzahlFlugblattEintraege++;
            } else {
                katalogGesamtFormat += eintrag.gesamtFormat;
                anzahlKatalogEintraege++;
            }
        }
    });

    if (hatErgebnisse) {
        planUebersichtBereich.appendChild(ul);

        if (suchBegriffLower === '') {
            if (anzahlKatalogEintraege > 0) {
                const katalogSummary = document.createElement('li');
                katalogSummary.className = 'plan-katalog-summary-row';
                katalogSummary.innerHTML = `Katalog (${anzahlKatalogEintraege}): <span class="font-mono">${katalogGesamtFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}</span>`;
                ul.appendChild(katalogSummary);
            }

            if (anzahlFlugblattEintraege > 0) {
                const flugblattSummary = document.createElement('li');
                flugblattSummary.className = 'plan-flugblatt-summary-row';
                flugblattSummary.innerHTML = `Flugblatt (${anzahlFlugblattEintraege}): <span class="font-mono">${flugblattGesamtFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}</span>`;
                ul.appendChild(flugblattSummary);
            }

            const gesamtSummary = document.createElement('li');
            gesamtSummary.className = 'plan-final-summary-styling';
            const gesamtAnzahl = anzahlKatalogEintraege + anzahlFlugblattEintraege;
            const gesamtFormat = katalogGesamtFormat + flugblattGesamtFormat;
            gesamtSummary.innerHTML = `Gesamt (${gesamtAnzahl}): <span class="font-mono">${gesamtFormat.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1})}</span>`;
            ul.appendChild(gesamtSummary);
        }
    } else {
        planUebersichtBereich.innerHTML = standardText;
    }
}

/**
 * Filtert und zeigt die InDesign-Übersicht an.
 * Nutzt globaleInDesignSeitenMap und iteriert durch rohdatenZeilen für separate Anzeige.
 * Dedupliziert Einträge basierend auf Seite, Datei und Produktnummer (Ebene wird ignoriert).
 * Zeigt "FEHLER: Datei nicht gefunden" spezifisch an.
 * @param {string} suchBegriff - Der aktuelle Suchbegriff aus dem Input-Feld.
 */
function filterAndDisplayIndesignOverview(suchBegriff) {
    if (!indesignUebersichtBereich) {
        console.error("Fehler: InDesign-Übersichts-Container nicht gefunden.");
        return;
    }

    const standardText = '<p class="text-gray-400 italic text-sm">Keine passenden InDesign-Daten gefunden.</p>';
    const suchBegriffLower = suchBegriff.toLowerCase().trim();
    let hatErgebnisse = false;

    indesignUebersichtBereich.innerHTML = '';

    if (!globaleInDesignSeitenMap || globaleInDesignSeitenMap.size === 0) {
        indesignUebersichtBereich.innerHTML = standardText;
        return;
    }

    const indesignUl = document.createElement('ul');
    indesignUl.className = 'list-none space-y-1';

    const sortedSeiten = Array.from(globaleInDesignSeitenMap.keys()).sort((a, b) => {
        const numA = parseInt(a, 10);
        const numB = parseInt(b, 10);
        return isNaN(numA) || isNaN(numB) ? a.localeCompare(b) : numA - numB;
    });

    sortedSeiten.forEach(s => {
        const seitenEintragGesamt = globaleInDesignSeitenMap.get(s);
        if (!seitenEintragGesamt || !seitenEintragGesamt.rohdatenZeilen || seitenEintragGesamt.rohdatenZeilen.length === 0) return;

        const displayedEntriesThisPage = new Set();

        seitenEintragGesamt.rohdatenZeilen.forEach(rohZeile => {
            const prodNr = rohZeile.Produktnummer?.toString().trim() || '';
            const datei = rohZeile.Datei?.trim() || '';
            const formatAnzeige = rohZeile.Format?.toString().trim() || '';
            const ebene = rohZeile.Ebene?.trim() || '';

            const entryKey = `${s}_${datei}_${prodNr}`;

            if (displayedEntriesThisPage.has(entryKey)) {
                return;
            }

            let zeileMatch = false;
            if (prodNr || datei) {
                 if (suchBegriffLower === '') {
                     zeileMatch = true;
                 } else {
                     if (s.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && prodNr.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && datei.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && formatAnzeige.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && rohZeile.Modell?.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                     if (!zeileMatch && ebene.toLowerCase().includes(suchBegriffLower)) zeileMatch = true;
                 }
            }

            if (zeileMatch) {
                hatErgebnisse = true;
                displayedEntriesThisPage.add(entryKey);

                const li = document.createElement('li');
                const anzeigeSpan = document.createElement('span');

                if (prodNr === "FEHLER: Datei nicht gefunden") {
                    anzeigeSpan.innerHTML = `<span class="seite-text">Seite ${s}</span> - <span class="datei-text-id">${datei || 'Unbekannte Datei'}</span>: <span class="fehler-text-rot">${prodNr}</span>`;
                    const fehlerFormatSpan = document.createElement('span');
                    fehlerFormatSpan.className = 'format-text-id-fehler';
                    fehlerFormatSpan.textContent = 'Format: N/A';
                    li.appendChild(anzeigeSpan);
                    li.appendChild(fehlerFormatSpan);
                } else {
                    const nummernText = prodNr ? `(${prodNr})` : '(Keine ProdNr)';
                    anzeigeSpan.innerHTML = `<span class="seite-text">Seite ${s}</span> <span class="nummern-text">${nummernText}</span>`;
                    li.appendChild(anzeigeSpan);

                    const fS = document.createElement('span');
                    let formatText = 'Format: -';
                    try {
                        const formatNum = parseFloat(formatAnzeige.replace(',', '.'));
                        if (!isNaN(formatNum)) {
                            formatText = `Format: ${formatNum.toLocaleString('de-DE',{minimumFractionDigits:1,maximumFractionDigits:2})}`;
                        } else if (formatAnzeige) {
                             formatText = `Format: ${formatAnzeige}`;
                        }
                    } catch (parseError) {
                         if (formatAnzeige) formatText = `Format: ${formatAnzeige}`;
                    }
                    fS.textContent = formatText;
                    li.appendChild(fS);
                }

                let tooltipDetails = [];
                if (ebene) tooltipDetails.push(`Ebene: ${ebene}`);
                if (prodNr === "FEHLER: Datei nicht gefunden") {
                    tooltipDetails.push(`Datei: ${datei || 'Unbekannt'} - Gemeldeter Fehler`);
                } else {
                    if (prodNr) tooltipDetails.push(`Produkt: ${prodNr}`);
                    if (datei) tooltipDetails.push(`Datei: ${datei}`);
                }
                anzeigeSpan.title = tooltipDetails.join(' | ');

                // OBJEKTUM SZINTŰ "[Fehlt in Plan]" jelölés
                // Csak akkor jelenjen meg, ha ez a konkrét produktnummer problémás
                const istProblematisch = window.globaleProblematischeProduktNummern &&
                                        window.globaleProblematischeProduktNummern.has(prodNr);

                if (istProblematisch && prodNr !== "FEHLER: Datei nicht gefunden") {
                    const fehlerNichtInPlanSpan = document.createElement('span');
                    fehlerNichtInPlanSpan.className = 'fehler-tag-container';
                    fehlerNichtInPlanSpan.innerHTML = '<span class="fehler-tag" title="Produkt fehlt in Einteilung">[Fehlt in Plan]</span>';
                    if (li.children.length > 1) {
                        li.insertBefore(fehlerNichtInPlanSpan, li.children[1]);
                    } else {
                        li.appendChild(fehlerNichtInPlanSpan);
                    }
                }
                indesignUl.appendChild(li);
            }
        });
    });

    if (hatErgebnisse) {
        indesignUebersichtBereich.appendChild(indesignUl);
    } else {
        indesignUebersichtBereich.innerHTML = standardText;
    }
}

console.log("display.js v.2.0 geladen.");
