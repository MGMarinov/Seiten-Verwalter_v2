// js/parser.js - v.2.0 - Datenverarbeitungsfunktionen
console.log("Lade parser.js v.2.0...");

/**
 * Verarbeitet die Einteilungsdaten (Excel) und erstellt eine Map nach Kataloggruppierung.
 * Prüft auf Duplikate, Formatfehler und berechnet Gesamtformate.
 * @param {object[]} planRohdaten - Die geparsten Rohdaten aus der Excel-Datei.
 * @returns {{planMap: Map<string, object>, fehlerListe: object[], minSeite: number, maxSeite: number}}
 */
function verarbeitePlandaten(planRohdaten) {
    const planMap = new Map();
    const fehlerListe = [];
    let minSeite = Infinity;
    let maxSeite = -Infinity;

    const erwartetePlanSpaltenKern = ['Kataloggruppierung', 'Format'];
    const erwartetePlanSpaltenSuche = ['ModellNr', 'Modell', 'Artnr', 'VKPreis', 'Artikel', 'Seite'];

    if (!planRohdaten || planRohdaten.length === 0) {
        throw new Error("Eintheilung-Daten (Excel) sind leer oder ungültig.");
    }

    const ersteZeileKeysRoh = Object.keys(planRohdaten[0] || {});
    const ersteZeileKeys = ersteZeileKeysRoh.map(key => key.trim());

    const fehlendeKernSpalten = erwartetePlanSpaltenKern.filter(spalte => !ersteZeileKeys.includes(spalte));
    if (fehlendeKernSpalten.length > 0) {
        throw new Error(`Fehlende erforderliche Kernspalten in der Eintheilung-Datei (Excel): ${fehlendeKernSpalten.join(', ')}`);
    }

    const vorhandeneSuchSpalten = erwartetePlanSpaltenSuche.filter(spalte => ersteZeileKeys.includes(spalte));
    const duplikatPruefungMoeglich = vorhandeneSuchSpalten.length >= 3;

    let datenHashMap = new Map();
    let duplikateGefunden = new Set();

    if (duplikatPruefungMoeglich) {
        planRohdaten.forEach((zeile, index) => {
            const zeilennummer = index + 2;
            const datenWerte = vorhandeneSuchSpalten.map(spalte => {
                const wert = zeile[spalte];
                if (wert === null || wert === undefined || wert === '') return '';
                return String(wert).trim().toLowerCase();
            });
            const datenString = datenWerte.join('|');

            if (datenHashMap.has(datenString)) {
                const existierendeZeilen = datenHashMap.get(datenString);
                fehlerListe.push({
                    typ: 'Übereinstimmende Daten', zeile: zeilennummer,
                    gruppe: zeile.Kataloggruppierung?.toString().trim() || 'Unbekannt',
                    wert: `Identisch mit Zeile(n) ${existierendeZeilen.join(', ')}`,
                    modell: zeile.Modell?.trim() || '-'
                });
                duplikateGefunden.add(zeilennummer);
                 existierendeZeilen.forEach(zn => {
                    const fehlerIndex = fehlerListe.findIndex(f => f.zeile === zn && f.typ === 'Übereinstimmende Daten');
                    if (fehlerIndex !== -1) {
                        const andereZeilen = [...existierendeZeilen, zeilennummer].filter(z => z !== zn);
                        fehlerListe[fehlerIndex].wert = `Identisch mit Zeile(n) ${andereZeilen.join(', ')}`;
                    }
                 });
                existierendeZeilen.push(zeilennummer);
            } else {
                datenHashMap.set(datenString, [zeilennummer]);
            }
        });
    }

    planRohdaten.forEach((zeile, index) => {
        const zeileRoh = { ...zeile };
        const gruppe = zeile.Kataloggruppierung?.toString().trim();
        if (!gruppe) return;

        const modell = zeile.Modell?.toString().trim() || 'Unbekannt';
        const formatRoh = zeile.Format;
        const format = parseFloat(String(formatRoh).replace(',', '.'));
        const seiteRoh = zeile.Seite;

         if (!planMap.has(gruppe)) {
             planMap.set(gruppe, {
                 gesamtFormat: 0, modell: 'Unbekannt', artikel: [], formatFehler: false,
                 istDoppelseite: false, istFlugblatt: false, istHalbseite: false,
                 seiten: new Set(), ersteSeiteNum: NaN,
                 fehlerNichtInId: false
             });
         }
         const eintrag = planMap.get(gruppe);
         if (eintrag.modell === 'Unbekannt' && modell !== 'Unbekannt') eintrag.modell = modell;
         eintrag.artikel.push(zeileRoh);

         if (isNaN(format)) {
             if (!eintrag.formatFehler && zeile.Format !== undefined && zeile.Format !== null && zeile.Format !== '') {
                 fehlerListe.push({ typ: 'Ungültiges Format (keine Zahl)', zeile: index + 2, gruppe: gruppe, wert: zeile.Format, modell: modell });
                 eintrag.formatFehler = true;
             }
         } else {
             eintrag.gesamtFormat += format;
         }

         if (seiteRoh !== undefined && seiteRoh !== null && seiteRoh !== '') {
             const seiteNum = parseInt(String(seiteRoh), 10);
             if (!isNaN(seiteNum)) {
                 eintrag.seiten.add(seiteNum);
                 if (isNaN(eintrag.ersteSeiteNum) || seiteNum < eintrag.ersteSeiteNum) {
                     eintrag.ersteSeiteNum = seiteNum;
                 }
                 if (seiteNum < minSeite) minSeite = seiteNum;
                 if (seiteNum > maxSeite) maxSeite = seiteNum;
             }
         }
    });

    planMap.forEach((eintrag, gruppe) => {
        const hatKatalogSeite = Array.from(eintrag.seiten).some(s => s > 0 && s <= 500);
        const hatFlugblattSeite = Array.from(eintrag.seiten).some(s => s > 500);

        if (hatFlugblattSeite && !hatKatalogSeite) {
            eintrag.istFlugblatt = true;
        } else if (hatKatalogSeite && !hatFlugblattSeite) {
            eintrag.istFlugblatt = false;
        } else if (hatKatalogSeite && hatFlugblattSeite) {
             eintrag.istFlugblatt = true;
             console.warn(`Gruppe ${gruppe} enthält sowohl Katalog- als auch Flugblattseiten. Wird als Konflikt behandelt.`);
        } else {
             const alleSeitenNull = eintrag.seiten.size > 0 && Array.from(eintrag.seiten).every(s => s === 0);
             if(alleSeitenNull) {
                 eintrag.istFlugblatt = false;
             } else if (eintrag.seiten.size === 0){
                 eintrag.istFlugblatt = false;
             }
        }

        const gerundetesFormat = Math.round(eintrag.gesamtFormat * 10) / 10;

        if (!eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat !== 0 && ![0.5, 1, 2].includes(gerundetesFormat)) {
             if (!fehlerListe.some(f => f.gruppe === gruppe && f.typ === 'Ungültiges Format (keine Zahl)')) {
                fehlerListe.push({ typ: 'Ungültige Format-Summe', gruppe: gruppe, modell: eintrag.modell, summe: gerundetesFormat, erwartet: "0.5, 1 oder 2" });
             }
             eintrag.formatFehler = true;
        }

        eintrag.istDoppelseite = !eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat === 2;
        eintrag.istHalbseite = !eintrag.istFlugblatt && !eintrag.formatFehler && gerundetesFormat === 0.5;
        eintrag.gesamtFormat = gerundetesFormat;
    });

    if (minSeite === Infinity) minSeite = 1;
    if (maxSeite === -Infinity) maxSeite = 1;

    return { planMap, fehlerListe, minSeite, maxSeite };
}

/**
 * Verarbeitet die InDesign-Daten (CSV). Fügt Fehler-Flag hinzu.
 * Erstellt eine Map der Seiten und eine Map von Produktnummern zu Seiten.
 * @param {object[]} inDesignRohdaten - Die geparsten Rohdaten aus der InDesign-Exportdatei (CSV).
 * @returns {{inDesignSeitenMap: Map<string, object>, hoechsteSeiteNummerCsv: number, vorhandeneSeitenNummernCsv: Set<number>, produktNummerZuSeitenMap: Map<string, Set<string>>}}
 */
function verarbeiteInDesignDaten(inDesignRohdaten) {
    const seitenRohdatenMap = new Map();
    const produktNummerZuSeitenMap = new Map();
    let formatFehlerWarnungAusgegeben = false;
    const erwarteteCsvSpalten = ['Produktnummer', 'Seite', 'Format', 'Datei'];
    let hoechsteSeiteNummerCsv = 0;
    const vorhandeneSeitenNummernCsv = new Set();

    if (!inDesignRohdaten || inDesignRohdaten.length === 0) {
        throw new Error("InDesign-Daten (CSV) sind leer oder ungültig.");
    }

    const ersteZeileKeys = Object.keys(inDesignRohdaten[0] || {});
    const fehlendeSpalten = erwarteteCsvSpalten.filter(spalte => !ersteZeileKeys.includes(spalte));
    if (fehlendeSpalten.length > 0) {
        throw new Error(`Fehlende erforderliche Spalten in der InDesign-Datei (CSV): ${fehlendeSpalten.join(', ')}`);
    }

    inDesignRohdaten.forEach(zeile => {
        const seite = zeile.Seite?.toString().trim();
        const produktnummer = zeile.Produktnummer?.toString().trim();
        const formatRoh = zeile.Format?.toString().trim();
        const datei = zeile.Datei?.toString().trim();

        if (!seite) return;

        const seitenummer = parseInt(seite, 10);
        if (!isNaN(seitenummer)) {
            vorhandeneSeitenNummernCsv.add(seitenummer);
            if (seitenummer > hoechsteSeiteNummerCsv) {
                hoechsteSeiteNummerCsv = seitenummer;
            }
        }

        let gueltigesFormat = NaN;
        if (formatRoh) {
            const formatNormalisiert = formatRoh.replace(',', '.');
            gueltigesFormat = parseFloat(formatNormalisiert);
            if (isNaN(gueltigesFormat) && !formatFehlerWarnungAusgegeben) {
                console.warn(`Ungültiges Format in CSV gefunden: "${formatRoh}" (Seite: ${seite})`);
                formatFehlerWarnungAusgegeben = true;
            }
        }

        const zeileErweitert = { ...zeile, gueltigesFormat };

        if (!seitenRohdatenMap.has(seite)) {
            seitenRohdatenMap.set(seite, []);
        }
        seitenRohdatenMap.get(seite).push(zeileErweitert);

        if (produktnummer) {
            if (!produktNummerZuSeitenMap.has(produktnummer)) {
                produktNummerZuSeitenMap.set(produktnummer, new Set());
            }
            produktNummerZuSeitenMap.get(produktnummer).add(seite);
        }

        if (datei) {
            const nummernAusDatei = extrahiereProduktnummernAusDatei(datei);
            nummernAusDatei.forEach(nummer => {
                if (!produktNummerZuSeitenMap.has(nummer)) {
                    produktNummerZuSeitenMap.set(nummer, new Set());
                }
                produktNummerZuSeitenMap.get(nummer).add(seite);
            });
        }
    });

    const inDesignSeitenMap = new Map();
    seitenRohdatenMap.forEach((rohdatenListe, seite) => {
        const produktnummern = new Set();
        const dateinamen = new Set();
        let maxFormat = 0;
        let sumFormat = 0;
        let anzahlGueltigerFormate = 0;
        let hatGueltigenInhalt = false;

        rohdatenListe.forEach(zeile => {
            const nummerAusCsv = zeile.Produktnummer?.toString().trim();
            const dateiName = zeile.Datei?.toString().trim();
            if (nummerAusCsv) { produktnummern.add(nummerAusCsv); hatGueltigenInhalt = true; }
            if (dateiName) {
                dateinamen.add(dateiName);
                const nummernAusDatei = extrahiereProduktnummernAusDatei(dateiName);
                if (nummernAusDatei.length > 0) {
                    nummernAusDatei.forEach(nr => produktnummern.add(nr));
                    hatGueltigenInhalt = true;
                }
            }
            if (!isNaN(zeile.gueltigesFormat)) {
                maxFormat = Math.max(maxFormat, zeile.gueltigesFormat);
                sumFormat += zeile.gueltigesFormat;
                anzahlGueltigerFormate++;
                if (zeile.gueltigesFormat > 0) hatGueltigenInhalt = true;
            }
        });
         if (!hatGueltigenInhalt && dateinamen.size > 0) {
             hatGueltigenInhalt = true;
         }

        inDesignSeitenMap.set(seite, {
            produktnummern: Array.from(produktnummern).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
            dateinamen: Array.from(dateinamen),
            rohdatenZeilen: rohdatenListe,
            seitenFormat: maxFormat,
            seitennummer: seite,
            hatInhalt: hatGueltigenInhalt,
            fehlerNichtInPlan: false,
            istHalbseite: maxFormat === 0.5
        });
    });

    return { inDesignSeitenMap, hoechsteSeiteNummerCsv, vorhandeneSeitenNummernCsv, produktNummerZuSeitenMap };
}

console.log("parser.js v.2.0 geladen.");
