// js/search.js - v.2.0 - Suchfunktionen
console.log("Lade search.js v.2.0...");

/**
 * Sucht in den global gespeicherten Einteilung-Rohdaten nach einer Kataloggruppierung (Sidebar-Suche).
 * Zeigt Ergebnisse in einem Popup-Modal an.
 */
function sucheInPlandaten(suchBegriff) {
    if (!katalogSucheErgebnis) return;
    const begriff = suchBegriff.trim();
    katalogSucheErgebnis.innerHTML = '';

    if (!begriff) {
        katalogSucheErgebnis.innerHTML = '<p class="text-gray-500 italic">Geben Sie eine Kataloggruppierung ein.</p>';
        return;
    }

    if (globalePlanRohdaten.length === 0) {
        katalogSucheErgebnis.innerHTML = '<p class="text-yellow-400 italic">Keine Einteilung-Daten zum Durchsuchen geladen.</p>';
        return;
    }

    const begriffLower = begriff.toLowerCase();
    const treffer = globalePlanRohdaten.filter(zeile => zeile.Kataloggruppierung?.toString().trim().toLowerCase() === begriffLower);

    if (treffer.length === 0) {
        katalogSucheErgebnis.innerHTML = `<p class="text-gray-400 italic">Keine Einträge für "${begriff}" gefunden.</p>`;
    } else {
        // Kurze Vorschau in der Sidebar
        katalogSucheErgebnis.innerHTML = `<p class="text-green-400 italic cursor-pointer hover:text-green-300" onclick="oeffneKatalogSucheModal()">
            ${treffer.length} Einträge gefunden für "${begriff}" - Klicken für Details
        </p>`;

        // Detaillierte Ergebnisse im Modal anzeigen
        zeigeKatalogSucheErgebnisseImModal(treffer, begriff);
    }
}

/**
 * Zeigt die Katalog-Suchergebnisse im Modal an.
 */
function zeigeKatalogSucheErgebnisseImModal(treffer, suchBegriff) {
    const modalInhalt = document.getElementById('katalogSucheModalInhalt');
    if (!modalInhalt) return;

    // Format Gesamt berechnen
    const formatGesamt = treffer.reduce((sum, zeile) => {
        const format = zeile.Format;
        return sum + (typeof format === 'number' ? format : 0);
    }, 0);

    let html = `<div class="space-y-4">
        <div class="flex justify-between items-center bg-slate-700/50 p-3 rounded border border-slate-600/50">
            <div>
                <h4 class="font-semibold text-white">Gefunden: ${treffer.length} Einträge für "${suchBegriff}"</h4>
            </div>
            <div class="text-right">
                <div class="text-sm text-gray-400">Format Gesamt:</div>
                <div class="text-lg font-bold text-green-400">${formatGesamt.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 2 })}</div>
            </div>
        </div>`;

    // Tabellenkopf
    html += `<div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-slate-700/50 border-b border-slate-600">
                    <th class="text-left p-2 text-gray-300 font-medium">Artnr</th>
                    <th class="text-left p-2 text-gray-300 font-medium">Artikel</th>
                    <th class="text-center p-2 text-gray-300 font-medium">Seite</th>
                    <th class="text-right p-2 text-gray-300 font-medium">Format</th>
                    <th class="text-left p-2 text-gray-300 font-medium">Modell</th>
                </tr>
            </thead>
            <tbody>`;

    // Tabellenzeilen
    treffer.forEach((zeile, index) => {
        const artnr = zeile.Artnr || '-';
        const artikel = zeile.Artikel || '-';
        const seite = zeile.Seite || '-';
        const format = typeof zeile.Format === 'number' ?
            zeile.Format.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 2 }) : '-';
        const modell = zeile.Modell || '-';

        const zebraClass = index % 2 === 0 ? 'bg-slate-800/30' : 'bg-slate-700/20';

        html += `<tr class="${zebraClass} hover:bg-slate-600/30 transition-colors">
            <td class="p-2 text-white font-mono">${artnr}</td>
            <td class="p-2 text-gray-200">${artikel}</td>
            <td class="p-2 text-center text-white font-mono">${seite}</td>
            <td class="p-2 text-right text-white font-mono">${format}</td>
            <td class="p-2 text-gray-200">${modell}</td>
        </tr>`;
    });

    html += `</tbody></table></div></div>`;
    modalInhalt.innerHTML = html;
}

/**
 * Fügt Event Listener für Input und Clear Button hinzu.
 */
function setupClearButton(inputElement, clearButtonElement, callbackFn) {
    if (!inputElement || !clearButtonElement) { 
        console.error("Fehler: Input- oder Clear-Button-Element fehlt für setupClearButton."); 
        return; 
    }
    
    const toggleClearButton = () => { 
        clearButtonElement.classList.toggle('hidden', inputElement.value.length === 0); 
    };
    
    inputElement.addEventListener('input', toggleClearButton);
    clearButtonElement.addEventListener('click', () => { 
        inputElement.value = ''; 
        toggleClearButton(); 
        if (callbackFn) { 
            setTimeout(() => { 
                callbackFn(''); 
            }, 0); 
        } 
        inputElement.focus(); 
    });
    
    toggleClearButton();
}

console.log("search.js v.2.0 geladen.");
