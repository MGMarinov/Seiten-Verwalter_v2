// js/dom.js - v.2.0 - DOM-Elemente und globale Variablen
console.log("Lade dom.js v.2.0...");

// --- Globale Variablen ---
let globalePlanRohdaten = [];
let globalePlanMap = new Map();
let globaleInDesignSeitenMap = new Map();
let globaleKorrekteDaten = [];
let globaleMaxPlanSeiteFuerRueckseite = 0;

// --- DOM-Elemente ---
const dateiPlanInput = document.getElementById('dateiPlan');
const dateiInDesignInput = document.getElementById('dateiInDesign');
const vergleichButton = document.getElementById('vergleichButton');
const fehlerBereich = document.getElementById('fehlerBereich');
const fehlerAnzeige = document.getElementById('fehlerAnzeige');
const entfernenAnzeige = document.getElementById('entfernenAnzeige');
const hinzufuegenAnzeige = document.getElementById('hinzufuegenAnzeige');
const korrektAnzeige = document.getElementById('korrektAnzeige');
const entfernenTotal = document.getElementById('entfernenTotal');
const hinzufuegenTotal = document.getElementById('hinzufuegenTotal');
const duplikatFehlerBereich = document.getElementById('duplikatFehlerBereich');
const duplikatFehlerAnzeige = document.getElementById('duplikatFehlerAnzeige');
const leereSeitenAnzeige = document.getElementById('leereSeitenAnzeige');
const planUebersichtBereich = document.getElementById('planUebersichtBereich');
const indesignUebersichtBereich = document.getElementById('indesignUebersichtBereich');
const katalogSucheInput = document.getElementById('katalogSucheInput');
const katalogSucheErgebnis = document.getElementById('katalogSucheErgebnis');
const planSucheInput = document.getElementById('planSucheInput');
const indesignSucheInput = document.getElementById('indesignSucheInput');
const korrektSpeichernButton = document.getElementById('korrektSpeichernButton');
const resetButton = document.getElementById('resetButton');
const katalogSucheClear = document.getElementById('katalogSucheClear');
const planSucheClear = document.getElementById('planSucheClear');
const indesignSucheClear = document.getElementById('indesignSucheClear');
const hilfeButton = document.getElementById('hilfeButton');
const hilfeModalOverlay = document.getElementById('hilfeModalOverlay');
const hilfeModalSchliessen = document.getElementById('hilfeModalSchliessen');

console.log("dom.js v.2.0 geladen.");
